# Change Log

Related pages: [[index]], [[folder-structure]], [[project-overview]]

## Purpose

This file records important changes to the LLM Wiki so humans and AI assistants can understand how the wiki has developed over time.

## Log Format

Each entry should use this format:

```markdown
### YYYY-MM-DD — Short change title

**Changed files:**
- `file-name.md`

**What changed:**
- Short description of the change.

**Reason:**
- Why the change was made.
```

## Initial Entry

### 2026-06-17 — Created first LLM Wiki structure

**Changed files:**
- `AGENTS.md`
- `index.md`
- `project-overview.md`
- `terminology.md`
- `source-materials.md`
- `extraction-rules.md`
- `prompt-rules.md`
- `examples.md`
- `known-errors.md`
- `workflows.md`

**What changed:**
- Created the first version of the LLM Wiki.
- Added core rules, terminology, extraction rules, prompt rules, examples, known errors, source rules, and workflows.

**Reason:**
- To create a durable project memory layer for AI-assisted work on Sinitic / Chinese historical and humanities texts.

### 2026-06-18 — Connected wiki graph and source-001 outputs

**Changed files:**
- `index.md`
- `folder-structure.md`
- `terminology.md`
- `source-001.md`
- `final-summary.md`
- `log.md`
- `outputs/source-001/processing-notes.md`
- `outputs/source-001/cbdb-enrichment.md`
- `outputs/source-001/chgis-enrichment.md`
- `outputs/source-001/map-network-cross-reading.md`
- `outputs/source-001/source-001.nlp-summary.md`

**What changed:**
- Added a `source-001` hub page.
- Linked operational pages, skills, and source-derived output notes from `index.md`.
- Converted skill references in `index.md` and `folder-structure.md` into Obsidian wikilinks.
- Added related-page backlinks to isolated notes.
- Added terminology for RESTful APIs, OpenAI-compatible APIs, GIS, historical GIS, network analysis, external enrichment, gazetteer matching, CBDB, CHGIS, and TGAZ.

**Reason:**
- To make the wiki easier to navigate in Obsidian and to help AI agents discover relevant source, method, and output notes before analysis.

### 2026-06-19 — Added non-secret Google Cloud project notes

**Changed files:**
- `google-cloud-info.md`
- `index.md`
- `.gitignore`

**What changed:**
- Added a Google Cloud metadata page for project ID, enabled APIs, service accounts, storage buckets, and local default settings.
- Added local secret-file ignore rules and a `.env.local` placeholder for API keys.

**Reason:**
- To support API and cloud-backed history research workflows without storing credentials or private keys in wiki Markdown.

### 2026-06-19 — Added first developing research object

**Changed files:**
- `background/research-questions.md`
- `index.md`
- `log.md`

**What changed:**
- Added a new research questions page.
- Recorded Research Object 1: wartime communication between the Qing central government and frontline military actors, using official records from a still-to-be-selected warfare case.
- Added provisional research questions, source directions, extraction fields, method notes, and open decisions.
- Linked the new page from the wiki index.

**Reason:**
- To mark the user's first research idea in the wiki while preserving its provisional status and making future development easier.

### 2026-06-19 — Added Material 1 Google Cloud OCR skill

**Changed files:**
- `skills/material-1-google-cloud-ocr.md`
- `scripts/ocr_material1_google_docai.py`
- `source-materials.md`
- `folder-structure.md`
- `index.md`
- `log.md`

**What changed:**
- Added a book-specific OCR skill for Material 1, 《明清臺灣檔案彙編》第貳輯第30冊.
- Recorded layout notes for the vertical Traditional Chinese page design.
- Added a reusable Python command runner for rendering Finder/PDF pages and sending page images to Google Cloud Document AI OCR.
- Linked the OCR skill from the source record, folder structure, and wiki index.

**Reason:**
- To make future OCR work on Material 1 repeatable, provenance-aware, and careful about the difference between Finder/PDF page numbers and printed page numbers.

### 2026-06-22 — Added 上諭 summary skill

**Changed files:**
- `skills/summarize-shangyu.md`
- `index.md`
- `folder-structure.md`
- `log.md`

**What changed:**
- Added a reusable skill for summarizing 林爽文 `上諭` records into structured JSON.
- Linked the skill from the wiki index and folder-structure page.
- Recorded `announce_date`, transmission formula, emperor opinion, command target, responding-message evidence, and major-location rules.

**Reason:**
- To make imperial-order summaries consistent with the existing `上奏` and `硃批` summary workflows.

### 2026-06-19 — Added Material 1 OCR outputs for Finder pages 43-47

**Changed files:**
- `ocr/user-source-1/user-source-1-finder-pages-043-047.ocr.txt`
- `ocr/user-source-1/user-source-1-finder-pages-043-047.docai.combined.json`
- `outputs/user-source-1/processing-notes.md`
- `source-materials.md`
- `scripts/ocr_material1_google_docai.py`
- `log.md`

**What changed:**
- Combined Google Cloud Document AI JSON outputs for Finder pages 43-47.
- Regenerated page-level TXT and combined TXT from the Document AI layout-parser JSON schema.
- Added processing notes for the OCR run and linked the OCR artifacts from the source record.

**Reason:**
- To preserve OCR provenance and make the Material 1 Finder page 43-47 outputs discoverable for future transcription, checking, and extraction.

### 2026-06-20 — Cleaned Material 1 OCR TXT and added cleanup guideline

**Changed files:**
- `cleaned/user-source-1/user-source-1-finder-pages-043-047.cleaned.txt`
- `skills/material-1-google-cloud-ocr.md`
- `outputs/user-source-1/processing-notes.md`
- `source-materials.md`
- `log.md`

**What changed:**
- Cleaned the Google Cloud OCR TXT for Finder pages 43-47 into four document-level records.
- Added a cleanup guideline for 《明清臺灣檔案彙編》 OCR outputs.
- Recorded the cleaned output in processing notes and the source record.

**Reason:**
- To make Material 1 OCR text easier to review, cite, and process while preserving OCR uncertainty.

### 2026-06-20 — Added Chinese reign-date conversion skill

**Changed files:**
- `skills/chinese-reign-date-conversion.md`
- `skills/material-1-google-cloud-ocr.md`
- `cleaned/user-source-1/user-source-1-finder-pages-043-047.cleaned.txt`
- `outputs/user-source-1/processing-notes.md`
- `source-materials.md`
- `index.md`
- `folder-structure.md`
- `log.md`

**What changed:**
- Added a reusable skill requiring Academia Sinica Sinocal for Chinese reign-date conversion.
- Appended Gregorian dates to repeated Qianlong 51 date strings in the cleaned Material 1 TXT.
- Recorded that Sinocal was not reachable during this pass and should be checked later.

**Reason:**
- To standardize date conversion while preserving original Chinese dates and avoiding unverifiable conversion claims.

### 2026-06-20 — Added Qianlong year quick reference

**Changed files:**
- `skills/chinese-reign-date-conversion.md`
- `log.md`

**What changed:**
- Added a quick-reference table for 乾隆四十九年至乾隆六十年, including Arabic reign-year notation and approximate Gregorian year.
- Added a warning that exact month/day conversion still requires Sinocal because lunar years cross Gregorian year boundaries.

**Reason:**
- To help with repeated Qianlong dates in Material 1 while avoiding false precision.

### 2026-06-20 — Converted cleaned Material 1 records to JSON

**Changed files:**
- `cleaned/user-source-1/user-source-1-finder-pages-043-047.cleaned.json`
- `skills/material-1-google-cloud-ocr.md`
- `outputs/user-source-1/processing-notes.md`
- `source-materials.md`
- `log.md`

**What changed:**
- Converted the cleaned TXT records for Finder pages 43-47 into JSON.
- Used `文首日期` instead of `日期`.
- Recorded `Finder頁碼` as an array.

**Reason:**
- To make the cleaned Material 1 OCR output easier to query and process programmatically.

### 2026-06-20 — Added parsed relationship fields to Material 1 JSON

**Changed files:**
- `cleaned/user-source-1/user-source-1-finder-pages-043-047.cleaned.json`
- `skills/material-1-google-cloud-ocr.md`
- `outputs/user-source-1/processing-notes.md`
- `log.md`

**What changed:**
- Added `來源解析` and `職銜作者解析` arrays while preserving the original source and post-author strings.
- Documented that compound fields should only be split when the relationship is clear.

**Reason:**
- To show relationships such as source series plus volume, and official post plus author, in machine-readable JSON without losing the original wording.

### 2026-06-20 — Simplified Material 1 JSON relationship schema

**Changed files:**
- `cleaned/user-source-1/user-source-1-finder-pages-043-047.cleaned.json`
- `skills/material-1-google-cloud-ocr.md`
- `outputs/user-source-1/processing-notes.md`
- `log.md`

**What changed:**
- Changed `來源` from a string plus `來源解析` into a direct array `[系列／檔名, 冊次]`.
- Changed `職銜＋作者` plus `職銜作者解析` into direct `職銜作者` array `[職銜, 作者]`.

**Reason:**
- To match the user's preferred compact JSON schema for compound values.

### 2026-06-20 — Extracted body-text official posts and personal names

**Changed files:**
- `outputs/user-source-1/user-source-1-finder-pages-043-047.body-officials-persons.json`
- `outputs/user-source-1/processing-notes.md`
- `source-materials.md`
- `log.md`

**What changed:**
- Extracted official posts and personal names from `正文` fields only.
- Added linked official-post/person pairs with evidence snippets and uncertainty flags.

**Reason:**
- To support structured analysis of people and offices while keeping extraction evidence separate from metadata.

### 2026-06-20 — Identified reported messages and message sources

**Changed files:**
- `outputs/user-source-1/user-source-1-finder-pages-043-047.reported-message-sources.json`
- `outputs/user-source-1/processing-notes.md`
- `source-materials.md`
- `log.md`

**What changed:**
- Added a structured document-by-document summary of what each first-hand text reports.
- Identified the source of each reported message with evidence snippets.

**Reason:**
- To support analysis of information flow, reporting chains, and source provenance in Material 1.
### 2026-06-22 — Added Attempt 002 for 林爽文 early-stage research

**Changed files:**
- `corpora/lin-shuangwen-first-hand-json.md`
- `background/lin-shuangwen-war-stages.md`
- `research-attempts/README.md`
- `research-attempts/attempt-002-lin-shuangwen-early-stages.md`
- `index.md`
- `folder-structure.md`
- `source-materials.md`
- `background/research-questions.md`
- `log.md`

**What changed:**
- Added a reusable corpus page for `/Users/creamybanana/Downloads/林爽文/Final Drive Copy/奏摺上諭結構化數據.json`.
- Added a working three-stage model of the 林爽文 war: 黃仕簡／任承恩, 常青／藍元枚, and 福康安.
- Added a `research-attempts/` structure so later attempts can reuse the same corpus without duplicating notes.
- Created Attempt 002, focused on turning from the previously studied 福康安 final stage to the first stage of the war.

**Reason:**
- To make the second LLM Wiki historical-research attempt explicit and to prepare the wiki for later attempts that reuse the same first-hand materials.

### 2026-06-22 — Added Stage 1 date-adjustment script

**Changed files:**
- `scripts/adjust_lin_shuangwen_dates.py`
- `research-attempts/attempt-002-lin-shuangwen-early-stages.md`
- `log.md`

**What changed:**
- Added a script that works directly from the original 林爽文 first-hand JSON and adjusts date fields by `doc_type` without adding interpretive fields to each record.
- Recorded the initial adjustment rules for `上奏`, `硃批`, and `上諭`; `移咨` and `其他` are left unchanged for now.

**Reason:**
- To solve the first data-organization problem in Attempt 002 while keeping the adjusted JSON close to the original source structure.

### 2026-06-22 — Updated original JSON 上諭 issue dates from XLSM

**Changed files:**
- `/Users/creamybanana/Downloads/林爽文/Final Drive Copy/奏摺上諭結構化數據.json`
- `scripts/update_shangyu_dates_from_xlsm.py`
- `scripts/adjust_lin_shuangwen_dates.py`
- `outputs/attempt-002/stage1-date-adjusted.json`
- `outputs/attempt-002/stage1-date-adjustment-summary.md`
- `corpora/lin-shuangwen-first-hand-json.md`
- `log.md`

**What changed:**
- Matched all 438 `上諭` records by `title` against `/Users/creamybanana/Downloads/林爽文/林爽文Final/（3）原始史料統計/奏摺上諭名單.xlsm`.
- Read the western date from `西歷日期` and mechanically converted it to 乾隆 Chinese date text without online date conversion.
- Wrote the converted date to `issue_date` for `上諭` records in the original JSON.
- Removed `memorial_date` and `rescript_date` from `上諭` records.
- Regenerated the Stage 1 adjusted JSON.

**Reason:**
- To give `上諭` records usable issue dates while preserving the user's preferred date-field semantics by document type.

### 2026-06-22 — Applied date-field semantics to original JSON 上奏 and 硃批

**Changed files:**
- `/Users/creamybanana/Downloads/林爽文/Final Drive Copy/奏摺上諭結構化數據.json`
- `scripts/apply_date_field_semantics_to_source_json.py`
- `outputs/attempt-002/stage1-date-adjusted.json`
- `outputs/attempt-002/stage1-date-adjustment-summary.md`
- `corpora/lin-shuangwen-first-hand-json.md`
- `log.md`

**What changed:**
- For all `上奏` records, kept `memorial_date` and removed `rescript_date` / `issue_date`.
- For all `硃批` records, kept `memorial_date` and `rescript_date`, and removed `issue_date`.
- Verified that `上諭` records still keep `issue_date` and do not contain `memorial_date` / `rescript_date`.
- Regenerated the Stage 1 adjusted JSON.

**Reason:**
- To make the original JSON itself follow the preferred date-field semantics before further Stage 1 analysis.

### 2026-06-22 — Renamed source JSON date fields and paired Chinese/Arabic dates

**Changed files:**
- `/Users/creamybanana/Downloads/林爽文/Final Drive Copy/奏摺上諭結構化數據.json`
- `scripts/rename_source_json_date_fields.py`
- `scripts/adjust_lin_shuangwen_dates.py`
- `outputs/attempt-002/stage1-date-adjusted.json`
- `outputs/attempt-002/stage1-date-adjustment-summary.md`
- `corpora/lin-shuangwen-first-hand-json.md`
- `research-attempts/attempt-002-lin-shuangwen-early-stages.md`
- `log.md`

**What changed:**
- Renamed `memorial_date` to `send_date`.
- Renamed `rescript_date` to `receive_date`.
- Renamed `issue_date` to `announce_date` for `上諭`.
- Converted real date values to `[Chinese date, Arabic date]` pairs.
- Regenerated the Stage 1 adjusted JSON under the new schema.

**Reason:**
- To make date semantics explicit and keep Chinese and Arabic dates together in the data structure.

### 2026-06-22 — Reformatted JSON date fields under title

**Changed files:**
- `/Users/creamybanana/Downloads/林爽文/Final Drive Copy/奏摺上諭結構化數據.json`
- `outputs/attempt-002/stage1-date-adjusted.json`
- `scripts/format_json_dates_under_title.py`
- `log.md`

**What changed:**
- Reordered each JSON object so date fields appear immediately after `title`.
- Kept `[Chinese date, Arabic date]` arrays on one line.
- Regenerated the Stage 1 adjusted output with the same layout.

**Reason:**
- To make date fields easier to read during manual source inspection.

### 2026-06-22 — Added interactive Stage 1 timeline HTML

**Changed files:**
- `outputs/attempt-002/stage1-timeline.html`
- `scripts/build_stage1_timeline_html.py`
- `log.md`

**What changed:**
- Generated a self-contained interactive HTML timeline from `outputs/attempt-002/stage1-date-adjusted.json`.
- Added wavy left-to-right SVG curves for official memorial sending, emperor replies, and imperial 上諭.
- Added click-to-inspect daily actor statistics grouped by official/addressee.
- Added graph zoom controls and trackpad/pinch-style zoom handling.
- Changed daily actor details to show document titles directly; 硃批 titles include sent date, received date, and day difference.

**Reason:**
- To visually explore the timing of official reports and imperial responses during the first stage of the 林爽文 war.

### 2026-06-24 — Recorded Claude adjustment to attempt-002 timeline HTML

**Changed files:**
- `research-attempts/attempt-002-lin-shuangwen-early-stages.md`
- `log.md`

**Observed HTML file:**
- `outputs/attempt-002/stage1-timeline.html`

**What changed in the HTML:**
- Claude's 2026-06-23 update turned the timeline into a two-mode workspace: the original `曲線總覽` plus a new `雙線・發送↔回覆` view.
- The dual view separates official sending dates from imperial response / announcement dates, making `硃批` readable as a send-to-receive interval.
- Added filters for document type, sender, and full-text search across source text, titles, rescripts, and summaries.
- Added a record drawer with original text, rescript, structured summary table, and interactive quote-highlighting against the source text.
- Added browser-local notes and editable summary fields stored in `localStorage`, with JSON export/import as `timeline-edits.json`.
- Added optional Gemini proxy controls for further summary, text division, and document-level questions.

**Reason:**
- To update the wiki's description of attempt 002 so the HTML is treated as a close-reading and annotation workspace, not just a static or aggregate chronology chart.

### 2026-06-24 — Recorded latest Claude workspace update to attempt-002 timeline HTML

**Changed files:**
- `log.md`

**Observed HTML file:**
- `outputs/attempt-002/stage1-timeline.html`

**What changed in the HTML:**
- Claude's latest update further reworked the `雙線・發送↔回覆` view from a single chart-plus-drawer interface into a docked workspace with the chart and one or more card-list columns.
- Added a `人物` filter that treats `上奏` / `硃批` by sender and `上諭` by recipient, with multiple filter rows combinable by `且` / `或`.
- Added workspace controls for global font size (`A−` / `A+`), global edit export/import, hide/show timeline chart, and adding extra card columns.
- Added card-based document panels that can be opened from timeline records, stacked into columns, folded, pinned, dragged/reordered, and used for side-by-side close reading.
- Expanded the earlier drawer concept with resizable edges and also added multi-panel/card UI classes for persistent research windows.
- Added a frozen date ruler with Chinese/Arabic date labels and clickable date ticks.
- Added support for recipient metadata (`recipients`) in the embedded record data, especially for `上諭` filtering and display.
- Expanded AI settings from a simple proxy URL into model selection and custom prompt buttons stored in browser `localStorage`.
- Added persistent UI preferences such as workspace font size and note mode, alongside the existing browser-local notes, highlights, and JSON export/import.

**Reason:**
- To preserve the latest interface semantics in the wiki log: the attempt-002 HTML is now not only an exploratory timeline, but a multi-document reading desk for comparing several records and annotations at once.

### 2026-06-24 — Implemented highlight label display toggle in attempt-002 timeline

**Changed files:**
- `outputs/attempt-002/stage1-timeline.html`
- `log.md`

**What changed:**
- Made the existing `標註：右側` / `標註：行內` toggle functional.
- Kept the current right-side note layout as the default: highlighted text remains in the body, and the label/summary appears in the right margin.
- Added an inline full-width mode: the body text expands to the full panel width, the selected text remains highlighted, and the label/summary is inserted directly under the highlighted text as a full-width line that breaks the paragraph.
- Stored the user's chosen display mode in browser `localStorage` through the existing `noteMode` key.

**Reason:**
- To give readers two ways to inspect highlight labels: a compact right-margin mode for overview reading, and a full-width inline mode for close reading when the annotation should appear directly in the textual flow.

### 2026-06-24 — Fixed sticky dot tooltip in attempt-002 timeline

**Changed files:**
- `outputs/attempt-002/stage1-timeline.html`
- `log.md`

**What changed:**
- Hid the dual-timeline dot hover tooltip immediately when a dot is clicked.
- Also clears the tooltip just before the clicked record opens, preventing the hover label from lingering above the card workspace.

**Reason:**
- To keep hover labels transient: after a record is selected, the opened card/panel should carry the information, not the dot tooltip.

### 2026-06-24 — Updated info-panel body editing and label grouping

**Changed files:**
- `outputs/attempt-002/stage1-timeline.html`
- `log.md`

**What changed:**
- Allowed direct editing of the original body text in the annotation panel by clicking the plain body text itself, while preserving highlight-click editing and text-selection behavior.
- Kept the pencil button as an alternate way to enter original-text editing.
- Changed annotation filter chips to group AI labels by their base category before `・`; for example, multiple `情報來源・...` highlights now appear as `情報來源 2`.
- User-created labels remain grouped by their full custom label.

**Reason:**
- To make original-text correction as direct as summary correction, and to keep the label toolbar compact when a category has several source-specific highlights.

### 2026-06-24 — Added floating workspace Note and AI tools

**Changed files:**
- `outputs/attempt-002/stage1-timeline.html`
- `log.md`

**What changed:**
- Removed the visible per-card bottom `筆記` / `AI` footer from info-panel cards.
- Added global floating `Note` and `AI` buttons for the card workspace.
- Let the floating button pair dock to the left, right, top, or bottom side of the workspace; the opened panel appears from the same side.
- Added scope controls for `All`, `Single`, and `Some` cards.
- In `Single` / `Some` scope, clicking cards selects the target card set and marks selected cards with a green outline.
- Implemented shared group notes: one note is saved for the selected/opened document group rather than copied into each individual document.
- Implemented combined multi-document AI requests: selected/opened cards are sent together in one payload containing each document's id, type, title, body, rescript, summary, and notes.
- Stored shared notes and combined AI responses in the exported timeline edits object under a workspace-level group area.

**Reason:**
- To turn Note and AI into workspace-level comparison tools for multiple open documents, instead of repeating the same controls at the bottom of every card.

### 2026-06-24 — Made floating Note and AI tools movable and resizable

**Changed files:**
- `outputs/attempt-002/stage1-timeline.html`
- `log.md`

**What changed:**
- Changed the floating `Note` and `AI` controls into round pet-like buttons.
- Made the two buttons draggable together as a pair, with their position saved in browser `localStorage`.
- The floating panel now opens near the button pair from the nearest side: right-side placement opens right-to-left, bottom placement opens bottom-to-top, etc.
- Changed the floating panel from full-height / full-width side sheets into a smaller floating panel.
- Allowed the floating panel to be dragged by its header and resized by the browser resize handle, with panel position saved separately.
- Kept the side snap controls as quick positioning options, but free movement is now the main interaction.

**Reason:**
- To make the Note/AI workspace feel like a movable assistant tool rather than a page-level drawer, while keeping the panel compact and adjustable.

### 2026-06-24 — Restored division prompt in floating AI panel

**Changed files:**
- `outputs/attempt-002/stage1-timeline.html`
- `log.md`

**What changed:**
- Restored the `分段標註` button inside the floating AI panel after the per-card AI footer was removed.

**Reason:**
- To preserve the existing division/part-prompt workflow in the new floating AI interface.

### 2026-06-25 — Adjusted timeline ruler and info-panel headers

**Changed files:**
- `outputs/attempt-002/stage1-timeline.html`
- `log.md`

**What changed:**
- Increased and retuned the frozen left ruler spacing so month/year labels no longer collide with small day-number labels.
- Renamed the dual timeline side headers from `官員發送　上奏・硃批送出日` / `皇帝硃批回覆・上諭頒佈日` to `官員上奏` / `皇帝硃批下旨`.
- Added responsive short labels: narrow windows show `上奏` / `硃批下旨`.
- Reworked each info-panel header into a compact metadata table with title, person, send/response date, lag, and source rows.
- Added a draggable bottom handle on info-panel headers; dragging it changes a shared header-height setting for all cards.
- Saved the shared header height in browser `localStorage`.

**Reason:**
- To reduce visual overlap in the timeline, make the two communication directions easier to read, and let readers control how much metadata each card header displays.

### 2026-06-25 — Read current Claude-updated attempt-002 timeline workspace

**Changed files:**
- `log.md`

**Observed HTML file:**
- `outputs/attempt-002/stage1-timeline.html`

**What changed in the HTML:**
- Confirmed the file now embeds a two-tab interface: `曲線總覽` for the aggregate curve timeline and `雙線・發送↔回覆` for the full-screen reading workspace.
- Confirmed the dual view has type filters, chained person filters using `且` / `或`, full-text search, zoom controls, font-size controls, chart hide/show, and global edit export/import.
- Confirmed the workspace can open multiple document cards from timeline records for side-by-side reading; cards support folding, pinning, dragging, resizing, column docking, source/body editing, structured-summary editing, and annotation display.
- Confirmed the annotation layer can show AI-derived quote highlights, user-created highlights, division backdrops, editable labels, right-margin or inline annotation placement, and saved local notes.
- Confirmed the floating `Note` and `AI` tools now operate at workspace scope, including `單一` / `部分` / `全部` card selection, shared group notes, custom prompt storage, Gemini model/proxy settings, multi-document AI requests, and `分段標註`.
- Confirmed browser-local state is saved in `localStorage` and exported/imported through `timeline-edits.json`; exported edits should still be reviewed before being promoted into canonical source or wiki files.

**Reason:**
- To record the current Claude-updated HTML as an active research desk for close reading, annotation, and multi-document comparison, not only as a generated visualization.

### 2026-06-22 — Generated 10 上奏 summaries with Gemini 3.5 Flash

**Changed files:**
- `outputs/attempt-002/stage1-shangzou-summaries-check10-gemini35.json`
- `scripts/summarize_stage1_shangzou_vertex.py`
- `log.md`

**What changed:**
- Confirmed `gemini-3.5-flash` works through Vertex AI in the `global` location.
- Generated 10 check summaries for Stage 1 `上奏` records using the revised schema.
- Increased output-token budget support in the summarization script for Gemini 3.5 Flash.

**Reason:**
- To test whether Gemini 3.5 Flash gives better summaries before rerunning the full Stage 1 `上奏` set.

### 2026-06-22 — Generated 5 revised 上奏 summary examples

**Changed files:**
- `outputs/attempt-002/stage1-shangzou-summaries-check5-gemini35-v2.json`
- `scripts/summarize_stage1_shangzou_vertex.py`
- `log.md`

**What changed:**
- Revised the summary schema to make each document easier to distinguish.
- Changed `sources_of_information` into a list so multiple sources can be named separately.
- Added `major_locations` with situation summaries and quotations.
- Generated 5 Gemini 3.5 Flash examples for review.

**Reason:**
- To test the improved schema before rerunning the full Stage 1 `上奏` summary batch.

### 2026-06-22 — Generated 5 硃批 summary examples

**Changed files:**
- `outputs/attempt-002/stage1-zhupi-summaries-check5-gemini35.json`
- `scripts/summarize_stage1_shangzou_vertex.py`
- `log.md`

**What changed:**
- Added `--doc-type` support to the Gemini summarization script.
- Generated 5 Stage 1 `硃批` examples with `send_date` and `receive_date` in `source_record`.
- Added an `emperor_reply` field for `硃批` records.
- Added `days_between_send_and_receive` below `receive_date`.

**Reason:**
- To test the revised summary schema on imperial rescript records before processing the whole `硃批` set.

### 2026-06-22 — Generated 5 上諭 summary examples

**Changed files:**
- `outputs/attempt-002/stage1-shangyu-summaries-check5-gemini35.json`
- `scripts/summarize_stage1_shangzou_vertex.py`
- `log.md`

**What changed:**
- Added a dedicated `上諭` prompt path to the Gemini summarization script.
- Generated 5 Stage 1 `上諭` examples with `announce_date` in `source_record`.
- Added fields for key information, the message being answered, emperor opinion, emperor command, and major locations.

**Reason:**
- To test the summary schema for imperial orders before processing the whole `上諭` set.

### 2026-06-22 — Added summary skills for 上奏 and 硃批

**Changed files:**
- `skills/summarize-shangzou.md`
- `skills/summarize-zhupi.md`
- `index.md`
- `folder-structure.md`
- `log.md`

**What changed:**
- Added reusable skill pages for summarizing `上奏` and `硃批` records.
- Recorded required JSON layouts, evidence rules, date rules, and common errors.
- Linked the skills from the wiki index and folder structure pages.

**Reason:**
- To make future LLM summarization runs consistent before processing the full Stage 1 corpus.
