# Source 001

Related pages: [[index]], [[source-materials]], [[workflows]], [[folder-structure]], [[outputs/source-001/processing-notes]]

## Purpose

This page is the hub for `source-001`, the first processed source in this LLM Wiki. It connects the raw source, OCR, cleaned text, TEI, NLP outputs, GIS outputs, network outputs, and external enrichment notes.

## Source Record

Read [[source-materials]] for the bibliographic record, reliability notes, and unresolved metadata questions.

The source is a Traditional Chinese article page about 章太炎 and 孫中山. Bibliographic metadata remains partially unverified, so do not invent publication year, publisher, complete page range, or stable identifier.

## Core Processing Notes

- [[outputs/source-001/processing-notes]] records the full processing history.
- Raw source files live in `raw/source-001/`.
- OCR files live in `ocr/source-001/`.
- Cleaned text lives in `cleaned/source-001/`.
- Derived outputs live in `outputs/source-001/`.

## Main Artifacts

### Text and TEI

- `cleaned/source-001/source-001.cleaned.txt`
- `outputs/source-001/source-001.tei.xml`

Use [[skills/tei-encoding]] before revising TEI markup.

### Entity Extraction

- `outputs/source-001/source-001.entities.verified.csv`
- `outputs/source-001/source-001.entities.cleaned.csv`
- `outputs/source-001/source-001.entities.errors.csv`
- OCR-preserved versions are also kept under `outputs/source-001/` with `.ocr.` in the filename.

Use [[extraction-rules]], [[examples]], [[known-errors]], and [[skills/nlp-analysis]] before changing extraction outputs.

### NLP Outputs

- [[outputs/source-001/source-001.nlp-summary]]
- `outputs/source-001/source-001.nlp-segments.csv`
- `outputs/source-001/source-001.nlp-tags.csv`
- `outputs/source-001/source-001.nlp-topics.csv`
- `outputs/source-001/source-001.nlp-classification.csv`

The NLP pass is TEI-derived and rule-based. Do not describe it as a statistical topic model or unreviewed research conclusion.

### GIS Outputs

- [[outputs/source-001/chgis-enrichment]]
- `outputs/source-001/source-001.gazetteer.csv`
- `outputs/source-001/source-001.chgis-places.csv`
- `outputs/source-001/source-001.cbdb-chgis.geojson`

Use [[skills/historical-gis]] before changing gazetteer or map-ready outputs.

### Network Outputs

- [[outputs/source-001/cbdb-enrichment]]
- [[outputs/source-001/map-network-cross-reading]]
- `outputs/source-001/source-001.network-nodes.csv`
- `outputs/source-001/source-001.network-edges.csv`
- `outputs/source-001/source-001.cbdb-network-nodes.csv`
- `outputs/source-001/source-001.cbdb-network-edges.csv`
- `outputs/source-001/source-001.cbdb-network.gexf`

Use [[skills/network-analysis]] before changing node or edge lists.

## Interpretation Rules

- Keep source-derived claims separate from CBDB, CHGIS, and TGAZ enrichment.
- Preserve uncertainty where metadata, normalization, or place matching remains unresolved.
- Do not infer relationships, routes, residences, or geographic clustering unless the evidence explicitly supports them.
- Prefer reviewed artifacts over raw OCR outputs for analysis, but keep OCR-derived files for provenance.
