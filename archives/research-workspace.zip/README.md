# LLM Wiki for Sinitic Texts

This repository is a working knowledge base for AI-assisted digital humanities work on Sinitic / Chinese historical and humanities texts.

Start with [`index.md`](index.md) for the wiki landing page and suggested reading paths.

## Run and Share the Review Website

This repository contains a local review website as well as the wiki. A teammate
can run the complete local workspace by following [`LOCAL_SETUP.md`](LOCAL_SETUP.md).
It explains which folders are required, how to start the app, and how the
optional Gemini-assisted tools are configured without committing credentials.

## Important Files

- [`AGENTS.md`](AGENTS.md): Instructions for AI coding and research agents.
- [`project-overview.md`](project-overview.md): Project purpose and overview.
- [`terminology.md`](terminology.md): Key terms and usage rules.
- [`source-materials.md`](source-materials.md): Source records, reliability, and citation rules.
- [`extraction-rules.md`](extraction-rules.md): Rules for structured extraction.
- [`prompt-rules.md`](prompt-rules.md): Prompt templates and prompt-writing rules.
- [`examples.md`](examples.md): Good and bad AI output examples.
- [`known-errors.md`](known-errors.md): Repeated AI errors and prevention rules.
- [`workflows.md`](workflows.md): Repeatable project workflows.

## Language Note

Use English by default. Use Traditional Chinese only when Chinese is needed.

## Safety Warning

Do not store API keys, access tokens, passwords, or private credentials in this repository.
