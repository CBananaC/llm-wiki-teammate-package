# Research Questions

Related pages: [[index]], [[project-overview]], [[source-materials]], [[extraction-rules]], [[workflows]], [[log]]

## Purpose

This page records developing research objects, possible research questions, and open problems for the project.

These notes are provisional. They should help future humans and AI assistants understand what the project is trying to investigate without treating an early idea as a finished argument.

## Research Object 1 — Wartime communication between the Qing central government and frontline military

### Working topic

Examine communication during war between the Qing central government and military actors on the frontline, using official records connected to a specific warfare case.

### Current formulation

This topic is still unspecific and needs further development.

At present, the core interest is:

- how information moved between the Qing court / central government and frontline commanders;
- how battlefield reports, requests, orders, memorials, edicts, or other official communications shaped wartime decision-making;
- how official records represent communication delays, misunderstandings, command hierarchy, responsibility, and military urgency;
- how the center understood frontline conditions through documents, and how frontline actors framed events for the center.

### Possible research questions

- What channels of communication connected the Qing central government with commanders or officials on the frontline during a specific war?
- What kinds of information were reported upward from the front, and what kinds of orders or responses came downward from the center?
- How did time delay, distance, geography, or administrative procedure affect military communication?
- How did frontline actors describe battlefield conditions, enemy movements, logistics, casualties, morale, or local society in official records?
- How did the central government evaluate, correct, reward, punish, or redirect frontline military actors through written communication?
- Do official records reveal moments of miscommunication, strategic disagreement, information filtering, or rhetorical self-protection?

### Source direction

Likely source types include official Qing records from a defined warfare case, such as:

- memorials and palace memorials;
- imperial edicts or rescripts;
- military reports;
- campaign records;
- court compilations;
- local official reports connected to military administration;
- archival records, if available.

The exact war, corpus, edition, and archive are not yet selected.

### Data and extraction possibilities

If a suitable corpus is identified, useful structured fields may include:

| Field | Description |
| --- | --- |
| Date | Date of communication, report, order, or event. |
| Sender | Person or office sending the communication. |
| Recipient | Person, office, emperor, court body, or military command receiving it. |
| Place | Place of writing, reception, battlefield event, or administrative jurisdiction. |
| Document type | Memorial, edict, report, order, rescript, campaign entry, etc. |
| Communication direction | Frontline to center, center to frontline, lateral communication, or unclear. |
| Military issue | Logistics, battle report, troop movement, command dispute, intelligence, casualties, supplies, punishment, reward, etc. |
| Evidence passage | Original wording supporting the extracted entry. |
| Uncertainty | Ambiguities in dating, sender, recipient, place, or interpretation. |

### Method notes

- Keep source evidence separate from interpretation.
- Do not assume that official records transparently describe battlefield reality.
- Track rhetoric and bureaucratic framing, not only factual content.
- Preserve original Chinese wording for key terms, titles, offices, and communication verbs.
- Mark uncertain dates, places, ranks, and institutional roles instead of normalizing too early.

### Open decisions

- Which Qing war or military campaign should be selected?
- Which official records are available and suitable for close reading or structured extraction?
- Should the project focus on one campaign, one commander, one communication route, or one type of document?
- Should the main output be a narrative analysis, a communication network, a timeline, a map, or a combined digital humanities dataset?
- Which terms should be used for “central government,” “frontline,” “military,” and “official records” in the final research framing?

## Research Object 2 — 林爽文事件 as a staged communication and command problem

### Working topic

Use the 林爽文事件 first-hand document corpus to study how Qing wartime command changed across different stages of the war.

### Current formulation

The first attempt focused heavily on 福康安 and the final stage of the war. The second attempt begins again from the earlier stages, especially the 黃仕簡、任承恩分路渡臺 stage, to understand how the initial command and communication system failed before 福康安 became the solution.

### Related pages

- [[corpora/lin-shuangwen-first-hand-json]]
- [[background/lin-shuangwen-war-stages]]
- [[research-attempts/attempt-002-lin-shuangwen-early-stages]]

### Current question

How did early Qing reports, imperial responses, and command arrangements turn the 林爽文事件 from an apparently suppressible local disturbance into a war requiring exceptional intervention by 福康安?
