# Lin Shuangwen War Stages

Related pages: [[index]], [[background/research-questions]], [[corpora/lin-shuangwen-first-hand-json]], [[research-attempts/attempt-002-lin-shuangwen-early-stages]]

## Purpose

This page records the working stage model for the 林爽文事件 research.

The stage model is a research scaffold, not a final argument. It helps future attempts compare documents from the same war without treating the 福康安 stage as the whole war.

## Working three-stage model

The previous draft material divided the war into three broad stages:

| Stage | Working label | Approximate boundary | Core problem |
| --- | --- | --- | --- |
| 1 | 黃仕簡、任承恩分路渡臺階段 | roughly 乾隆五十一年十一月至乾隆五十二年三月 | Qing court underestimates the crisis and relies on two Fujian commanders without effective unified command. |
| 2 | 常青、藍元枚督剿階段 | roughly 乾隆五十二年三月至十一月 | The court tries to rebuild command, but the battlefield remains split among 府城, 鹿仔港, and 諸羅. |
| 3 | 福康安統兵反攻階段 | command transition begins around 乾隆五十二年九月; battlefield breakthrough after 福康安 reaches Taiwan | Qing forces concentrate trusted commanders and cross-provincial troops, relieve 諸羅, attack 大里杙, and capture 林爽文 / 莊大田. |

## Stage 1 — 黃仕簡、任承恩分路渡臺

Stage 1 begins with the early shock of the rebellion and Qing attempts to respond through existing Fujian military resources.

Working features:

- 黃仕簡 and 任承恩 are expected to form a south-north converging attack.
- The court appears to assume that dispatching Fujian water and land commanders can quickly suppress the rebellion.
- In practice, the command structure is weak: the two senior commanders do not form a unified operational center.
- 清軍 activity becomes divided among 府城, 鹿仔港, 諸羅, 鳳山, and other nodes.
- 柴大紀 becomes important as a field actor, but this does not yet solve the strategic problem of 大里杙.

Analytical value for the communication project:

- This stage can show how the court first learned the scale of the war.
- It can reveal early misjudgment, fragmented reporting, and the absence of a trusted single commander.
- It is a good place to compare imperial expectations with what reports from Taiwan and Fujian actually show.

## Stage 2 — 常青、藍元枚督剿

Stage 2 begins when the court tries to correct the first stage by reorganizing command around 常青, with 藍元枚 supporting the 鹿仔港 and water-route side.

Working features:

- 乾隆 attempts to rebuild a clearer command hierarchy.
- 常青 is expected to coordinate Taiwan-wide operations.
- 藍元枚 becomes crucial for 鹿仔港, water transport, reinforcements, and supply.
- The battlefield remains divided: 府城 is pressured, 鹿仔港 must be held, and 諸羅 becomes increasingly critical.
- The war becomes a problem of stalled reinforcements, blocked roads, supply, and delayed information.

Analytical value for the communication project:

- This stage may show how central command reacts when the first strategy fails.
- It can reveal repeated reinforcement without decisive concentration.
- It is the transition zone between ordinary provincial response and the later 福康安 exceptional intervention.

## Stage 3 — 福康安統兵反攻

Stage 3 is the stage previously studied most closely.

Working features:

- 乾隆 loses confidence in 常青 and sends 福康安, 海蘭察, and other trusted commanders.
- The court mobilizes cross-provincial forces beyond Fujian.
- 福康安 chooses 鹿仔港 as the landing and operational entry point.
- The campaign shifts from dispersed defense to concentrated breakthrough: 鹿仔港 → 諸羅 → 斗六門 / 大里杙 → inner mountain pursuit.
- 福康安’s local judgment interacts with, but does not simply follow, delayed imperial orders.

Analytical value for the communication project:

- This stage provides the clearest cases of information delay and imperial strategic adjustment.
- It should remain available for comparison, but the second attempt should not let it dominate the whole war again.

## Research cautions

- The stage labels are working categories, not fixed periodization.
- Some documents may belong to a transition rather than one clean stage.
- The 福康安 command transition begins before his effective battlefield breakthrough, so future notes should distinguish appointment / planning / arrival / action.
- Dates should preserve Qing reign-date wording unless converted and verified separately.
