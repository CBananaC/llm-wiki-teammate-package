# Lin Shuangwen First-Hand JSON Corpus

Related pages: [[index]], [[source-materials]], [[background/lin-shuangwen-war-stages]], [[research-attempts/attempt-002-lin-shuangwen-early-stages]]

## Purpose

This page records the reusable first-hand source corpus for research on the 林爽文事件.

The corpus should be treated as shared research infrastructure. Individual research attempts should cite or link to this page instead of repeating the same corpus description.

## Main dataset

**Local file:** `/Users/creamybanana/Downloads/林爽文/Final Drive Copy/奏摺上諭結構化數據.json`

**Format:** JSON

**Record count checked on 2026-06-22:** 1,834 records

**Top-level fields observed:**

- `doc_id`
- `series`
- `doc_type`
- `subtype`
- `compiled_in`
- `archive_reference`
- `author`
- `title`
- `send_date`
- `receive_date`
- `announce_date`
- `issue_date`
- `body`
- `rescript_text`

## Series represented

Checked from the JSON on 2026-06-22:

| Series | Count |
| --- | ---: |
| 明清台灣檔案匯編 | 1,396 |
| 天地會 | 438 |

## Document types represented

Checked from the JSON on 2026-06-22:

| Document type | Count |
| --- | ---: |
| 上奏 | 727 |
| 硃批 | 559 |
| 上諭 | 438 |
| 其他 | 57 |
| 移咨 | 53 |

## Important caution

The JSON is analysis-ready for searching, clustering, and source selection, but it should not automatically be treated as final citation text.

On 2026-06-22, date fields in the original JSON were cleaned and renamed by document type:

- `上奏`: uses `send_date`.
- `硃批`: uses `send_date` and `receive_date`.
- `上諭`: uses `announce_date`.
- Remaining `移咨` and `其他` records may still use `issue_date`.
- Date values are `[Chinese date, Arabic date]` pairs.
- `上諭` dates were filled by matching `title` against `/Users/creamybanana/Downloads/林爽文/林爽文Final/（3）原始史料統計/奏摺上諭名單.xlsm`, reading the western date from the `西歷日期` column, and mechanically converting it to a Qianlong Chinese date.

For formal quotation or footnote use:

- check the relevant source record;
- preserve the original wording;
- distinguish `send_date`, `receive_date`, `announce_date`, and remaining `issue_date`;
- mark estimated or uncertain dates clearly;
- verify page references against the underlying printed compilation when possible.

## Suggested use

This corpus is especially useful for:

- reconstructing information flow between Taiwan, Fujian, and Beijing;
- tracking delay between memorial dates and rescript or issue dates;
- comparing upward reports with downward imperial orders;
- studying changing imperial strategy across war stages;
- selecting source clusters for close reading.

## Reusable extraction fields

Future research attempts using this corpus should normally preserve these fields:

| Field | Use |
| --- | --- |
| `doc_id` | Stable reference key for internal cross-reference. |
| `series` | Distinguishes source series. |
| `doc_type` | Separates 上奏, 硃批, 上諭, 移咨, and other records. |
| `author.name` | Identifies sender, compiler, or issuing authority as recorded. |
| `author.position` | Preserves official title when present. |
| `title` | Gives initial topic clue. |
| `send_date` | Upward reporting chronology for `上奏` and the memorial side of `硃批`. |
| `receive_date` | Emperor receipt/reply chronology for `硃批`. |
| `announce_date` | Imperial announcement/order chronology for `上諭`. |
| `issue_date` | Remaining issue date for document types not yet normalized away from this field. |
| `body` | Main evidence text. |
| `rescript_text` | Imperial response text for 硃批 records. |

## Open questions

- Which date field should be treated as the primary chronological axis for each document type?
- Which records need manual correction against printed source pages?
- Should derived attempt-specific subsets be stored under `outputs/` or under a separate `datasets/` folder?
