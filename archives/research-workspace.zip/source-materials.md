# Source Materials

## Purpose of This Page

This page records the sources available to the project, their status, reliability, format, and rules for using them. For extraction from these sources, see [[extraction-rules]].

Use this page so AI assistants know what sources exist, what they may be used for, and what must not be assumed. AI agents should also follow [[AGENTS]].

## General Source Rules

- Do not invent source titles.
- Do not invent citations.
- Do not assume a source contains information unless it is listed or provided.
- Distinguish between primary sources, reference works, datasets, and secondary scholarship.
- Preserve original wording when quoting or transcribing.
- If source text is missing, ask the user to provide it.
- If a source is uncertain or incomplete, mark it clearly.
- Do not silently correct, modernize, or translate source text unless asked. Record repeated violations in [[known-errors]].
- For Chinese sources and source materials, format citations according to `/Users/creamybanana/Documents/Poly Info/中文論文格式.pdf`.

## Source Categories

### Primary Sources

Primary sources are historical or original texts used as evidence. See [[terminology]] for related project terms.

Possible examples:

- Gazetteers
- Genealogies
- Archival records
- Memorials
- Official documents
- Literary texts
- Commentaries
- Stone inscriptions
- Manuscripts

### Reference Works

Reference works help identify terms, names, places, dates, or background information.

Possible examples:

- Dictionaries
- Biographical databases
- Chronological tables
- Place-name databases
- Bibliographies

### Datasets

Datasets are structured data used for analysis. See [[workflows]] for repeatable processing steps.

Possible examples:

- CSV files
- JSON files
- TEI XML files
- Extracted entity tables
- OCR output files
- Metadata spreadsheets

### Secondary Scholarship

Secondary scholarship includes modern academic articles, books, theses, and research notes.

Rules:

- Do not cite scholarship unless the source is available.
- Do not invent page numbers.
- Separate the author's argument from the project's interpretation.

## Source Record Template

### Source: [Source title]

**Source type:**  
[Primary source / reference work / dataset / secondary scholarship]

**Language/script:**  
[Classical Chinese / Traditional Chinese / Simplified Chinese / English / mixed]

**Format:**  
[PDF / TXT / CSV / JSON / XML / image / website / database]

**Location:**  
[Local path, URL, repository, or description]

**Status:**  
[Raw / cleaned / OCRed / manually checked / partially checked]

**Reliability notes:**  
[Known issues, OCR quality, edition issues, missing pages, uncertain metadata]

**Allowed AI use:**  
[What the AI may use this source for]

**Restrictions:**  
[What the AI must not do with this source]

**Citation rule:**  
[How to cite or refer to this source]

## Current Sources

### Source: lin-shuangwen-first-hand-json — 林爽文事件奏摺上諭結構化數據

**Source type:**  
Dataset / structured first-hand source corpus

**Language/script:**  
Traditional Chinese / mixed metadata

**Format:**  
JSON

**Location:**  
`/Users/creamybanana/Downloads/林爽文/Final Drive Copy/奏摺上諭結構化數據.json`

**Status:**  
Analysis-ready for searching and grouping / not fully verified for formal quotation

**Observed contents:**  
Checked on 2026-06-22: 1,834 records. The `series` field contains 1,396 records from `明清台灣檔案匯編` and 438 records from `天地會`. Document types include `上奏`, `硃批`, `上諭`, `移咨`, and `其他`.

**Related corpus page:**  
[[corpora/lin-shuangwen-first-hand-json]]

**Allowed AI use:**  
AI may use this JSON to search, group, count, and select first-hand documents for close reading; to reconstruct document chronology; and to propose extraction subsets.

**Restrictions:**  
Do not treat the JSON alone as final checked transcription for formal quotation. Do not silently choose between `memorial_date`, `rescript_date`, and `issue_date`; record which date field is being used. Verify quotations and page references against the underlying source when needed.

**Citation rule:**  
For internal wiki work, cite by `doc_id` plus document type, author, and date field used. For formal writing, cite the underlying source compilation after verification.

### Source: user-source-1 — 《明清臺灣檔案彙編》，第貳輯，第三十冊

**Source type:**  
Primary source / published archival compilation

**Language/script:**  
Traditional Chinese

**Editor:**  
臺灣史料集成編輯委員會

**Publication:**  
《明清臺灣檔案彙編》，第貳輯，第三十冊

**Chronological coverage printed on cover:**  
清乾隆五十二年十二月至五十三年三月

**Publisher page information:**  
發行單位：中華文化復興運動總會。出版單位：中華文化復興運動總會、國立臺灣大學圖書館、遠流出版事業股份有限公司。出版地：臺北。出版日期：2006年12月20日。ISBN 13：978-986-00-7171-9（第30冊，精裝）。

**Format:**  
PDF

**Location:**  
`/Users/creamybanana/Downloads/Source /明清台灣檔案匯編 30.pdf`

**Status:**  
Raw / publisher page visually checked / Finder pages 43-47 OCRed by Google Cloud Document AI

**Reliability notes:**  
Bibliographic details above are taken from the publisher page visible inside the supplied PDF. The file title uses `明清台灣檔案匯編`, while the printed title page uses the traditional form `明清臺灣檔案彙編`; use the printed title for citation. Finder pages 43-47 have Google Cloud Document AI OCR outputs, but these have not yet been manually verified. Page-level quotations must be checked against the PDF image before use.

**Allowed AI use:**  
AI may use this source as a first-hand historical source after checking the relevant page images or reliable transcription. AI may use the publisher page for citation metadata.

**OCR workflow:**  
Use [[skills/material-1-google-cloud-ocr]] for Google Cloud OCR of this book. Finder/PDF page numbers must be distinguished from printed page numbers.

**OCR outputs:**  
For Finder pages 43-47, see `ocr/user-source-1/user-source-1-finder-pages-043-047.ocr.txt`, `ocr/user-source-1/user-source-1-finder-pages-043-047.docai.combined.json`, and [[outputs/user-source-1/processing-notes]].

**Cleaned text outputs:**  
For cleaned document-level TXT from Finder pages 43-47, see `cleaned/user-source-1/user-source-1-finder-pages-043-047.cleaned.txt`. For structured JSON with `文首日期`, see `cleaned/user-source-1/user-source-1-finder-pages-043-047.cleaned.json`. These files include appended Gregorian dates for repeated Qianlong 51 date strings, with Sinocal verification still recommended when available.

**Extraction outputs:**  
For official posts and personal names extracted from `正文` only, see `outputs/user-source-1/user-source-1-finder-pages-043-047.body-officials-persons.json`.

**Reported-message outputs:**  
For a document-level summary of what each text reports and the source of the reported message, see `outputs/user-source-1/user-source-1-finder-pages-043-047.reported-message-sources.json`.

**Restrictions:**  
Do not cite unverified page numbers, do not silently normalize original archival wording, and do not treat AI OCR text as verified transcription without visual checking.

**Reference list entry:**  
臺灣史料集成編輯委員會編，《明清臺灣檔案彙編》，第貳輯，第30冊。臺北：中華文化復興運動總會、國立臺灣大學圖書館、遠流出版事業股份有限公司，2006。

**Citation rule:**  
Initial footnote: 臺灣史料集成編輯委員會編，《明清臺灣檔案彙編》（臺北：中華文化復興運動總會、國立臺灣大學圖書館、遠流出版事業股份有限公司，2006），第貳輯，冊30，頁碼。  
Subsequent footnote: 臺灣史料集成編輯委員會編，《明清臺灣檔案彙編》，冊30，頁碼。

`source-001` is registered below. Metadata visible on the supplied page has been checked, but the publication year, publisher, and complete article page range still require verification.

### Source: source-001 — 道不同終不相為謀：論章太炎與孫中山革命思想的異趣

**Source type:**  
Secondary scholarship / journal article abstract page

**Language/script:**  
Traditional Chinese

**Author:**  
汪榮祖

**Publication:**  
《思想史》, issue or volume designation `7` as printed in the page header

**Page:**  
Printed page `2`; the complete article page range is not yet known

**Format:**  
PDF

**Location:**  
`raw/source-001/`

**Status:**  
Cleaned / TEI encoded / GIS and network artifacts created / citation partially verified

**Reliability notes:**  
The one-page PDF, raw OCR text, visually checked cleaned transcription, reviewed entity extraction outputs, and validated minimal TEI XML are available. The extraction was rerun against the corrected transcription. The title, author, `思想史 7` header, and printed page number are visible on the supplied page. The publication year, publisher, complete article page range, and stable catalog identifier have not been verified. The embedded PDF metadata is unreliable and must not be used for citation.

**Allowed AI use:**  
AI may inspect and process the available source file and OCR text. AI-generated entities must be reviewed before use as research evidence.

**External enrichment:**  
CBDB person IDs `75900` (孫文 / 孫中山) and `88996` (章炳麟 / 章太炎) were matched through the official CBDB API on 2026-06-18. Their CBDB addresses were matched through CHGIS/TGAZ to `hvd_42226` (香山縣) and `hvd_40085` (余杭縣). External database claims are stored separately under `outputs/source-001/source-001.cbdb-*` and `outputs/source-001/source-001.chgis-*` and must not be attributed to the article.

**Restrictions:**  
Do not invent the publication year, publisher, issue interpretation, complete page range, stable identifier, or other citation details.

**Citation rule:**  
Until a complete catalog or journal record is found, use only a provisional citation: 汪榮祖, 〈道不同終不相為謀：論章太炎與孫中山革命思想的異趣〉, 《思想史》 7, supplied abstract page, printed p. 2. Mark the publication year and complete page range as unverified.

## Example Source Record

### Source: 新安縣志

**Source type:**  
Primary source / gazetteer

**Language/script:**  
Classical Chinese / Traditional Chinese

**Format:**  
Not yet specified

**Location:**  
To be added

**Status:**  
Not yet verified

**Reliability notes:**  
Edition, page range, and OCR quality must be checked before use.

**Allowed AI use:**  
The AI may use this source only when relevant text is provided or when the source has been registered with reliable metadata.

**Restrictions:**  
Do not invent quotations, page numbers, edition details, or bibliographic information.

**Citation rule:**  
Cite only with verified edition and page information.

## Source Reliability Levels

- **raw**: Not checked.
- **OCRed**: Text extracted but may contain errors.
- **cleaned**: Obvious errors corrected.
- **verified**: Checked against source image or reliable edition.
- **analysis-ready**: Safe for structured extraction or citation with caution.

## When To Update This Page

Update this page when:

- A new source is added
- OCR is completed
- A source is cleaned or verified
- Citation rules are decided
- Source reliability changes
- A source is removed from active use
- A source-related workflow changes in [[workflows]]
