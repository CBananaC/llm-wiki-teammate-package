# Local Website Setup and GitHub Handoff

This repository is the complete local workspace for the 林爽文 review website.
Do **not** upload only `stage1-timeline.html`: it is a user interface that is
served together with saved edits, skills, review bundles, and the local API.

## Quick start (core website)

Prerequisite: Python 3.10 or newer. The review app itself uses only the Python
standard library; no `pip install` is required.

```bash
git clone <REPOSITORY-URL>
cd llm-wiki
python3 review-app/server.py
```

Open <http://127.0.0.1:8766>. Keep that terminal running while reviewing.

The two useful local addresses are:

- `/` — the review bridge, including the saved-prompt Skills and Bundles drawers.
- `/app` — the full timeline directly.

Do not open `outputs/attempt-002/stage1-timeline.html` with `file://` when
collaborating. It can display the embedded timeline, but it cannot persist
large edits to disk or load the shared skills/bundles API.

## Required repository contents

Keep these directories together, with their current relative paths:

```text
llm-wiki/
├── review-app/                  # local Python server and bridge frontend
│   ├── server.py
│   └── static/
├── outputs/
│   ├── attempt-002/             # active timeline HTML, embedded corpus, edits, data
│   └── review-bundles/          # previous batch runs and human-reviewed outputs
├── skills/                      # saved prompts / reusable task specifications
├── raw/                         # original source files
├── ocr/                         # OCR JSON, text, and page images
├── cleaned/                     # cleaned source text and JSON
├── scripts/                     # reproducible batch and transformation scripts
├── gemini-proxy/                # optional AI/geocoding service source
└── *.md                         # project methodology and documentation
```

In particular, commit these active artifacts:

- `outputs/attempt-002/stage1-timeline.html`
- `outputs/attempt-002/timeline-edits.local.json`
- `outputs/attempt-002/stage1-date-adjusted.json`
- `outputs/attempt-002/dual-timeline-data.json`
- all intended `outputs/review-bundles/` runs

`timeline-edits.local.json` is intentionally a checked-in data file, even
though its name includes `.local`: it is the durable shared state of timeline
edits, notes, source chains, and AI-recorded results. The server saves changes
back to this file.

## Optional AI and map functions

The timeline's Gemini extraction/chat and historical-place lookup use a
separate service in `gemini-proxy/`. It is not required to browse, edit, save,
export, or review the bundled results.

For AI tools, either:

1. use the shared Cloud Run proxy URL in the timeline's **Settings** panel; or
2. deploy `gemini-proxy/` in a Google Cloud project the teammate is authorized
   to use, following [`gemini-proxy/README.md`](gemini-proxy/README.md).

The proxy needs Google Cloud credentials and Vertex AI permission. Never commit
service-account files, API keys, `.env` files, or a private proxy URL intended
only for a restricted audience. The app loads Leaflet and vis-network from
public CDNs when the map/relationship-graph panels are opened, and map tiles
come from OpenStreetMap; those optional panels therefore need an internet
connection.

## GitHub publishing checklist

Before the first push, run these commands from `llm-wiki/`:

```bash
git status
git check-ignore -v outputs/attempt-002/timeline-edits.local.json
git ls-files outputs/attempt-002/timeline-edits.local.json
```

The last two commands should produce no ignore rule and should list the edit
file after it is staged/committed. Then review the staged change carefully:

```bash
git add .
git status
git diff --cached --stat
git diff --cached -- . ':!outputs/review-bundles'
```

Do not commit `node_modules/`, Python caches, `.DS_Store`, credentials, or
unintended temporary files. `node_modules/` can be rebuilt only if a developer
needs the archived JSDOM tooling under `outputs/attempt-002/`:

```bash
cd outputs/attempt-002
npm ci
```

No individual file in the current active website exceeds GitHub's 100 MB file
limit. The repository is sizeable because it deliberately includes review
history and large saved timeline edits; use Git LFS later only if future source
files or outputs exceed that per-file limit.

## Collaborative editing note

The app writes edits directly to
`outputs/attempt-002/timeline-edits.local.json`. Two people should not edit the
same shared branch at once: Git cannot reliably merge overlapping changes in a
large JSON state file. Use separate branches, or agree who edits the timeline,
then commit and pull between sessions.

## Minimal smoke test

With the server running, this should return `{"ok": true}`:

```bash
curl http://127.0.0.1:8766/api/health
```

Then open the website, select **Skills** and **Bundles**, and confirm both
drawers load. Make a clearly disposable test edit, refresh the page, and check
that it remains before beginning real work.
