# Google Cloud Info

Use this page for non-secret Google Cloud project details used in this research workflow.

Do not store API keys, OAuth refresh tokens, service-account private keys, access tokens, or passwords here. Put secret values in `.env.local` instead.

Last checked: 2026-06-19

## Project

- Project name: My Project 73170
- Project ID: `delta-entry-496910-e7`
- Project number: `135191006412`
- Parent organization ID: `215845569332`
- Project lifecycle state: `ACTIVE`
- Created: 2026-05-20T10:30:02.560Z
- Billing enabled: yes
- Billing account: configured, exact billing account ID intentionally not stored here

## Default Settings

- Cloud Run region: `asia-east1`
- Compute region: unset
- Compute zone: unset
- Vertex AI location: not set in local `gcloud` config
- Vertex AI API: enabled
- BigQuery datasets: none returned by `bq ls`

## APIs and Services

Enabled services observed:

- `aiplatform.googleapis.com`
- `analyticshub.googleapis.com`
- `artifactregistry.googleapis.com`
- `bigquery.googleapis.com`
- `bigqueryconnection.googleapis.com`
- `bigquerydatapolicy.googleapis.com`
- `bigquerydatatransfer.googleapis.com`
- `bigquerymigration.googleapis.com`
- `bigqueryreservation.googleapis.com`
- `bigquerystorage.googleapis.com`
- `calendar-json.googleapis.com`
- `cloudapis.googleapis.com`
- `cloudbuild.googleapis.com`
- `cloudfunctions.googleapis.com`
- `cloudresourcemanager.googleapis.com`
- `cloudscheduler.googleapis.com`
- `cloudtrace.googleapis.com`
- `containerregistry.googleapis.com`
- `dataform.googleapis.com`
- `dataplex.googleapis.com`
- `datastore.googleapis.com`
- `documentai.googleapis.com`
- `drive.googleapis.com`
- `firebaserules.googleapis.com`
- `firestore.googleapis.com`
- `generativelanguage.googleapis.com`
- `gmail.googleapis.com`
- `iam.googleapis.com`
- `iamcredentials.googleapis.com`
- `logging.googleapis.com`
- `monitoring.googleapis.com`
- `pubsub.googleapis.com`
- `run.googleapis.com`
- `secretmanager.googleapis.com`
- `servicemanagement.googleapis.com`
- `serviceusage.googleapis.com`
- `source.googleapis.com`
- `sql-component.googleapis.com`
- `storage-api.googleapis.com`
- `storage-component.googleapis.com`
- `storage.googleapis.com`
- `telemetry.googleapis.com`
- `translate.googleapis.com`

Research-relevant services:

- Vertex AI API: enabled
- Cloud Storage API: enabled
- BigQuery API: enabled
- Cloud Translation API: enabled
- Document AI API: enabled
- Generative Language API: enabled
- Secret Manager API: enabled

## Authentication Notes

- Local auth method: `gcloud` user/application credentials on this machine
- Active user account: not stored here; run `gcloud auth list` locally if needed
- Secret storage location: `.env.local`

Never paste the content of a JSON service-account key into this page.

## Service Accounts

Observed service accounts:

- Default compute service account: `135191006412-compute@developer.gserviceaccount.com`
- Gemini API Key: `ais-gemini-key-acecd24eaeba46b@135191006412.iam.gserviceaccount.com`
- App Engine default service account: `delta-entry-496910-e7@appspot.gserviceaccount.com`
- Mail Digest SA: `mail-digest-sa@delta-entry-496910-e7.iam.gserviceaccount.com`
- Document AI OCR Runner: `docai-ocr-runner@delta-entry-496910-e7.iam.gserviceaccount.com`

Do not store service-account JSON keys in the wiki.

## Storage Buckets

Observed Cloud Storage buckets:

| Bucket | Location | Notes |
| --- | --- | --- |
| `gs://chinese-test-webapp-1780814096/` | `ASIA-EAST2` | Website bucket; `index.html` and `index.html` not-found page configured. |
| `gs://delta-entry-496910-e7_cloudbuild/` | `US` | Cloud Build bucket. |
| `gs://gcf-v2-sources-135191006412-asia-east1/` | `ASIA-EAST1` | Cloud Functions source bucket. |
| `gs://gcf-v2-uploads-135191006412.asia-east1.cloudfunctions.appspot.com/` | `ASIA-EAST1` | Cloud Functions upload bucket. |
| `gs://ielts-vocab-sync-kelvin/` | `ASIA-EAST1` | Existing application/project bucket. |
| `gs://polyu-ai-dh-awards-2026/` | `ASIA-EAST2` | Website bucket; `index.html` and `index.html` not-found page configured. |

## Useful Commands

```bash
gcloud config get-value project
gcloud config list
gcloud auth list
gcloud services list --enabled
```

## Research Usage Notes

Use this section to record what each Google Cloud resource is used for in the history research workflow.

- OCR: likely Document AI; `documentai.googleapis.com` is enabled; service account `docai-ocr-runner` exists.
- Entity extraction: Vertex AI / Gemini may be used; `aiplatform.googleapis.com` and `generativelanguage.googleapis.com` are enabled.
- Translation: Cloud Translation API is enabled.
- Embeddings: Vertex AI or Gemini API may be used; exact model/location not recorded yet.
- Storage: use project buckets listed above; choose a dedicated research bucket before uploading source material.
- Batch jobs: Cloud Run, Cloud Functions, Cloud Scheduler, Pub/Sub, and Cloud Build APIs are enabled.

## Commands Used For This Snapshot

```bash
gcloud config get-value project
gcloud config list --format=yaml
gcloud projects describe delta-entry-496910-e7 --format=yaml
gcloud billing projects describe delta-entry-496910-e7 --format=yaml
gcloud services list --enabled
gcloud storage buckets list
gcloud iam service-accounts list --project delta-entry-496910-e7
bq ls
```

## Uncertainty

Record uncertain setup details here instead of guessing.

- Vertex AI default location is not set in local `gcloud` config.
- `bq ls` returned no datasets for the default project after CLI initialization.
- The exact billing account ID was observed but intentionally not copied into the wiki.
