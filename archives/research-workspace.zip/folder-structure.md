# Folder Structure

Related pages: [[index]], [[project-overview]], [[workflows]], [[log]]

This project includes wiki pages, source-processing folders, scripts, outputs, and reusable skills. Skills are reusable instructions that help AI agents perform specific tasks consistently and safely.

Classical digital humanities methods should produce verifiable artifacts, such as TEI XML, structured NLP outputs, map-ready gazetteer data, and network edge lists.

## Skills

- [[skills/rest-api-workflow]] — Instructions for safely and repeatably using an external RESTful API.
- [[skills/librarycloud-search]] — Instructions for searching Harvard LibraryCloud or a similar library catalog API.
- [[skills/tei-encoding]] — Instructions for producing structured and verifiable TEI XML.
- [[skills/nlp-analysis]] — Instructions for producing structured NLP analysis outputs.
- [[skills/historical-gis]] — Instructions for producing map-ready historical gazetteer data.
- [[skills/network-analysis]] — Instructions for producing evidence-based network nodes and edge lists.
- [[skills/material-1-google-cloud-ocr]] — Instructions and command template for Google Cloud OCR of Material 1.
- [[skills/chinese-reign-date-conversion]] — Instructions for converting Chinese reign dates with Sinocal and appending Gregorian dates.
- [[skills/summarize-shangzou]] — Instructions for structured JSON summaries of 林爽文 `上奏` records.
- [[skills/summarize-zhupi]] — Instructions for structured JSON summaries of 林爽文 `硃批` records.
- [[skills/summarize-shangyu]] — Instructions for structured JSON summaries of 林爽文 `上諭` records.

## Source Processing Folders

- `raw/` — Original source files. For the first source, see [[source-001]].
- `ocr/` — OCR text and page images derived from raw sources.
- `cleaned/` — Human-reviewed or cleaned text prepared for analysis.
- `outputs/` — Derived outputs such as extraction CSVs, TEI XML, GIS data, network files, and method notes.
- `scripts/` — Reusable scripts used to generate or clean outputs.

## Research Organization Folders

- `corpora/` — Reusable corpus-level descriptions for source sets that may support multiple research attempts.
- `research-attempts/` — Bounded research attempts that reuse shared corpus, method, and background pages without duplicating them.
