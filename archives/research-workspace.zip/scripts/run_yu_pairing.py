#!/usr/bin/env python3
"""Detect which official memorial is responding to which 上諭 (YU response pairing).

Structural half (Python): identity + date window + citation-marker / cited-date
extraction to build candidate reply lists per 上諭.  Textual half (AI): confirm
the citation, extract quotations, classify issue vs receive dates, rate
match_level.  See skills/yu-response-pairing.md.

Detection runs on the date-rich corpus (dual-timeline-data.json).  Write-back
(a later phase) targets stage1-date-adjusted.json.

Examples:
  # structural preview, no proxy call:
  python3 scripts/run_yu_pairing.py --doc-id 天43 --dry-run
  # full run against the proxy:
  python3 scripts/run_yu_pairing.py --proxy https://... --doc-id 天43
  # whole corpus:
  python3 scripts/run_yu_pairing.py --proxy https://... --all
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "outputs" / "attempt-002" / "dual-timeline-data.json"
PROMPT_PATH = ROOT / "skills" / "yu-response-pairing.md"
PROMPT_RE = re.compile(r"^##\s*Website Prompt[ \t]*\n(.*?)(?=\n##\s)", re.S | re.M)

# Citation markers an official uses to introduce the edict they received.
CITATION_MARKERS = ("欽奉上諭", "奉上諭", "奉廷寄", "欽奉諭旨", "承准", "接奉", "敬奉")
# Chinese-date pattern (optional 乾隆..年, month incl. 正/臘/閏, day).
CN_DATE_RE = re.compile(
    r"(?:乾隆[元一二三四五六七八九十]+年)?[正臘閏元一二三四五六七八九十]{1,3}月[初一二三四五六七八九十]{1,3}日"
)
# Window (days after the edict) within which a reply is even considered.
MAX_WINDOW_DAYS = 150


def parse_date(value):
    try:
        return datetime.strptime(value or "", "%Y/%m/%d")
    except (ValueError, TypeError):
        return None


def days_between(later, earlier):
    a, b = parse_date(later), parse_date(earlier)
    return (a - b).days if a and b else None


def website_prompt():
    m = PROMPT_RE.search(PROMPT_PATH.read_text(encoding="utf-8"))
    if not m:
        raise RuntimeError(f"No Website Prompt in {PROMPT_PATH}")
    return m.group(1).strip()


def edict_date(edict):
    return edict.get("annAr") or edict.get("sendAr")


# Populated once in main() from every author/recipient name in the corpus, used
# to recognise officials named inside an edict's body.
_KNOWN_OFFICIALS: set[str] = set()
# Directive verbs that mark an official as an addressee of the edict.
_DIRECTIVE_VERBS = ("傳諭", "諭令", "諭", "令", "著", "飭", "寄")


def build_known_officials(records):
    names = set()
    for r in records:
        a = (r.get("author_name") or "").strip()
        if a:
            names.add(a)
        for n in (r.get("recipients") or []):
            n = (n or "").strip()
            if n:
                names.add(n)
    return {n for n in names if 2 <= len(n) <= 4}


def body_recipients(body, known):
    """Officials named as addressees inside the edict body (e.g. 令孫士毅嚴密查拿),
    not just those in the recipients field — an edict often orders a secondary
    official within a document addressed to someone else."""
    text = body or ""
    found = set()
    for name in known:
        if any(verb + name in text for verb in _DIRECTIVE_VERBS):
            found.add(name)
    return found


def recipients_of(edict, known=None):
    if known is None:
        known = _KNOWN_OFFICIALS
    names = [n.strip() for n in (edict.get("recipients") or []) if n and n.strip()]
    if known:
        names += sorted(body_recipients(edict.get("body"), known))
    if not names and edict.get("author_name"):
        names = [edict["author_name"].strip()]
    return list(dict.fromkeys(names))


def transit_estimates(records):
    """Average send->receive(硃批) lag per author — a soft estimate of how long an
    imperial document takes to reach that official."""
    acc: dict[str, list[int]] = {}
    for r in records:
        lag = days_between(r.get("recvAr"), r.get("sendAr"))
        name = (r.get("author_name") or "").strip()
        if name and lag is not None and lag > 0:
            acc.setdefault(name, []).append(lag)
    return {name: round(sum(v) / len(v), 1) for name, v in acc.items()}


def _cn_date_variants(ann_ch):
    """Return substrings to search a reply body for the edict's own date, e.g.
    '乾隆五十二年一月十三日' -> {'一月十三日', '正月十三日'}."""
    if not ann_ch:
        return set()
    m = re.search(r"([正元一二三四五六七八九十]{1,3})月([初一二三四五六七八九十]{1,3})日", ann_ch)
    if not m:
        return set()
    month, day = m.group(1), m.group(2)
    months = {month}
    if month in ("一", "正", "元"):
        months |= {"一", "正", "元"}
    return {f"{mo}月{day}日" for mo in months}


def citation_passages(body, max_passages=5, span=90, lead=34):
    """Extract text around each citation marker (the reply's edict quotation).

    Includes ``lead`` characters BEFORE the marker so a date that precedes it
    (e.g. ``本年正月二十四日敬奉硃批…``) — and any ``同日`` back-reference — stays in
    the passage for the AI to resolve.
    """
    text = body or ""
    passages, seen = [], set()
    for marker in CITATION_MARKERS:
        for m in re.finditer(re.escape(marker), text):
            start = max(0, m.start() - lead)
            # Search for the closing 欽此/等因/等語 only AFTER the marker, so a
            # preceding citation's 欽此 (now inside the lead-in) can't truncate us.
            after = text[m.start():m.start() + span * 3]
            # Prefer 欽此 (the true close of an edict citation) so an 等語 nested
            # inside the quoted edict doesn't cut the quotation short.
            end = re.search(r"欽此", after) or re.search(r"(等因|等語)", after)
            stop = m.start() + (end.end() if end else span)
            passage = text[start:stop]
            key = passage[:24]
            if key in seen:
                continue
            seen.add(key)
            passages.append(passage.strip())
            if len(passages) >= max_passages:
                return passages
    return passages


def _reply_cand(reply, edict, transit):
    """Build a candidate-reply record describing `reply` relative to `edict`."""
    author = (reply.get("author_name") or "").strip()
    body = reply.get("body") or ""
    date_variants = _cn_date_variants(edict.get("annCh") or "")
    return {
        "id": reply["id"],
        "author": author,
        "sendAr": reply.get("sendAr", ""),
        "recvAr": reply.get("recvAr", ""),
        "lag_days": days_between(reply.get("sendAr"), edict_date(edict)),
        "transit_est": transit.get(author),
        "cites_edict_date": any(v in body for v in date_variants),
        "passages": citation_passages(body),
    }


def _pairable(edict, reply):
    """True if reply passes the structural net for edict: identity + date window
    + a citation marker or the edict's own date appearing in the reply."""
    targets = recipients_of(edict)
    author = (reply.get("author_name") or "").strip()
    if not author or not any(t and (t in author or author in t) for t in targets):
        return False
    lag = days_between(reply.get("sendAr"), edict_date(edict))
    if lag is None or lag <= 0 or lag > MAX_WINDOW_DAYS:
        return False
    body = reply.get("body") or ""
    has_marker = any(mk in body for mk in CITATION_MARKERS)
    cites_date = any(v in body for v in _cn_date_variants(edict.get("annCh") or ""))
    return has_marker or cites_date


def candidates_for(edict, records, transit):
    """Forward: given an 上諭, the official replies that may answer it."""
    out = [
        _reply_cand(r, edict, transit)
        for r in records
        if r.get("id") != edict.get("id")
        and r.get("type") != "shangyu"
        and _pairable(edict, r)
    ]
    out.sort(key=lambda c: (not c["cites_edict_date"], c["lag_days"]))
    return out[:12]


def edicts_for(reply, records, transit):
    """Reverse: given an official doc, the 上諭 it may be answering. Returns a list
    of (edict, [reply_cand]) so each edict can drive the same pairing prompt."""
    out = []
    for y in records:
        if y.get("type") != "shangyu":
            continue
        if _pairable(y, reply):
            out.append(y)
    out.sort(key=lambda y: (not _reply_cand(reply, y, transit)["cites_edict_date"],
                            days_between(reply.get("sendAr"), edict_date(y)) or 999))
    return [(y, [_reply_cand(reply, y, transit)]) for y in out[:12]]


def candidate_block(edict, cands):
    lines = [
        "【本上諭】",
        f"doc_id：{edict.get('id', '')}",
        f"發布日：{edict.get('annAr') or edict.get('sendAr') or '未明'}"
        f"（{edict.get('annCh') or ''}）",
        f"受命官員：{'、'.join(recipients_of(edict))}",
        f"標題：{edict.get('title', '')}",
        f"原文：\n{edict.get('body', '')}",
        "",
    ]
    for i, c in enumerate(cands, 1):
        lines += [
            f"【候選回應 {i}】",
            f"doc_id：{c['id']}",
            f"具奏官員：{c['author']}",
            f"上奏日：{c['sendAr'] or '未明'}",
            f"距上諭：{c['lag_days']} 日"
            + (f"（該官平均往返約 {c['transit_est']} 日）" if c["transit_est"] else ""),
            "引用段落：\n" + ("\n---\n".join(c["passages"]) or "（未偵測到引用標記）"),
            "",
        ]
    return "\n".join(lines)


def call_proxy(proxy, payload):
    req = Request(
        proxy.rstrip("/") + "/chat",
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urlopen(req, timeout=180) as resp:
        return json.loads(resp.read().decode("utf-8"))


def repair_json(text):
    s = (text or "").strip()
    if s.startswith("```"):
        s = s.split("\n", 1)[1] if "\n" in s else s
        if s.rstrip().endswith("```"):
            s = s.rstrip()[:-3]
    a, b = s.find("{"), s.rfind("}")
    return s[a:b + 1] if a >= 0 and b > a else s


def parse_pairs(model_response, edict_id, cands):
    text = model_response.get("text") if isinstance(model_response, dict) else model_response
    obj = None
    for cand in (text, repair_json(text or "")):
        try:
            obj = json.loads(cand)
            break
        except (json.JSONDecodeError, TypeError):
            continue
    if not isinstance(obj, dict):
        return []
    valid = {c["id"] for c in cands}
    pairs = []
    for p in obj.get("pairs", []):
        rid = str(p.get("reply_doc_id", "")).strip()
        if rid not in valid:
            continue
        pairs.append({
            "reply_doc_id": rid,
            "yu_doc_id": edict_id,
            "relation": "reply_to_yu",
            "match_level": p.get("match_level", "weak"),
            "evidence": p.get("evidence", {}),
        })
    return pairs


def build_jobs(anchor, records, transit):
    """Return [(edict, [reply_cand,…]), …] for either direction, chosen by the
    anchor's type: an 上諭 anchors a forward search (its replies); an official doc
    anchors a reverse search (the 上諭 it answers)."""
    if anchor.get("type") == "shangyu":
        return [(anchor, candidates_for(anchor, records, transit))]
    return edicts_for(anchor, records, transit)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--proxy", default=os.environ.get("GEMINI_PROXY_URL", ""))
    ap.add_argument("--doc-id", help="Analyse one document — an 上諭 (find its replies) "
                    "OR an official doc (find the 上諭 it answers). Direction is auto.")
    ap.add_argument("--all", action="store_true", help="Analyse every 上諭 (forward).")
    ap.add_argument("--model", default="gemini-3.5-flash")
    ap.add_argument("--dry-run", action="store_true", help="Show candidates; no proxy call.")
    ap.add_argument("--bundle-name", default="yu-pairing")
    args = ap.parse_args()

    records = json.loads(DATA_PATH.read_text(encoding="utf-8"))
    by_id = {r.get("id"): r for r in records}
    global _KNOWN_OFFICIALS
    _KNOWN_OFFICIALS = build_known_officials(records)
    transit = transit_estimates(records)

    if args.doc_id:
        anchor = by_id.get(args.doc_id)
        if not anchor:
            ap.error(f"document not found: {args.doc_id}")
        anchors = [anchor]
    elif args.all:
        anchors = [r for r in records if r.get("type") == "shangyu"]
    else:
        ap.error("Pass --doc-id <id> (上諭 or official doc) or --all.")

    jobs = []
    for anchor in anchors:
        direction = "forward" if anchor.get("type") == "shangyu" else "reverse"
        jobs.extend((direction, anchor, ed, cands)
                    for ed, cands in build_jobs(anchor, records, transit))

    all_pairs = []
    for direction, anchor, edict, cands in jobs:
        if args.dry_run:
            tag = f"{anchor['id']} → 上諭 {edict['id']}" if direction == "reverse" else edict["id"]
            print(f"\n== [{direction}] {tag} ({edict.get('annAr') or edict.get('sendAr')}) "
                  f"受命：{'、'.join(recipients_of(edict))} ==")
            for c in cands:
                flag = "★cites-date" if c["cites_edict_date"] else ""
                print(f"  {c['id']:>6}  {c['author']:<6} {c['sendAr']}  +{c['lag_days']}d  {flag}")
                for p in c["passages"][:1]:
                    print(f"        「{p[:60]}…」")
            continue
        if not cands:
            continue
        if not args.proxy:
            ap.error("Set GEMINI_PROXY_URL or pass --proxy (or use --dry-run).")
        payload = {
            "mode": "ask",
            "model": args.model,
            "doc_id": edict["id"],
            "doc_type": edict.get("doc_type", "上諭"),
            "title": edict.get("title", ""),
            "body": candidate_block(edict, cands),
            "question": website_prompt(),
        }
        result = call_proxy(args.proxy, payload)
        all_pairs.extend(parse_pairs(result, edict["id"], cands))

    if args.dry_run:
        return 0

    # de-duplicate pairs (reverse mode can re-surface a pair found forward)
    seen, deduped = set(), []
    for p in all_pairs:
        key = (p["reply_doc_id"], p["yu_doc_id"])
        if key not in seen:
            seen.add(key)
            deduped.append(p)

    out_path = ROOT / "outputs" / "attempt-002" / "yu-pairing.json"
    out_path.write_text(json.dumps(deduped, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    # website-loadable bundle (renders one card per pair in the no-selection panel)
    bundle_root = ROOT / "outputs" / "review-bundles" / args.bundle_name
    (bundle_root / "outputs").mkdir(parents=True, exist_ok=True)
    (bundle_root / "outputs" / "yu-pairing.json").write_text(
        json.dumps(deduped, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (bundle_root / "manifest.json").write_text(json.dumps({
        "name": args.bundle_name,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "source": "outputs/attempt-002/dual-timeline-data.json",
        "doc_ids": sorted({p["yu_doc_id"] for p in deduped} | {p["reply_doc_id"] for p in deduped}),
        "chain": ["yu-pairing"],
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(out_path)
    print(bundle_root)
    print(f"pairs: {len(deduped)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
