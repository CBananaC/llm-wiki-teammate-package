# LLM Wiki Index

## Purpose

This wiki is a working knowledge base for AI-assisted digital humanities work on Sinitic / Chinese historical and humanities texts.

It helps AI assistants understand project background, [[terminology]], [[source-materials]], [[extraction-rules]], [[prompt-rules]], [[examples]], [[known-errors]], [[workflows]], and [[folder-structure]] before doing project work.

Skills are reusable instructions that help AI agents perform specific tasks consistently and safely.

Classical digital humanities methods should produce verifiable artifacts, such as TEI XML, structured NLP outputs, map-ready gazetteer data, and network edge lists.

## Quick Start for AI Assistants

Before doing any project work, read these files in order:

1. [[AGENTS]]
2. [[project-overview]]
3. The task-specific page, such as [[extraction-rules]], [[prompt-rules]], or [[source-materials]]

Rules:

- Do not invent sources, citations, names, dates, translations, or historical facts.
- Use English for explanation by default.
- Use Traditional Chinese only when Chinese is needed.
- Follow the requested output format exactly.
- Mark uncertainty instead of guessing.

## Wiki Pages

| File | Purpose | When to read it |
| --- | --- | --- |
| [[AGENTS]] | Gives working rules for AI coding and research agents. | Read first before any project work. |
| [[project-overview]] | Explains what the LLM Wiki is and what kind of project it supports. | Read when joining the project or starting a new task. |
| [[background/research-questions]] | Records developing research objects, provisional research questions, and open decisions. | Read when refining the project's research direction or adding a new topic. |
| [[terminology]] | Defines key AI, digital humanities, and Sinitic text terms. | Read when terms, translations, or categories are unclear. |
| [[source-materials]] | Records sources, source categories, reliability, and citation rules. | Read before using, citing, or describing any source. |
| [[reference-list]] | Collects reference-list entries for registered sources, grouped by language and source type. | Read when preparing bibliography or checking citation categories. |
| [[corpora/lin-shuangwen-first-hand-json]] | Records the reusable structured first-hand JSON corpus for 林爽文事件 research. | Read before using the 林爽文 JSON for chronology, extraction, or source selection. |
| [[background/lin-shuangwen-war-stages]] | Records the working three-stage model of the 林爽文 war. | Read before assigning documents or arguments to a war stage. |
| [[research-attempts/README]] | Explains how to organize repeated research attempts using shared materials. | Read before creating a new attempt page. |
| [[research-attempts/attempt-002-lin-shuangwen-early-stages]] | Describes the second LLM Wiki research attempt, starting from the first stage of the 林爽文 war. | Read when working on early-stage 林爽文 documents. |
| [[extraction-rules]] | Defines rules for extracting names, places, dates, titles, and structured data. | Read before extraction or entity-recognition tasks. |
| [[prompt-rules]] | Stores reusable prompt rules and prompt templates. | Read before writing or revising prompts. |
| [[examples]] | Shows correct and incorrect AI outputs. | Read before testing prompts or judging model output. |
| [[known-errors]] | Records repeated AI mistakes and prevention rules. | Read before designing prompts or debugging bad outputs. |
| [[workflows]] | Describes repeatable project workflows. | Read before OCR, extraction, model comparison, or wiki updates. |

## Operational Pages

| File | Purpose | When to read it |
| --- | --- | --- |
| [[folder-structure]] | Describes the current repository layout, including source-processing folders and reusable skills. | Read before adding folders, outputs, scripts, or skills. |
| [[google-cloud-info]] | Stores non-secret Google Cloud project metadata and setup notes. | Read before using Google Cloud resources or checking cloud setup. |
| [[log]] | Records important changes to the wiki. | Read before reconstructing project history or adding a major update. |
| [[final-summary]] | Summarizes the workshop/project arc and the current built artifacts. | Read when onboarding or reviewing the whole project. |
| [[source-001]] | Hub page for the first processed source and its derived artifacts. | Read before using or extending `source-001` outputs. |
| [[outputs/wiki-review]] | Records the wiki graph, terminology, and structure review. | Read before checking whether the latest review recommendations have been addressed. |

## Skills

| File | Purpose | When to use it |
| --- | --- | --- |
| [[skills/rest-api-workflow]] | Provides a safe, repeatable workflow for using external RESTful APIs. | Use when requesting external data or calling an API from a script. |
| [[skills/librarycloud-search]] | Provides a workflow for searching Harvard LibraryCloud or a similar catalog API. | Use when finding and evaluating bibliographic records. |
| [[skills/tei-encoding]] | Provides rules for encoding source texts as structured TEI XML. | Use when marking text structure, entities, dates, titles, or divisions. |
| [[skills/nlp-analysis]] | Provides rules for computational text analysis and structured NLP outputs. | Use for entity extraction, classification, tagging, topic detection, or model comparison. |
| [[skills/historical-gis]] | Provides rules for linking historical places to gazetteers and map-ready data. | Use for place extraction, historical geocoding, and geographic data preparation. |
| [[skills/network-analysis]] | Provides rules for creating evidence-based nodes and edge lists. | Use for relationship extraction and network data preparation. |
| [[skills/material-1-google-cloud-ocr]] | Provides layout notes and a Google Cloud Document AI OCR command for Material 1. | Use before OCRing pages from 《明清臺灣檔案彙編》第貳輯第30冊. |
| [[skills/chinese-reign-date-conversion]] | Provides rules for converting Chinese reign dates with Sinocal and appending Gregorian dates. | Use when cleaned Chinese source text contains dates such as 乾隆五十一年十二月十日. |
| [[skills/summarize-shangzou]] | Provides the JSON schema and evidence rules for summarizing 林爽文 `上奏` records. | Use before summarizing official memorials in the Stage 1 corpus. |
| [[skills/summarize-zhupi]] | Provides the JSON schema and evidence rules for summarizing 林爽文 `硃批` records. | Use before summarizing memorials with imperial rescripts. |
| [[skills/summarize-shangyu]] | Provides the JSON schema and evidence rules for summarizing 林爽文 `上諭` records. | Use before summarizing imperial orders in the Stage 1 corpus. |

## Source 001 Derived Outputs

| File | Purpose | When to read it |
| --- | --- | --- |
| [[outputs/source-001/processing-notes]] | Records processing steps, corrections, and artifact creation for `source-001`. | Read before trusting or extending any `source-001` output. |
| [[outputs/source-001/cbdb-enrichment]] | Records CBDB person matching and related external enrichment. | Read before using CBDB identifiers, addresses, or relationship data. |
| [[outputs/source-001/chgis-enrichment]] | Records CHGIS/TGAZ place matching and coordinate decisions. | Read before using map-ready place data. |
| [[outputs/source-001/map-network-cross-reading]] | Explains how to read map and network outputs together without overclaiming. | Read before interpreting geographic-network patterns. |
| [[outputs/source-001/source-001.nlp-summary]] | Summarizes TEI-derived NLP segments, tags, topics, and classification outputs. | Read before using NLP tables as evidence. |

## Suggested Reading Paths

### For Text Extraction Tasks

Read:

1. [[AGENTS]]
2. [[terminology]]
3. [[source-materials]]
4. [[extraction-rules]]
5. [[examples]]
6. [[known-errors]]

### For Prompt Writing Tasks

Read:

1. [[AGENTS]]
2. [[prompt-rules]]
3. [[examples]]
4. [[known-errors]]

### For Source Management Tasks

Read:

1. [[AGENTS]]
2. [[source-materials]]
3. [[reference-list]]
4. [[folder-structure]]
5. [[workflows]]

### For Source 001 Tasks

Read:

1. [[AGENTS]]
2. [[source-001]]
3. [[source-materials]]
4. [[outputs/source-001/processing-notes]]
5. The relevant method page, such as [[skills/tei-encoding]], [[skills/nlp-analysis]], [[skills/historical-gis]], or [[skills/network-analysis]]

### For Updating the Wiki

Read:

1. [[AGENTS]]
2. [[project-overview]]
3. [[folder-structure]]
4. [[workflows]]
5. [[log]]

## Current Wiki Status

This is the first version of the LLM Wiki. It currently contains general rules and examples. More project-specific source records, extraction schemas, and real examples should be added later.

## Next Pages To Improve

- [ ] Further specify [[background/research-questions|Research Object 1]] by selecting a Qing warfare case and source corpus
- [ ] Develop [[research-attempts/attempt-002-lin-shuangwen-early-stages]] into a Stage 1 document inventory and timeline
- [ ] Add real source records to [[source-materials]]
- [ ] Add project-specific entity categories to [[extraction-rules]]
- [ ] Add tested prompts to [[prompt-rules]]
- [ ] Add real good and bad examples to [[examples]]
- [ ] Add repeated model failures to [[known-errors]]
- [ ] Add real OCR and extraction workflows to [[workflows]]
