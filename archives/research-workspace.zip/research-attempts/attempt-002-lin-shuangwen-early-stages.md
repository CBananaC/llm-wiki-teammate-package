# Attempt 002 — Lin Shuangwen Early Stages

Related pages: [[index]], [[research-attempts/README]], [[background/lin-shuangwen-war-stages]], [[corpora/lin-shuangwen-first-hand-json]], [[source-materials]]

## Status

Started on 2026-06-22.

This is the user's second attempt at using the LLM Wiki for historical research.

## Working title

From early misjudgment to delayed control: the first stages of the 林爽文事件 before 福康安.

## Relation to the previous attempt

The previous research focused mainly on 福康安 and the final stage of the war.

That was useful because the 福康安 stage gives clear examples of delayed imperial strategy: 乾隆 issues orders based on old information, while 福康安 acts from newer battlefield knowledge.

The second attempt changes the angle. Instead of starting from the final breakthrough, it begins with the earlier stages of the war and asks how the command and communication problem developed before 福康安 became the solution.

## Shared corpus

Main source page: [[corpora/lin-shuangwen-first-hand-json]]

Main JSON file:

`/Users/creamybanana/Downloads/林爽文/Final Drive Copy/奏摺上諭結構化數據.json`

The dataset contains first-hand structured records from:

- 明清台灣檔案匯編
- 天地會

The JSON should be used for searching, grouping, chronology, and source selection. Formal quotation still requires checking the relevant source text.

## Stage model

Use [[background/lin-shuangwen-war-stages]] as the shared periodization page.

The current working model:

1. 黃仕簡、任承恩分路渡臺階段
2. 常青、藍元枚督剿階段
3. 福康安統兵反攻階段

Attempt 002 begins with Stage 1.

## Main research purpose

The purpose is to understand how the Qing court first interpreted the war, why the first response failed, and how the communication structure shaped that failure.

The guiding shift is:

> Do not only ask how 福康安 used local judgment under delayed imperial orders. Ask how the earlier system produced the crisis that made 福康安 necessary.

## Stage 1 working focus

Stage 1 is the 黃仕簡、任承恩分路渡臺 stage.

Initial hypothesis:

The first stage was not simply a military failure. It was also an information and command failure. The court received early reports of rebellion, dispatched senior Fujian commanders, and expected a converging suppression campaign. But because command authority was fragmented and reports arrived through multiple channels, the intended strategy became dispersed defense rather than coordinated attack.

Key people to track:

- 黃仕簡
- 任承恩
- 常青
- 柴大紀
- 孫士毅
- 徐嗣曾
- 李侍堯, when he enters the communication chain

Key places to track:

- 彰化
- 大里杙
- 府城
- 鹿仔港
- 諸羅
- 鳳山
- 廈門 / 福建 rear area
- Beijing / imperial decision center

## Questions for Stage 1

- When did 乾隆 and central officials first understand that 林爽文 was not a local disturbance but a major war?
- What did early memorials emphasize: rebellion scale, city loss, troop dispatch, local disorder, official failure, or need for reinforcement?
- How were 黃仕簡 and 任承恩 expected to cooperate?
- Did the documents show a clear commander, or a split command structure?
- How did delayed reports affect imperial judgment in the first weeks?
- When did the court begin to see that the first-stage response had failed?
- How did responsibility get assigned or shifted among 黃仕簡, 任承恩, 常青, 柴大紀, and Fujian officials?

## Suggested extraction fields for Stage 1

| Field | Purpose |
| --- | --- |
| `doc_id` | Stable citation key. |
| `doc_type` | Separate 上奏, 硃批, 上諭, 移咨. |
| `date_field_used` | Record whether chronology is based on memorial, rescript, or issue date. |
| `send_date` | Upward report date, stored as `[Chinese date, Arabic date]`. |
| `receive_date` | Imperial receipt/reply date, stored as `[Chinese date, Arabic date]`. |
| `announce_date` | Imperial order announcement date for `上諭`, stored as `[Chinese date, Arabic date]`. |
| `issue_date` | Remaining issue date for non-`上諭` document types, stored as `[Chinese date, Arabic date]`. |
| `author_name` | Sender or named issuing authority. |
| `author_position` | Official post when present. |
| `reported_event_date` | Event date inside the body, if different from document date. |
| `reported_place` | Main place reported. |
| `communication_direction` | Taiwan/Fujian to center, center to Taiwan/Fujian, lateral, or unclear. |
| `military_problem` | City loss, troop dispatch, defense, reinforcement, supply, command, intelligence, punishment, reward. |
| `command_relation` | Evidence of who commands whom, or where authority is unclear. |
| `delay_observation` | Any visible gap between event, memorial, receipt/rescript, and order. |
| `evidence_quote` | Short original wording supporting the classification. |
| `interpretive_note` | Separate interpretation from source wording. |
| `uncertainty` | Any unclear date, place, identity, or inference. |

## Method

1. Filter the JSON to the Stage 1 date range.
2. Produce a document inventory by date, document type, author, and title.
3. Identify clusters of documents around major early events.
4. Separate source chronology from imperial knowledge chronology.
5. Compare intended strategy with actual reported battlefield action.
6. Record failed prompts, extraction mistakes, or uncertain categories in the wiki instead of silently correcting them.

## Date adjustment rule

The first data problem was that `memorial_date`, `rescript_date`, and `issue_date` did not mean the same thing for every `doc_type`.

Current adjustment rule:

| `doc_type` | Date interpretation |
| --- | --- |
| `上奏` | Use `send_date`, stored as `[Chinese date, Arabic date]`. |
| `硃批` | Use `send_date` and `receive_date`, each stored as `[Chinese date, Arabic date]`. |
| `上諭` | Use `announce_date`, stored as `[Chinese date, Arabic date]`. |
| `移咨` | Leave unchanged for now. |
| `其他` | Leave unchanged for now. |

The source schema transformation script is [[scripts/rename_source_json_date_fields.py]].

The Stage 1 subset script is [[scripts/adjust_lin_shuangwen_dates.py]].

The generated output is `outputs/attempt-002/stage1-date-adjusted.json`, summarized in `outputs/attempt-002/stage1-date-adjustment-summary.md`.

## Interactive timeline workspace

The current attempt-002 HTML output is `outputs/attempt-002/stage1-timeline.html`.

Claude's 2026-06-23 adjustment changed the file from a single chronology chart into a two-mode reading workspace:

- `曲線總覽` keeps the original aggregate curve view: officials' outgoing memorials above the baseline, imperial `硃批` replies and `上諭` below it, with daily click-through counts and document titles.
- `雙線・發送↔回覆` adds an immersive full-screen dual timeline. It places official sending dates on the left and emperor response / announcement dates on the right, so `硃批` records can be read as communication intervals rather than one-day events.
- The dual view includes filters by document type (`上奏`, `硃批`, `上諭`), sender, and free-text search across title, original text, summary, and rescript fields.
- Clicking a record opens a movable / dockable drawer with original text, rescript text where present, the structured Gemini summary, and a table view.
- The drawer adds an interactive annotation layer: summary claims with quotations can be toggled to highlight their matching passages in the original text, making the LLM summary auditable against the source.
- Browser-local research notes and summary edits are stored in `localStorage` and can be exported / imported as `timeline-edits.json`; these are reader annotations, not replacements for the canonical JSON.
- The page includes optional Cloud Run Gemini proxy hooks for further summary, division, and question-answering inside the drawer.

Research implication: the HTML should now be treated as an exploratory close-reading interface over `stage1-date-adjusted.json` and the Stage 1 summary outputs, not only as a static visualization artifact. Any accepted edits or annotations made in the browser still need to be exported and deliberately incorporated into wiki/source files before they count as project data.

## Expected outputs

Possible outputs for this attempt:

- Stage 1 document inventory.
- Stage 1 timeline / reading workspace with separate sending, receipt/rescript, and announcement dates.
- Command-relation table for 黃仕簡, 任承恩, 常青, 柴大紀, and Fujian officials.
- Map-ready place list for early-stage reported events.
- Short interpretive memo on why the first-stage response failed.

## Wiki structure decision

This attempt should not create a separate copy of the whole 林爽文 corpus.

Use this division:

- shared source description: [[corpora/lin-shuangwen-first-hand-json]]
- shared periodization: [[background/lin-shuangwen-war-stages]]
- attempt-specific questions and extraction plan: this page
- derived tables, summary checks, and interactive reading outputs: under `outputs/attempt-002/`

## Open decisions

- Should Stage 1 end at 乾隆五十二年三月, or at the specific document cluster where 常青 replaces the initial two-commander model?
- Should documents be grouped by memorial date, rescript date, or issue date?
- Should the first extraction prioritize document metadata first, or close-read the early high-density clusters?
- Should future attempts be numbered by research session, by stage, or by output type?
