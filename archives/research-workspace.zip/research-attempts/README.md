# Research Attempts

Related pages: [[index]], [[background/research-questions]], [[corpora/lin-shuangwen-first-hand-json]], [[log]]

## Purpose

This folder records discrete research attempts that reuse the same wiki, corpus, and methods.

An attempt is not a finished paper. It is a bounded research experiment with a question, source subset, method, outputs, and open problems.

## Why use attempt pages

Attempt pages prevent the wiki from mixing three things that should stay separate:

1. shared sources and methods;
2. the current attempt's working argument;
3. later attempts that may reuse the same corpus for a different question.

Shared material should live in reusable pages such as [[corpora/lin-shuangwen-first-hand-json]] and [[background/lin-shuangwen-war-stages]].

Attempt-specific claims, subsets, prompts, failures, and decisions should live in an attempt page.

## Attempt page template

Each attempt page should normally include:

- working title;
- status;
- relation to earlier attempts;
- corpus or source subset;
- research question;
- stage or chronological scope;
- extraction fields;
- method;
- expected outputs;
- open decisions;
- next actions.

## Current attempts

| Attempt | Page | Focus |
| --- | --- | --- |
| 002 | [[research-attempts/attempt-002-lin-shuangwen-early-stages]] | Rebalance the 林爽文 research away from the 福康安 final stage by starting with Stage 1 and earlier command failure. |
