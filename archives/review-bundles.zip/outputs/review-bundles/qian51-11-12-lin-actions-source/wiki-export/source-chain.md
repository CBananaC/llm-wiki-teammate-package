# source-chain

Bundle: `qian51-11-12-lin-actions-source`  
Docs: 台2, 台3, 台4, 台5, 台7, 台6, 台10, 台9, 台11, 台8, 台12, 台13, 台14, 台15, 台16, 台17, 台18, 台19, 台20, 台22, 台23, 台21, 台24, 台26, 台25, 台28, 台29, 台27, 台30, 台32, 台31, 台35, 台33, 台36, 台34, 天13, 天20

## 台2

```json
{
  "doc_id": "台2",
  "evTitle": "林爽文結黨騷擾地方",
  "event": {
    "description": "乾隆五十一年十一月間，林爽文於彰化縣地方結黨滋事，騷擾地方，文武官員未能將其擒獲。",
    "howKnown": "轉述",
    "quote": "十一月間，卑職等聞彰化縣匪徒林爽文結黨四虐，騷擾地方，文武官員擒捕未獲。",
    "relations": [],
    "side": "lin",
    "subtitle": "林爽文結黨騷擾地方",
    "whenAr": "1786/12",
    "whenCh": "十一月間",
    "whenKnownCh": "十二月初九日",
    "where": "彰化縣",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "彰化縣"
    },
    "doc_id": "台2"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "十一月間，卑職等聞彰化縣匪徒林爽文結黨四虐，騷擾地方，文武官員擒捕未獲。",
          "reporter": "程峻、董得魁",
          "subtitle": "林爽文結黨騷擾地方",
          "whenCh": "乾隆五十一年十一月間",
          "where": "彰化縣"
        }
      ],
      "hops": [
        {
          "from_person": "楊添",
          "how": "投稟並口述",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "本年十二月初九日亥刻，奴才接據署臺灣府淡水同知程峻、竹塹營守備董得魁會銜差役楊添投稟報...當即傳喚該差楊添進署面加詢問。",
          "to_person": "任承恩",
          "whenAr": "1787/01/27",
          "whenCh": "乾隆五十一年十二月初九日亥刻"
        },
        {
          "from_person": "程峻、董得魁",
          "how": "差遣",
          "inferred": true,
          "layer": 2,
          "place": "淡水",
          "quote": "署臺灣府淡水同知程峻、竹塹營守備董得魁會銜差役楊添投稟報...隨即專差搭船馳稟。",
          "to_person": "楊添",
          "whenAr": "",
          "whenCh": "乾隆五十一年十一月二十九日後"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "十一月間，卑職等聞彰化縣匪徒林爽文結黨四虐，騷擾地方，文武官員擒捕未獲。",
            "reporter": "程峻、董得魁",
            "subtitle": "林爽文結黨騷擾地方",
            "whenCh": "乾隆五十一年十一月間",
            "where": "彰化縣"
          }
        ],
        "hops": [
          {
            "from_person": "楊添",
            "how": "投稟並口述",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "本年十二月初九日亥刻，奴才接據署臺灣府淡水同知程峻、竹塹營守備董得魁會銜差役楊添投稟報...當即傳喚該差楊添進署面加詢問。",
            "to_person": "任承恩",
            "whenAr": "1787/01/27",
            "whenCh": "乾隆五十一年十二月初九日亥刻"
          },
          {
            "from_person": "程峻、董得魁",
            "how": "差遣",
            "inferred": true,
            "layer": 2,
            "place": "淡水",
            "quote": "署臺灣府淡水同知程峻、竹塹營守備董得魁會銜差役楊添投稟報...隨即專差搭船馳稟。",
            "to_person": "楊添",
            "whenAr": "",
            "whenCh": "乾隆五十一年十一月二十九日後"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台2

```json
{
  "doc_id": "台2",
  "evTitle": "大墩襲殺官兵",
  "event": {
    "description": "乾隆五十一年十一月二十七日夜，彰化知縣俞峻與北路協副將赫生額率兵在大墩地方搜捕匪徒，遭林爽文部眾襲擊殺害。",
    "howKnown": "轉述",
    "quote": "此月二十七夜，本縣俞在大墩地方拿匪遇害……北路赫副將與俞知縣在大墩地方拿匪，同時被害",
    "relations": [
      {
        "evidence": "本縣俞在大墩地方拿匪遇害",
        "relation": "殺害",
        "relation_type": "conflict",
        "source": "林爽文",
        "target": "俞知縣"
      },
      {
        "evidence": "北路赫副將與俞知縣在大墩地方拿匪，同時被害",
        "relation": "殺害",
        "relation_type": "conflict",
        "source": "林爽文",
        "target": "赫副將"
      }
    ],
    "side": "lin",
    "subtitle": "大墩襲殺官兵",
    "whenAr": "1786/12/17",
    "whenCh": "十一月二十七夜",
    "whenKnownCh": "十二月初九日",
    "where": "大墩",
    "who": [
      "林爽文",
      "俞知縣",
      "赫副將"
    ],
    "who_loc": {
      "俞知縣": "大墩",
      "林爽文": "大墩",
      "赫副將": "大墩"
    },
    "doc_id": "台2"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "此月二十七夜，本縣俞在大墩地方拿匪遇害",
          "reporter": "大肚社番",
          "subtitle": "大墩襲殺官兵",
          "whenCh": "十一月二十七夜",
          "where": "大墩"
        }
      ],
      "hops": [
        {
          "from_person": "楊添",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "泉州府城",
          "quote": "奴才接據署臺灣府淡水同知程峻、竹塹營守備董得魁會銜差役楊添投稟報稱……奴才接閱之下不勝駭異，當即傳喚該差楊添進署面加詢問。",
          "to_person": "任承恩",
          "whenAr": "1787/01/27",
          "whenCh": "乾隆五十一年十二月初九日亥刻"
        },
        {
          "from_person": "程峻、董得魁",
          "how": "差遣",
          "inferred": false,
          "layer": 2,
          "place": "淡水",
          "quote": "隨即專差搭船馳稟",
          "to_person": "楊添",
          "whenAr": "",
          "whenCh": "乾隆五十一年十一月二十九日之後"
        },
        {
          "from_person": "大甲社通事",
          "how": "轉遞",
          "inferred": true,
          "layer": 3,
          "place": "淡水",
          "quote": "該番忽將原文帶回，並有彰邑大肚社番字寄淡屬大甲社通事……卑職等立即督率兵役",
          "to_person": "程峻、董得魁",
          "whenAr": "1787/01/17",
          "whenCh": "乾隆五十一年十一月二十九日"
        },
        {
          "from_person": "大肚社番",
          "how": "字寄",
          "inferred": false,
          "layer": 4,
          "place": "大肚社至大甲社",
          "quote": "彰邑大肚社番字寄淡屬大甲社通事，據稱此月二十七夜，本縣俞在大墩地方拿匪遇害",
          "to_person": "大甲社通事",
          "whenAr": "",
          "whenCh": "乾隆五十一年十一月二十九日以前"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "北路赫副將與俞知縣在大墩地方拿匪，同時被害",
          "reporter": "楊添",
          "subtitle": "大墩襲殺官兵",
          "whenCh": "十一月二十七夜",
          "where": "大墩"
        }
      ],
      "hops": [
        {
          "from_person": "楊添",
          "how": "口述",
          "inferred": false,
          "layer": 1,
          "place": "泉州府城",
          "quote": "復據該差楊添口稱：小的起身在路上時，聞得傳說，北路赫副將與俞知縣在大墩地方拿匪，同時被害",
          "to_person": "任承恩",
          "whenAr": "1787/01/27",
          "whenCh": "乾隆五十一年十二月初九日亥刻"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "此月二十七夜，本縣俞在大墩地方拿匪遇害",
            "reporter": "大肚社番",
            "subtitle": "大墩襲殺官兵",
            "whenCh": "十一月二十七夜",
            "where": "大墩"
          }
        ],
        "hops": [
          {
            "from_person": "楊添",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "泉州府城",
            "quote": "奴才接據署臺灣府淡水同知程峻、竹塹營守備董得魁會銜差役楊添投稟報稱……奴才接閱之下不勝駭異，當即傳喚該差楊添進署面加詢問。",
            "to_person": "任承恩",
            "whenAr": "1787/01/27",
            "whenCh": "乾隆五十一年十二月初九日亥刻"
          },
          {
            "from_person": "程峻、董得魁",
            "how": "差遣",
            "inferred": false,
            "layer": 2,
            "place": "淡水",
            "quote": "隨即專差搭船馳稟",
            "to_person": "楊添",
            "whenAr": "",
            "whenCh": "乾隆五十一年十一月二十九日之後"
          },
          {
            "from_person": "大甲社通事",
            "how": "轉遞",
            "inferred": true,
            "layer": 3,
            "place": "淡水",
            "quote": "該番忽將原文帶回，並有彰邑大肚社番字寄淡屬大甲社通事……卑職等立即督率兵役",
            "to_person": "程峻、董得魁",
            "whenAr": "1787/01/17",
            "whenCh": "乾隆五十一年十一月二十九日"
          },
          {
            "from_person": "大肚社番",
            "how": "字寄",
            "inferred": false,
            "layer": 4,
            "place": "大肚社至大甲社",
            "quote": "彰邑大肚社番字寄淡屬大甲社通事，據稱此月二十七夜，本縣俞在大墩地方拿匪遇害",
            "to_person": "大甲社通事",
            "whenAr": "",
            "whenCh": "乾隆五十一年十一月二十九日以前"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "北路赫副將與俞知縣在大墩地方拿匪，同時被害",
            "reporter": "楊添",
            "subtitle": "大墩襲殺官兵",
            "whenCh": "十一月二十七夜",
            "where": "大墩"
          }
        ],
        "hops": [
          {
            "from_person": "楊添",
            "how": "口述",
            "inferred": false,
            "layer": 1,
            "place": "泉州府城",
            "quote": "復據該差楊添口稱：小的起身在路上時，聞得傳說，北路赫副將與俞知縣在大墩地方拿匪，同時被害",
            "to_person": "任承恩",
            "whenAr": "1787/01/27",
            "whenCh": "乾隆五十一年十二月初九日亥刻"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台2

```json
{
  "doc_id": "台2",
  "evTitle": "匪徒攻陷彰化縣城",
  "event": {
    "description": "乾隆五十一年十一月二十八日清晨，林爽文率領起事群眾攻陷彰化縣城並予以佔據，導致南北路途梗塞，文報無法傳遞。",
    "howKnown": "轉述",
    "quote": "本日早彰城失陷，路途梗塞，不能前遞……彰化既為匪徒竊踞",
    "relations": [],
    "side": "lin",
    "subtitle": "匪徒攻陷彰化縣城",
    "whenAr": "1786/12/18",
    "whenCh": "十一月二十八日早",
    "whenKnownCh": "十二月初九日",
    "where": "彰化城",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "彰化城"
    },
    "doc_id": "台2"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "本日早彰城失陷，路途梗塞，不能前遞",
          "reporter": "大肚社番",
          "subtitle": "匪徒攻陷彰化縣城",
          "whenCh": "十一月二十八日早",
          "where": "彰化城"
        }
      ],
      "hops": [
        {
          "from_person": "楊添",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "奴才接據署臺灣府淡水同知程峻、竹塹營守備董得魁會銜差役楊添投稟報...奴才接閱之下不勝駭異，當即傳喚該差楊添進署面加詢問。",
          "to_person": "任承恩",
          "whenAr": "1787/01/27",
          "whenCh": "十二月初九日亥刻"
        },
        {
          "from_person": "程峻、董得魁",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "淡水",
          "quote": "卑職等立即督率兵役，募集鄉勇、社番，扼要堵禦。現在彰化既為匪徒竊踞，通報內地文稟不能由正口直達，適有商船飄泊淡港，隨即專差搭船馳稟。",
          "to_person": "楊添",
          "whenAr": "",
          "whenCh": "十一月二十九日後"
        },
        {
          "from_person": "該番",
          "how": "轉述",
          "inferred": false,
          "layer": 3,
          "place": "淡水",
          "quote": "十一月二十九日，該番忽將原文帶回，並有彰邑大肚社番字寄淡屬大甲社通事...將原文附回。",
          "to_person": "程峻、董得魁",
          "whenAr": "1787/01/17",
          "whenCh": "十一月二十九日"
        },
        {
          "from_person": "大肚社番",
          "how": "書信",
          "inferred": false,
          "layer": 4,
          "place": "大肚社",
          "quote": "彰邑大肚社番字寄淡屬大甲社通事，據稱此月二十七夜，本縣俞在大墩地方拿匪遇害，本日早彰城失陷，路途梗塞，不能前遞，將原文附回。",
          "to_person": "大甲社通事",
          "whenAr": "",
          "whenCh": "十一月二十九日以前"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "本日早彰城失陷，路途梗塞，不能前遞",
            "reporter": "大肚社番",
            "subtitle": "匪徒攻陷彰化縣城",
            "whenCh": "十一月二十八日早",
            "where": "彰化城"
          }
        ],
        "hops": [
          {
            "from_person": "楊添",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "奴才接據署臺灣府淡水同知程峻、竹塹營守備董得魁會銜差役楊添投稟報...奴才接閱之下不勝駭異，當即傳喚該差楊添進署面加詢問。",
            "to_person": "任承恩",
            "whenAr": "1787/01/27",
            "whenCh": "十二月初九日亥刻"
          },
          {
            "from_person": "程峻、董得魁",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "淡水",
            "quote": "卑職等立即督率兵役，募集鄉勇、社番，扼要堵禦。現在彰化既為匪徒竊踞，通報內地文稟不能由正口直達，適有商船飄泊淡港，隨即專差搭船馳稟。",
            "to_person": "楊添",
            "whenAr": "",
            "whenCh": "十一月二十九日後"
          },
          {
            "from_person": "該番",
            "how": "轉述",
            "inferred": false,
            "layer": 3,
            "place": "淡水",
            "quote": "十一月二十九日，該番忽將原文帶回，並有彰邑大肚社番字寄淡屬大甲社通事...將原文附回。",
            "to_person": "程峻、董得魁",
            "whenAr": "1787/01/17",
            "whenCh": "十一月二十九日"
          },
          {
            "from_person": "大肚社番",
            "how": "書信",
            "inferred": false,
            "layer": 4,
            "place": "大肚社",
            "quote": "彰邑大肚社番字寄淡屬大甲社通事，據稱此月二十七夜，本縣俞在大墩地方拿匪遇害，本日早彰城失陷，路途梗塞，不能前遞，將原文附回。",
            "to_person": "大甲社通事",
            "whenAr": "",
            "whenCh": "十一月二十九日以前"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台3

```json
{
  "doc_id": "台3",
  "evTitle": "賊匪攻破彰化縣城",
  "event": {
    "description": "臺灣地方賊匪起事滋事，攻打並破壞彰化縣城。",
    "howKnown": "轉述",
    "quote": "臺灣又有賊匪滋事，攻破彰化縣城",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪攻破彰化縣城",
    "whenAr": "1786/12",
    "whenCh": "十一月",
    "whenKnownCh": "十二月初八日",
    "where": "彰化縣城",
    "who": [
      "賊匪"
    ],
    "who_loc": {
      "賊匪": "彰化縣城"
    },
    "doc_id": "台3"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "臺灣又有賊匪滋事，攻破彰化縣城",
          "reporter": "黃仕簡",
          "subtitle": "賊匪攻破彰化縣城",
          "whenCh": "十一月",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "黃仕簡",
          "how": "札達",
          "inferred": false,
          "layer": 1,
          "place": "",
          "quote": "先於十二月初八日，接到水師提臣黃仕簡札達，訪聞得臺灣又有賊匪滋事，攻破彰化縣城。現在調備兵船，俟一有確信，即當親往辦理，囑令奴才一體留心。等語。",
          "to_person": "任承恩",
          "whenAr": "1787/01/26",
          "whenCh": "十二月初八日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "臺灣又有賊匪滋事，攻破彰化縣城",
            "reporter": "黃仕簡",
            "subtitle": "賊匪攻破彰化縣城",
            "whenCh": "十一月",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "黃仕簡",
            "how": "札達",
            "inferred": false,
            "layer": 1,
            "place": "",
            "quote": "先於十二月初八日，接到水師提臣黃仕簡札達，訪聞得臺灣又有賊匪滋事，攻破彰化縣城。現在調備兵船，俟一有確信，即當親往辦理，囑令奴才一體留心。等語。",
            "to_person": "任承恩",
            "whenAr": "1787/01/26",
            "whenCh": "十二月初八日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台5

```json
{
  "doc_id": "台5",
  "evTitle": "匪徒於大墩殺害官員",
  "event": {
    "description": "乾隆五十一年十一月二十七日夜，林爽文等匪徒在大墩地方拒捕，並殺害前來擒拿的官員（本縣俞）。",
    "howKnown": "轉述",
    "quote": "本月二十七夜本縣俞在大墩地方拿匪被害",
    "relations": [
      {
        "evidence": "本月二十七夜本縣俞在大墩地方拿匪被害",
        "relation": "拒捕殺害",
        "relation_type": "conflict",
        "source": "林爽文",
        "target": "俞"
      }
    ],
    "side": "lin",
    "subtitle": "匪徒於大墩殺害官員",
    "whenAr": "1787/01/16",
    "whenCh": "十一月二十七日夜",
    "whenKnownCh": "十二月初十日",
    "where": "大墩",
    "who": [
      "林爽文",
      "俞"
    ],
    "who_loc": {
      "俞": "大墩",
      "林爽文": "大墩"
    },
    "doc_id": "台5"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "本月二十七夜本縣俞在大墩地方拿匪被害",
          "reporter": "彰邑大肚社番",
          "subtitle": "匪徒於大墩殺害官員",
          "whenCh": "十一月二十七日夜",
          "where": "大墩"
        }
      ],
      "hops": [
        {
          "from_person": "署北路淡水同知程峻、守備董得魁",
          "how": "會稟",
          "inferred": false,
          "layer": 1,
          "place": "廈門",
          "quote": "接據署北路淡水同知程峻、守備董得魁會稟稱...等情前來。",
          "to_person": "福建水師提督黃仕簡",
          "whenAr": "1787/02/27",
          "whenCh": "乾隆五十一年十二月初十日"
        },
        {
          "from_person": "淡屬大甲社通事",
          "how": "轉述",
          "inferred": true,
          "layer": 2,
          "place": "淡水",
          "quote": "大肚社番字寄淡屬大甲社通事，據稱",
          "to_person": "署北路淡水同知程峻、守備董得魁",
          "whenAr": "",
          "whenCh": "乾隆五十一年十一月二十九日之後"
        },
        {
          "from_person": "彰邑大肚社番",
          "how": "字寄",
          "inferred": false,
          "layer": 3,
          "place": "大肚社至大甲社",
          "quote": "十一月二十九日彰邑大肚社番字寄淡屬大甲社通事",
          "to_person": "淡屬大甲社通事",
          "whenAr": "1787/01/17",
          "whenCh": "乾隆五十一年十一月二十九日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "本月二十七夜本縣俞在大墩地方拿匪被害",
            "reporter": "彰邑大肚社番",
            "subtitle": "匪徒於大墩殺害官員",
            "whenCh": "十一月二十七日夜",
            "where": "大墩"
          }
        ],
        "hops": [
          {
            "from_person": "署北路淡水同知程峻、守備董得魁",
            "how": "會稟",
            "inferred": false,
            "layer": 1,
            "place": "廈門",
            "quote": "接據署北路淡水同知程峻、守備董得魁會稟稱...等情前來。",
            "to_person": "福建水師提督黃仕簡",
            "whenAr": "1787/02/27",
            "whenCh": "乾隆五十一年十二月初十日"
          },
          {
            "from_person": "淡屬大甲社通事",
            "how": "轉述",
            "inferred": true,
            "layer": 2,
            "place": "淡水",
            "quote": "大肚社番字寄淡屬大甲社通事，據稱",
            "to_person": "署北路淡水同知程峻、守備董得魁",
            "whenAr": "",
            "whenCh": "乾隆五十一年十一月二十九日之後"
          },
          {
            "from_person": "彰邑大肚社番",
            "how": "字寄",
            "inferred": false,
            "layer": 3,
            "place": "大肚社至大甲社",
            "quote": "十一月二十九日彰邑大肚社番字寄淡屬大甲社通事",
            "to_person": "淡屬大甲社通事",
            "whenAr": "1787/01/17",
            "whenCh": "乾隆五十一年十一月二十九日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台5

```json
{
  "doc_id": "台5",
  "evTitle": "匪徒攻陷彰化縣城",
  "event": {
    "description": "乾隆五十一年十一月二十九日辰刻，林爽文等匪徒聚集會黨攻打彰化縣城，至午刻將城池攻陷，文武官員生死不明。",
    "howKnown": "訪聞",
    "quote": "於十一月二十九日辰刻攻打彰化縣城，至午刻縣城被陷，文武官員不知生死之事",
    "relations": [],
    "side": "lin",
    "subtitle": "匪徒攻陷彰化縣城",
    "whenAr": "1787/01/18",
    "whenCh": "十一月二十九日",
    "whenKnownCh": "十二月初五日",
    "where": "彰化縣城",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "彰化縣城"
    },
    "doc_id": "台5"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "二早彰城失陷",
          "reporter": "彰邑大肚社番",
          "subtitle": "彰化縣城失陷",
          "whenCh": "二早",
          "where": "彰城"
        }
      ],
      "hops": [
        {
          "from_person": "署北路淡水同知程峻、守備董得魁",
          "how": "會稟",
          "inferred": false,
          "layer": 1,
          "place": "廈門",
          "quote": "接據署北路淡水同知程峻、守備董得魁會稟稱：彰化縣匪犯林爽文等結黨四虐，擒捕未獲。十一月二十九日彰邑大肚社番字寄淡屬大甲社通事，據稱：本月二十七夜本縣俞在大墩地方拿匪被害，二早彰城失陷，卑職等督同兵役，整齊鎗砲，募集鄉勇、社番，在於扼要處所分頭堵禦，一面救援。第兵力單薄，道路隔絕，伏祈迅發大兵拯救。再，彰城失陷被害文武官員若干，此時探聽維艱，未知的實，俟查確另稟。等情前來。",
          "to_person": "福建水師提督黃仕簡",
          "whenAr": "1787/01/28",
          "whenCh": "十二月初十日"
        },
        {
          "from_person": "淡屬大甲社通事",
          "how": "轉述",
          "inferred": true,
          "layer": 2,
          "place": "淡水",
          "quote": "十一月二十九日彰邑大肚社番字寄淡屬大甲社通事，據稱：本月二十七夜本縣俞在大墩地方拿匪被害，二早彰城失陷",
          "to_person": "署北路淡水同知程峻、守備董得魁",
          "whenAr": "",
          "whenCh": "十一月二十九日之後"
        },
        {
          "from_person": "彰邑大肚社番",
          "how": "字寄",
          "inferred": false,
          "layer": 3,
          "place": "大甲社",
          "quote": "十一月二十九日彰邑大肚社番字寄淡屬大甲社通事",
          "to_person": "淡屬大甲社通事",
          "whenAr": "1787/01/17",
          "whenCh": "十一月二十九日"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "於十一月二十九日辰刻攻打彰化縣城，至午刻縣城被陷，文武官員不知生死之事",
          "reporter": "未具名來源",
          "subtitle": "匪徒攻陷彰化縣城",
          "whenCh": "十一月二十九日辰刻至午刻",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "未具名來源",
          "how": "訪聞",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "茲本年十二月初五日戌刻，訪聞得臺灣彰化縣屬又有匪徒聚集會黨，於十一月二十九日辰刻攻打彰化縣城，至午刻縣城被陷，文武官員不知生死之事。",
          "to_person": "福建水師提督黃仕簡",
          "whenAr": "1787/01/23",
          "whenCh": "十二月初五日戌刻"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "二早彰城失陷",
            "reporter": "彰邑大肚社番",
            "subtitle": "彰化縣城失陷",
            "whenCh": "二早",
            "where": "彰城"
          }
        ],
        "hops": [
          {
            "from_person": "署北路淡水同知程峻、守備董得魁",
            "how": "會稟",
            "inferred": false,
            "layer": 1,
            "place": "廈門",
            "quote": "接據署北路淡水同知程峻、守備董得魁會稟稱：彰化縣匪犯林爽文等結黨四虐，擒捕未獲。十一月二十九日彰邑大肚社番字寄淡屬大甲社通事，據稱：本月二十七夜本縣俞在大墩地方拿匪被害，二早彰城失陷，卑職等督同兵役，整齊鎗砲，募集鄉勇、社番，在於扼要處所分頭堵禦，一面救援。第兵力單薄，道路隔絕，伏祈迅發大兵拯救。再，彰城失陷被害文武官員若干，此時探聽維艱，未知的實，俟查確另稟。等情前來。",
            "to_person": "福建水師提督黃仕簡",
            "whenAr": "1787/01/28",
            "whenCh": "十二月初十日"
          },
          {
            "from_person": "淡屬大甲社通事",
            "how": "轉述",
            "inferred": true,
            "layer": 2,
            "place": "淡水",
            "quote": "十一月二十九日彰邑大肚社番字寄淡屬大甲社通事，據稱：本月二十七夜本縣俞在大墩地方拿匪被害，二早彰城失陷",
            "to_person": "署北路淡水同知程峻、守備董得魁",
            "whenAr": "",
            "whenCh": "十一月二十九日之後"
          },
          {
            "from_person": "彰邑大肚社番",
            "how": "字寄",
            "inferred": false,
            "layer": 3,
            "place": "大甲社",
            "quote": "十一月二十九日彰邑大肚社番字寄淡屬大甲社通事",
            "to_person": "淡屬大甲社通事",
            "whenAr": "1787/01/17",
            "whenCh": "十一月二十九日"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "於十一月二十九日辰刻攻打彰化縣城，至午刻縣城被陷，文武官員不知生死之事",
            "reporter": "未具名來源",
            "subtitle": "匪徒攻陷彰化縣城",
            "whenCh": "十一月二十九日辰刻至午刻",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "未具名來源",
            "how": "訪聞",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "茲本年十二月初五日戌刻，訪聞得臺灣彰化縣屬又有匪徒聚集會黨，於十一月二十九日辰刻攻打彰化縣城，至午刻縣城被陷，文武官員不知生死之事。",
            "to_person": "福建水師提督黃仕簡",
            "whenAr": "1787/01/23",
            "whenCh": "十二月初五日戌刻"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台7

```json
{
  "doc_id": "台7",
  "evTitle": "林爽文結黨騷擾地方",
  "event": {
    "description": "乾隆五十一年十一月初，彰化縣匪徒林爽文結黨滋事，於地方四處騷擾。",
    "howKnown": "轉述",
    "quote": "十一月初間聞有彰化縣匪徒林爽文結黨四虐，騷擾地方",
    "relations": [],
    "side": "lin",
    "subtitle": "林爽文結黨騷擾地方",
    "whenAr": "1786/12",
    "whenCh": "十一月初",
    "whenKnownCh": "十一月二十九日",
    "where": "彰化縣",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "彰化縣"
    },
    "doc_id": "台7"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "十一月初間聞有彰化縣匪徒林爽文結黨四虐，騷擾地方",
          "reporter": "署淡防廳程峻、竹塹營守備董得魁",
          "subtitle": "林爽文結黨騷擾地方",
          "whenCh": "乾隆五十一年十一月初",
          "where": "彰化縣"
        }
      ],
      "hops": [
        {
          "from_person": "署淡防廳程峻、竹塹營守備董得魁",
          "how": "會稟",
          "inferred": false,
          "layer": 1,
          "place": "坊口",
          "quote": "接據署淡防廳程峻、竹塹營守備董得魁會稟：十一月初間聞有彰化縣匪徒林爽文結黨四虐，騷擾地方",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/01/29",
          "whenCh": "乾隆五十一年十二月十一日後"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "十一月初間聞有彰化縣匪徒林爽文結黨四虐，騷擾地方",
            "reporter": "署淡防廳程峻、竹塹營守備董得魁",
            "subtitle": "林爽文結黨騷擾地方",
            "whenCh": "乾隆五十一年十一月初",
            "where": "彰化縣"
          }
        ],
        "hops": [
          {
            "from_person": "署淡防廳程峻、竹塹營守備董得魁",
            "how": "會稟",
            "inferred": false,
            "layer": 1,
            "place": "坊口",
            "quote": "接據署淡防廳程峻、竹塹營守備董得魁會稟：十一月初間聞有彰化縣匪徒林爽文結黨四虐，騷擾地方",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/01/29",
            "whenCh": "乾隆五十一年十二月十一日後"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台7

```json
{
  "doc_id": "台7",
  "evTitle": "大墩襲殺知縣俞峻",
  "event": {
    "description": "乾隆五十一年十一月二十七日夜，彰化知縣俞峻在大墩地方搜捕民變匪徒時，遭林爽文部眾襲擊遇害。",
    "howKnown": "轉述",
    "quote": "十一月二十七夜，彰化俞知縣在大墩地方拿匪遇害",
    "relations": [
      {
        "evidence": "彰化俞知縣在大墩地方拿匪遇害",
        "relation": "殺害",
        "relation_type": "conflict",
        "source": "林爽文",
        "target": "俞峻"
      }
    ],
    "side": "lin",
    "subtitle": "大墩襲殺知縣俞峻",
    "whenAr": "1787/01/16",
    "whenCh": "十一月二十七日夜",
    "whenKnownCh": "十一月二十九日",
    "where": "大墩",
    "who": [
      "林爽文",
      "俞峻"
    ],
    "who_loc": {
      "俞峻": "大墩",
      "林爽文": "大墩"
    },
    "doc_id": "台7"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "十一月二十七夜，彰化俞知縣在大墩地方拿匪遇害",
          "reporter": "彰邑大肚社番",
          "subtitle": "大墩襲殺知縣俞峻",
          "whenCh": "十一月二十七夜",
          "where": "大墩"
        }
      ],
      "hops": [
        {
          "from_person": "程峻、董得魁",
          "how": "會稟",
          "inferred": false,
          "layer": 1,
          "place": "坊口",
          "quote": "途次坊口，接據署淡防廳程峻、竹塹營守備董得魁會稟",
          "to_person": "常青",
          "whenAr": "",
          "whenCh": "十二月十一日後"
        },
        {
          "from_person": "該番",
          "how": "帶回",
          "inferred": false,
          "layer": 2,
          "place": "淡水",
          "quote": "十一月二十九日，據該番帶回原文，並有彰邑大肚社番寄字淡屬大甲社通事",
          "to_person": "程峻、董得魁",
          "whenAr": "",
          "whenCh": "十一月二十九日"
        },
        {
          "from_person": "彰邑大肚社番",
          "how": "寄字",
          "inferred": false,
          "layer": 3,
          "place": "臺灣",
          "quote": "彰邑大肚社番寄字淡屬大甲社通事",
          "to_person": "淡屬大甲社通事",
          "whenAr": "",
          "whenCh": "十一月二十七夜之後"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "十一月二十七夜，彰化俞知縣在大墩地方拿匪遇害",
            "reporter": "彰邑大肚社番",
            "subtitle": "大墩襲殺知縣俞峻",
            "whenCh": "十一月二十七夜",
            "where": "大墩"
          }
        ],
        "hops": [
          {
            "from_person": "程峻、董得魁",
            "how": "會稟",
            "inferred": false,
            "layer": 1,
            "place": "坊口",
            "quote": "途次坊口，接據署淡防廳程峻、竹塹營守備董得魁會稟",
            "to_person": "常青",
            "whenAr": "",
            "whenCh": "十二月十一日後"
          },
          {
            "from_person": "該番",
            "how": "帶回",
            "inferred": false,
            "layer": 2,
            "place": "淡水",
            "quote": "十一月二十九日，據該番帶回原文，並有彰邑大肚社番寄字淡屬大甲社通事",
            "to_person": "程峻、董得魁",
            "whenAr": "",
            "whenCh": "十一月二十九日"
          },
          {
            "from_person": "彰邑大肚社番",
            "how": "寄字",
            "inferred": false,
            "layer": 3,
            "place": "臺灣",
            "quote": "彰邑大肚社番寄字淡屬大甲社通事",
            "to_person": "淡屬大甲社通事",
            "whenAr": "",
            "whenCh": "十一月二十七夜之後"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台7

```json
{
  "doc_id": "台7",
  "evTitle": "叛軍攻陷彰化縣城",
  "event": {
    "description": "乾隆五十一年十一月二十七日（或二十八日）清晨，林爽文部眾攻陷並竊踞彰化縣城，導致交通阻絕。",
    "howKnown": "轉述",
    "quote": "本日早彰城失陷，路途梗塞，不能前進...現在彰化既為匪徒竊踞",
    "relations": [],
    "side": "lin",
    "subtitle": "叛軍攻陷彰化縣城",
    "whenAr": "1787/01/16",
    "whenCh": "十一月二十七日早",
    "whenKnownCh": "十一月二十九日",
    "where": "彰化縣城",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "彰化縣城"
    },
    "doc_id": "台7"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "本日早彰城失陷，路途梗塞，不能前進",
          "reporter": "彰邑大肚社番",
          "subtitle": "叛軍攻陷彰化縣城",
          "whenCh": "乾隆五十一年十一月二十七日早",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "署淡防廳程峻、竹塹營守備董得魁",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "坊口",
          "quote": "途次坊口，接據署淡防廳程峻、竹塹營守備董得魁會稟：……等情到臣。",
          "to_person": "閩浙總督常青",
          "whenAr": "",
          "whenCh": "乾隆五十一年十一月十一日後"
        },
        {
          "from_person": "淡屬大甲社通事與派遞公文之番人",
          "how": "轉述",
          "inferred": false,
          "layer": 2,
          "place": "淡水",
          "quote": "十一月二十九日，據該番帶回原文，並有彰邑大肚社番寄字淡屬大甲社通事",
          "to_person": "署淡防廳程峻、竹塹營守備董得魁",
          "whenAr": "1787/01/18",
          "whenCh": "乾隆五十一年十一月二十九日"
        },
        {
          "from_person": "彰邑大肚社番",
          "how": "寄字",
          "inferred": false,
          "layer": 3,
          "place": "大肚社",
          "quote": "彰邑大肚社番寄字淡屬大甲社通事，據稱：十一月二十七夜，彰化俞知縣在大墩地方拿匪遇害，本日早彰城失陷",
          "to_person": "淡屬大甲社通事",
          "whenAr": "",
          "whenCh": "乾隆五十一年十一月二十七日後"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "本日早彰城失陷，路途梗塞，不能前進",
            "reporter": "彰邑大肚社番",
            "subtitle": "叛軍攻陷彰化縣城",
            "whenCh": "乾隆五十一年十一月二十七日早",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "署淡防廳程峻、竹塹營守備董得魁",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "坊口",
            "quote": "途次坊口，接據署淡防廳程峻、竹塹營守備董得魁會稟：……等情到臣。",
            "to_person": "閩浙總督常青",
            "whenAr": "",
            "whenCh": "乾隆五十一年十一月十一日後"
          },
          {
            "from_person": "淡屬大甲社通事與派遞公文之番人",
            "how": "轉述",
            "inferred": false,
            "layer": 2,
            "place": "淡水",
            "quote": "十一月二十九日，據該番帶回原文，並有彰邑大肚社番寄字淡屬大甲社通事",
            "to_person": "署淡防廳程峻、竹塹營守備董得魁",
            "whenAr": "1787/01/18",
            "whenCh": "乾隆五十一年十一月二十九日"
          },
          {
            "from_person": "彰邑大肚社番",
            "how": "寄字",
            "inferred": false,
            "layer": 3,
            "place": "大肚社",
            "quote": "彰邑大肚社番寄字淡屬大甲社通事，據稱：十一月二十七夜，彰化俞知縣在大墩地方拿匪遇害，本日早彰城失陷",
            "to_person": "淡屬大甲社通事",
            "whenAr": "",
            "whenCh": "乾隆五十一年十一月二十七日後"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台6

```json
{
  "doc_id": "台6",
  "evTitle": "匪徒攻陷彰化縣城",
  "event": {
    "description": "臺灣民變匪徒攻陷彰化縣城，並殺害駐城官員。",
    "howKnown": "轉述",
    "quote": "臺匪攻陷彰化縣城殺官",
    "relations": [],
    "side": "lin",
    "subtitle": "匪徒攻陷彰化縣城",
    "whenAr": "1787/01",
    "whenCh": "十一月底",
    "whenKnownCh": "十二月初十日前",
    "where": "彰化縣城",
    "who": [
      "臺匪"
    ],
    "who_loc": {
      "臺匪": "彰化縣城"
    },
    "doc_id": "台6"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "臺匪攻陷彰化縣城殺官",
          "reporter": "臺灣鎮總兵柴大紀、臺灣道永福",
          "subtitle": "匪徒攻陷彰化縣城",
          "whenCh": "十一月底",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "臺灣鎮總兵柴大紀、臺灣道永福",
          "how": "咨會",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "茲十一日再次接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱",
          "to_person": "福建水師提督黃仕簡",
          "whenAr": "",
          "whenCh": "十二月十一日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "臺匪攻陷彰化縣城殺官",
            "reporter": "臺灣鎮總兵柴大紀、臺灣道永福",
            "subtitle": "匪徒攻陷彰化縣城",
            "whenCh": "十一月底",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "臺灣鎮總兵柴大紀、臺灣道永福",
            "how": "咨會",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "茲十一日再次接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱",
            "to_person": "福建水師提督黃仕簡",
            "whenAr": "",
            "whenCh": "十二月十一日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台6

```json
{
  "doc_id": "台6",
  "evTitle": "林爽文等結黨搶劫",
  "event": {
    "description": "大里杙等庄之奸民林爽文、王芬等人糾集黨羽，乘值歲暮之際在地方進行搶劫。",
    "howKnown": "訪聞",
    "quote": "大里杙等庄有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
    "relations": [
      {
        "evidence": "林爽文、王芬等結黨",
        "relation": "結黨",
        "relation_type": "ally",
        "source": "林爽文",
        "target": "王芬"
      }
    ],
    "side": "lin",
    "subtitle": "林爽文等結黨搶劫",
    "whenAr": "1786/12",
    "whenCh": "歲暮",
    "whenKnownCh": "十一月",
    "where": "大里杙等庄",
    "who": [
      "林爽文",
      "王芬"
    ],
    "who_loc": {
      "林爽文": "大里杙",
      "王芬": "大里杙"
    },
    "doc_id": "台6"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "大里杙等庄有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
          "reporter": "臺灣鎮總兵柴大紀、臺灣道永福",
          "subtitle": "林爽文等結黨搶劫",
          "whenCh": "歲暮",
          "where": "大里杙等庄"
        }
      ],
      "hops": [
        {
          "from_person": "臺灣鎮總兵柴大紀、臺灣道永福",
          "how": "咨會",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "茲十一日再次接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱：訪聞北路一帶深山地方遼闊，大里杙等庄有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
          "to_person": "福建水師提督黃仕簡",
          "whenAr": "1787/01/29",
          "whenCh": "十二月十一日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "大里杙等庄有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
            "reporter": "臺灣鎮總兵柴大紀、臺灣道永福",
            "subtitle": "林爽文等結黨搶劫",
            "whenCh": "歲暮",
            "where": "大里杙等庄"
          }
        ],
        "hops": [
          {
            "from_person": "臺灣鎮總兵柴大紀、臺灣道永福",
            "how": "咨會",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "茲十一日再次接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱：訪聞北路一帶深山地方遼闊，大里杙等庄有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
            "to_person": "福建水師提督黃仕簡",
            "whenAr": "1787/01/29",
            "whenCh": "十二月十一日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台6

```json
{
  "doc_id": "台6",
  "evTitle": "賊匪夜劫大墩營盤",
  "event": {
    "description": "十一月二十七日夜四更，數千名賊匪散而復聚，前往搶劫大墩營盤。",
    "howKnown": "轉述",
    "quote": "十一月二十七夜四更時候，賊匪散而復聚，竟有數千人，往劫大墩營盤",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪夜劫大墩營盤",
    "whenAr": "1787/01/15",
    "whenCh": "十一月二十七日",
    "whenKnownCh": "十二月初一日",
    "where": "大墩",
    "who": [
      "賊匪"
    ],
    "who_loc": {
      "賊匪": "大墩"
    },
    "doc_id": "台6"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "十一月二十七夜四更時候，賊匪散而復聚，竟有數千人，往劫大墩營盤",
          "reporter": "王宗武",
          "subtitle": "賊匪夜劫大墩營盤",
          "whenCh": "十一月二十七日夜四更",
          "where": "大墩"
        }
      ],
      "hops": [
        {
          "from_person": "柴大紀、永福",
          "how": "咨會",
          "inferred": false,
          "layer": 1,
          "place": "臺灣至福建",
          "quote": "茲十一日再次接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱",
          "to_person": "黃仕簡",
          "whenAr": "1787/01/29",
          "whenCh": "十二月十一日"
        },
        {
          "from_person": "王宗武",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "臺灣",
          "quote": "茲十二月初一日辰刻，據北路中營都司王宗武報稱",
          "to_person": "柴大紀、永福",
          "whenAr": "1787/01/19",
          "whenCh": "十二月初一日辰刻"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "十一月二十七夜四更時候，賊匪散而復聚，竟有數千人，往劫大墩營盤",
            "reporter": "王宗武",
            "subtitle": "賊匪夜劫大墩營盤",
            "whenCh": "十一月二十七日夜四更",
            "where": "大墩"
          }
        ],
        "hops": [
          {
            "from_person": "柴大紀、永福",
            "how": "咨會",
            "inferred": false,
            "layer": 1,
            "place": "臺灣至福建",
            "quote": "茲十一日再次接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱",
            "to_person": "黃仕簡",
            "whenAr": "1787/01/29",
            "whenCh": "十二月十一日"
          },
          {
            "from_person": "王宗武",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "臺灣",
            "quote": "茲十二月初一日辰刻，據北路中營都司王宗武報稱",
            "to_person": "柴大紀、永福",
            "whenAr": "1787/01/19",
            "whenCh": "十二月初一日辰刻"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台6

```json
{
  "doc_id": "台6",
  "evTitle": "賊匪大肚溪邊截路",
  "event": {
    "description": "賊匪於大肚溪邊聚集並截斷道路，阻斷官軍信息交通。",
    "howKnown": "轉述",
    "quote": "並於大肚溪邊聚匪截路，以致信息不通",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪大肚溪邊截路",
    "whenAr": "1787/01/15",
    "whenCh": "十一月二十七日",
    "whenKnownCh": "十二月初一日",
    "where": "大肚溪",
    "who": [
      "賊匪"
    ],
    "who_loc": {
      "賊匪": "大肚溪"
    },
    "doc_id": "台6"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "並於大肚溪邊聚匪截路，以致信息不通",
          "reporter": "北路中營都司王宗武",
          "subtitle": "賊匪大肚溪邊截路",
          "whenCh": "十一月二十七夜四更時候",
          "where": "大肚溪"
        }
      ],
      "hops": [
        {
          "from_person": "臺灣鎮總兵柴大紀、臺灣道永福",
          "how": "咨會",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "茲十一日再次接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱",
          "to_person": "福建水師提督黃仕簡",
          "whenAr": "1787/01/29",
          "whenCh": "十二月十一日"
        },
        {
          "from_person": "北路中營都司王宗武",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "臺灣府城",
          "quote": "茲十二月初一日辰刻，據北路中營都司王宗武報稱",
          "to_person": "臺灣鎮總兵柴大紀、臺灣道永福",
          "whenAr": "1787/01/19",
          "whenCh": "十二月初一日辰刻"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "並於大肚溪邊聚匪截路，以致信息不通",
            "reporter": "北路中營都司王宗武",
            "subtitle": "賊匪大肚溪邊截路",
            "whenCh": "十一月二十七夜四更時候",
            "where": "大肚溪"
          }
        ],
        "hops": [
          {
            "from_person": "臺灣鎮總兵柴大紀、臺灣道永福",
            "how": "咨會",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "茲十一日再次接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱",
            "to_person": "福建水師提督黃仕簡",
            "whenAr": "1787/01/29",
            "whenCh": "十二月十一日"
          },
          {
            "from_person": "北路中營都司王宗武",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "臺灣府城",
            "quote": "茲十二月初一日辰刻，據北路中營都司王宗武報稱",
            "to_person": "臺灣鎮總兵柴大紀、臺灣道永福",
            "whenAr": "1787/01/19",
            "whenCh": "十二月初一日辰刻"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台6

```json
{
  "doc_id": "台6",
  "evTitle": "南北投匪徒糾集滋事",
  "event": {
    "description": "南投、北投一帶有匪徒糾集滋事，並傳聞準備進攻彰化縣城。",
    "howKnown": "轉述",
    "quote": "南、微投一帶亦有匪徒糾集滋事，且聞要攻縣城",
    "relations": [],
    "side": "lin",
    "subtitle": "南北投匪徒糾集滋事",
    "whenAr": "1787/01",
    "whenCh": "十一月底",
    "whenKnownCh": "十二月初一日",
    "where": "南投、北投",
    "who": [
      "匪徒"
    ],
    "who_loc": {
      "匪徒": "南投、北投"
    },
    "doc_id": "台6"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "南、北投一帶亦有匪徒糾集滋事，且聞要攻縣城",
          "reporter": "北路中營都司王宗武",
          "subtitle": "南北投匪徒糾集滋事",
          "whenCh": "乾隆五十一年十一月底",
          "where": "南投、北投"
        }
      ],
      "hops": [
        {
          "from_person": "臺灣鎮總兵柴大紀、臺灣道永福",
          "how": "咨會",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "茲十一日再次接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱",
          "to_person": "福建水師提督黃仕簡",
          "whenAr": "1787/01/29",
          "whenCh": "乾隆五十一年十二月十一日"
        },
        {
          "from_person": "北路中營都司王宗武",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "臺灣府城",
          "quote": "茲十二月初一日辰刻，據北路中營都司王宗武報稱",
          "to_person": "臺灣鎮總兵柴大紀、臺灣道永福",
          "whenAr": "1787/01/19",
          "whenCh": "乾隆五十一年十二月初一日辰刻"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "南、北投一帶亦有匪徒糾集滋事，且聞要攻縣城",
            "reporter": "北路中營都司王宗武",
            "subtitle": "南北投匪徒糾集滋事",
            "whenCh": "乾隆五十一年十一月底",
            "where": "南投、北投"
          }
        ],
        "hops": [
          {
            "from_person": "臺灣鎮總兵柴大紀、臺灣道永福",
            "how": "咨會",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "茲十一日再次接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱",
            "to_person": "福建水師提督黃仕簡",
            "whenAr": "1787/01/29",
            "whenCh": "乾隆五十一年十二月十一日"
          },
          {
            "from_person": "北路中營都司王宗武",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "臺灣府城",
            "quote": "茲十二月初一日辰刻，據北路中營都司王宗武報稱",
            "to_person": "臺灣鎮總兵柴大紀、臺灣道永福",
            "whenAr": "1787/01/19",
            "whenCh": "乾隆五十一年十二月初一日辰刻"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台9

```json
{
  "doc_id": "台9",
  "evTitle": "賊匪攻陷彰化縣城",
  "event": {
    "description": "賊匪攻陷彰化縣城，殺害城內官員，並阻絕往來文報。",
    "howKnown": "轉述",
    "quote": "彰化縣城被賊匪攻陷、殺害官員、阻絕文報各情由",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪攻陷彰化縣城",
    "whenAr": "",
    "whenCh": "十二月初九日前",
    "whenKnownCh": "十二月初九日",
    "where": "彰化縣城",
    "who": [
      "賊匪"
    ],
    "who_loc": {
      "賊匪": "彰化縣城"
    },
    "doc_id": "台9"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "彰化縣城被賊匪攻陷、殺害官員、阻絕文報各情由",
          "reporter": "程峻、董得魁",
          "subtitle": "賊匪攻陷彰化縣城",
          "whenCh": "十二月初九日前",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "程峻、董得魁",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "十二月初九日，奴才接據臺灣淡防同知程峻、竹塹營守備董得魁稟報，彰化縣城被賊匪攻陷、殺害官員、阻絕文報各情由",
          "to_person": "任承恩",
          "whenAr": "1787/01/27",
          "whenCh": "十二月初九日"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "又因彰化地方已被賊踞，不能前往府城",
          "reporter": "程必大",
          "subtitle": "賊匪攻陷彰化縣城",
          "whenCh": "十二月初七日前",
          "where": "彰化縣"
        }
      ],
      "hops": [
        {
          "from_person": "程必大",
          "how": "口述",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "十二日，有該廳程峻之子程必大奔赴奴才轅門求見，奴才立即傳進。據，程必大懷取淡防同知關防請求救援...又因彰化地方已被賊踞，不能前往府城",
          "to_person": "任承恩",
          "whenAr": "1787/01/30",
          "whenCh": "十二月十二日"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "彰化地方已被賊踞，不得往府求救",
          "reporter": "虞文光",
          "subtitle": "賊匪攻陷彰化縣城",
          "whenCh": "十二月初七日前",
          "where": "彰化縣"
        }
      ],
      "hops": [
        {
          "from_person": "虞文光",
          "how": "口述",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "問據外委虞文光供...彰化地方已被賊踞，不得往府求救",
          "to_person": "任承恩",
          "whenAr": "1787/01/30",
          "whenCh": "十二月十二日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "彰化縣城被賊匪攻陷、殺害官員、阻絕文報各情由",
            "reporter": "程峻、董得魁",
            "subtitle": "賊匪攻陷彰化縣城",
            "whenCh": "十二月初九日前",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "程峻、董得魁",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "十二月初九日，奴才接據臺灣淡防同知程峻、竹塹營守備董得魁稟報，彰化縣城被賊匪攻陷、殺害官員、阻絕文報各情由",
            "to_person": "任承恩",
            "whenAr": "1787/01/27",
            "whenCh": "十二月初九日"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "又因彰化地方已被賊踞，不能前往府城",
            "reporter": "程必大",
            "subtitle": "賊匪攻陷彰化縣城",
            "whenCh": "十二月初七日前",
            "where": "彰化縣"
          }
        ],
        "hops": [
          {
            "from_person": "程必大",
            "how": "口述",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "十二日，有該廳程峻之子程必大奔赴奴才轅門求見，奴才立即傳進。據，程必大懷取淡防同知關防請求救援...又因彰化地方已被賊踞，不能前往府城",
            "to_person": "任承恩",
            "whenAr": "1787/01/30",
            "whenCh": "十二月十二日"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "彰化地方已被賊踞，不得往府求救",
            "reporter": "虞文光",
            "subtitle": "賊匪攻陷彰化縣城",
            "whenCh": "十二月初七日前",
            "where": "彰化縣"
          }
        ],
        "hops": [
          {
            "from_person": "虞文光",
            "how": "口述",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "問據外委虞文光供...彰化地方已被賊踞，不得往府求救",
            "to_person": "任承恩",
            "whenAr": "1787/01/30",
            "whenCh": "十二月十二日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台9

```json
{
  "doc_id": "台9",
  "evTitle": "中港之役賊匪擊潰官軍",
  "event": {
    "description": "賊匪於中港地方與淡水同知程峻、守備董得魁率領的兵勇交戰。因賊匪人數眾多，官軍抵敵不住而潰散，程峻生死不明。",
    "howKnown": "轉述",
    "quote": "我父親會同董守備，帶領兵役、鄉勇前赴中港地方堵禦，賊匪眾多，抵敵不住，我父親存亡不知",
    "relations": [
      {
        "evidence": "賊匪眾多，抵敵不住",
        "relation": "擊敗",
        "relation_type": "conflict",
        "source": "賊匪",
        "target": "程峻"
      },
      {
        "evidence": "賊匪眾多，抵敵不住",
        "relation": "擊敗",
        "relation_type": "conflict",
        "source": "賊匪",
        "target": "董得魁"
      },
      {
        "evidence": "我父親會同董守備，帶領兵役、鄉勇前赴中港地方堵禦",
        "relation": "會同堵禦",
        "relation_type": "ally",
        "source": "程峻",
        "target": "董得魁"
      }
    ],
    "side": "lin",
    "subtitle": "中港之役賊匪擊潰官軍",
    "whenAr": "",
    "whenCh": "十二月初七日前",
    "whenKnownCh": "十二月十二日",
    "where": "中港",
    "who": [
      "賊匪",
      "程峻",
      "董得魁"
    ],
    "who_loc": {
      "程峻": "中港",
      "董得魁": "中港",
      "賊匪": "中港"
    },
    "doc_id": "台9"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "我父親會同董守備，帶領兵役、鄉勇前赴中港地方堵禦，賊匪眾多，抵敵不住，我父親存亡不知",
          "reporter": "程必大",
          "subtitle": "中港之役賊匪擊潰官軍",
          "whenCh": "十二月初七日前",
          "where": "中港"
        }
      ],
      "hops": [
        {
          "from_person": "程必大",
          "how": "口述",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "茲於十二日，有該廳程峻之子程必大奔赴奴才轅門求見，奴才立即傳進。據，程必大懷取淡防同知關防請求救援...據程必大供",
          "to_person": "任承恩",
          "whenAr": "1787/01/30",
          "whenCh": "十二月十二日"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "連日隨同守備董得魁，會同程廳官，帶兵在中港地方堵禦賊匪；到本月初七日不料賊匪漸多，兵少不敵",
          "reporter": "虞文光",
          "subtitle": "中港之役賊匪擊潰官軍",
          "whenCh": "十二月初七日",
          "where": "中港"
        }
      ],
      "hops": [
        {
          "from_person": "虞文光、王元浩",
          "how": "口述",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "又有北路竹塹營外委虞文光、兵丁王元浩亦先後投到求救。奴才率同地方官詢問。據外委虞文光供...又問，據兵丁王元浩供同",
          "to_person": "任承恩",
          "whenAr": "1787/01/30",
          "whenCh": "十二月十二日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "我父親會同董守備，帶領兵役、鄉勇前赴中港地方堵禦，賊匪眾多，抵敵不住，我父親存亡不知",
            "reporter": "程必大",
            "subtitle": "中港之役賊匪擊潰官軍",
            "whenCh": "十二月初七日前",
            "where": "中港"
          }
        ],
        "hops": [
          {
            "from_person": "程必大",
            "how": "口述",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "茲於十二日，有該廳程峻之子程必大奔赴奴才轅門求見，奴才立即傳進。據，程必大懷取淡防同知關防請求救援...據程必大供",
            "to_person": "任承恩",
            "whenAr": "1787/01/30",
            "whenCh": "十二月十二日"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "連日隨同守備董得魁，會同程廳官，帶兵在中港地方堵禦賊匪；到本月初七日不料賊匪漸多，兵少不敵",
            "reporter": "虞文光",
            "subtitle": "中港之役賊匪擊潰官軍",
            "whenCh": "十二月初七日",
            "where": "中港"
          }
        ],
        "hops": [
          {
            "from_person": "虞文光、王元浩",
            "how": "口述",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "又有北路竹塹營外委虞文光、兵丁王元浩亦先後投到求救。奴才率同地方官詢問。據外委虞文光供...又問，據兵丁王元浩供同",
            "to_person": "任承恩",
            "whenAr": "1787/01/30",
            "whenCh": "十二月十二日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台9

```json
{
  "doc_id": "台9",
  "evTitle": "賊匪攻入竹塹肆行擄搶",
  "event": {
    "description": "賊匪於十二月初七日攻抵竹塹，並在當地四處進行擄掠與搶奪。",
    "howKnown": "轉述",
    "quote": "賊匪於十二月初七日已到竹塹，四行擄搶",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪攻入竹塹肆行擄搶",
    "whenAr": "1787/01/25",
    "whenCh": "十二月初七日",
    "whenKnownCh": "十二月十二日",
    "where": "竹塹",
    "who": [
      "賊匪"
    ],
    "who_loc": {
      "賊匪": "竹塹"
    },
    "doc_id": "台9"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "賊匪於十二月初七日已到竹塹，四行擄搶",
          "reporter": "程必大",
          "subtitle": "賊匪攻入竹塹肆行擄搶",
          "whenCh": "十二月初七日",
          "where": "竹塹"
        }
      ],
      "hops": [
        {
          "from_person": "程必大",
          "how": "口述",
          "inferred": false,
          "layer": 1,
          "place": "泉州（任承恩轅門）",
          "quote": "茲於十二日，有該廳程峻之子程必大奔赴奴才轅門求見，奴才立即傳進。...據程必大供：...賊匪於十二月初七日已到竹塹，四行擄搶",
          "to_person": "任承恩",
          "whenAr": "1787/01/30",
          "whenCh": "十二月十二日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "賊匪於十二月初七日已到竹塹，四行擄搶",
            "reporter": "程必大",
            "subtitle": "賊匪攻入竹塹肆行擄搶",
            "whenCh": "十二月初七日",
            "where": "竹塹"
          }
        ],
        "hops": [
          {
            "from_person": "程必大",
            "how": "口述",
            "inferred": false,
            "layer": 1,
            "place": "泉州（任承恩轅門）",
            "quote": "茲於十二日，有該廳程峻之子程必大奔赴奴才轅門求見，奴才立即傳進。...據程必大供：...賊匪於十二月初七日已到竹塹，四行擄搶",
            "to_person": "任承恩",
            "whenAr": "1787/01/30",
            "whenCh": "十二月十二日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台11

```json
{
  "doc_id": "台11",
  "evTitle": "林爽文等結黨搶劫",
  "event": {
    "description": "奸民林爽文、王芬等在大里杙等庄結黨，乘值歲暮之際在地方進行搶劫滋事。",
    "howKnown": "訪聞",
    "quote": "大里杙等庄有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
    "relations": [],
    "side": "lin",
    "subtitle": "林爽文等結黨搶劫",
    "whenAr": "",
    "whenCh": "歲暮",
    "whenKnownCh": "十二月初二日",
    "where": "大里杙",
    "who": [
      "林爽文",
      "王芬"
    ],
    "who_loc": {
      "林爽文": "大里杙",
      "王芬": "大里杙"
    },
    "doc_id": "台11"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "大里杙等庄有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
          "reporter": "永福",
          "subtitle": "林爽文等結黨搶劫",
          "whenCh": "歲暮",
          "where": "大里杙等庄"
        }
      ],
      "hops": [
        {
          "from_person": "柴大紀、永福",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "塗嶺",
          "quote": "茲於十三日行抵塗嶺，途次接據臺灣鎮、道十二月初二日來稟……先行具稟。等情到臣。",
          "to_person": "常青",
          "whenAr": "1787/01/31",
          "whenCh": "乾隆五十一年十二月十三日"
        },
        {
          "from_person": "永福",
          "how": "訪聞",
          "inferred": true,
          "layer": 2,
          "place": "臺灣",
          "quote": "職道等訪聞北路一帶深山，地方遼闊，大里杙等庄有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
          "to_person": "柴大紀",
          "whenAr": "",
          "whenCh": "乾隆五十一年十二月初二日之前"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "大里杙等庄有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
            "reporter": "永福",
            "subtitle": "林爽文等結黨搶劫",
            "whenCh": "歲暮",
            "where": "大里杙等庄"
          }
        ],
        "hops": [
          {
            "from_person": "柴大紀、永福",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "塗嶺",
            "quote": "茲於十三日行抵塗嶺，途次接據臺灣鎮、道十二月初二日來稟……先行具稟。等情到臣。",
            "to_person": "常青",
            "whenAr": "1787/01/31",
            "whenCh": "乾隆五十一年十二月十三日"
          },
          {
            "from_person": "永福",
            "how": "訪聞",
            "inferred": true,
            "layer": 2,
            "place": "臺灣",
            "quote": "職道等訪聞北路一帶深山，地方遼闊，大里杙等庄有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
            "to_person": "柴大紀",
            "whenAr": "",
            "whenCh": "乾隆五十一年十二月初二日之前"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台11

```json
{
  "doc_id": "台11",
  "evTitle": "賊匪夜劫大墩營盤",
  "event": {
    "description": "十一月二十七日夜四更，數千名賊匪散而復聚，前往劫掠大墩營盤，並在大肚溪邊截斷道路，阻絕官兵信息往來。",
    "howKnown": "轉述",
    "quote": "二十七日夜四更時候，賊匪散而復聚，竟有數千人，往劫大墩營盤，並於大肚溪邊截路，以致信息不通。",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪夜劫大墩營盤",
    "whenAr": "1787/01/16",
    "whenCh": "十一月二十七日夜",
    "whenKnownCh": "十二月初一日",
    "where": "大墩",
    "who": [],
    "who_loc": {},
    "doc_id": "台11"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "二十七日夜四更時候，賊匪散而復聚，竟有數千人，往劫大墩營盤，並於大肚溪邊截路，以致信息不通。",
          "reporter": "中營王都司",
          "subtitle": "賊匪夜劫大墩營盤",
          "whenCh": "乾隆五十一年十一月二十七日夜四更",
          "where": "大墩"
        }
      ],
      "hops": [
        {
          "from_person": "臺灣鎮柴大紀、臺灣道永福",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "塗嶺",
          "quote": "茲於十三日行抵塗嶺，途次接據臺灣鎮、道十二月初二日來稟...先行具稟。等情到臣。",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/01/31",
          "whenCh": "乾隆五十一年十二月十三日"
        },
        {
          "from_person": "中營王都司",
          "how": "報稱",
          "inferred": false,
          "layer": 2,
          "place": "臺灣府城",
          "quote": "茲本月初一日接據中營王都司報稱",
          "to_person": "臺灣鎮柴大紀、臺灣道永福",
          "whenAr": "1787/01/19",
          "whenCh": "乾隆五十一年十二月初一日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "二十七日夜四更時候，賊匪散而復聚，竟有數千人，往劫大墩營盤，並於大肚溪邊截路，以致信息不通。",
            "reporter": "中營王都司",
            "subtitle": "賊匪夜劫大墩營盤",
            "whenCh": "乾隆五十一年十一月二十七日夜四更",
            "where": "大墩"
          }
        ],
        "hops": [
          {
            "from_person": "臺灣鎮柴大紀、臺灣道永福",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "塗嶺",
            "quote": "茲於十三日行抵塗嶺，途次接據臺灣鎮、道十二月初二日來稟...先行具稟。等情到臣。",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/01/31",
            "whenCh": "乾隆五十一年十二月十三日"
          },
          {
            "from_person": "中營王都司",
            "how": "報稱",
            "inferred": false,
            "layer": 2,
            "place": "臺灣府城",
            "quote": "茲本月初一日接據中營王都司報稱",
            "to_person": "臺灣鎮柴大紀、臺灣道永福",
            "whenAr": "1787/01/19",
            "whenCh": "乾隆五十一年十二月初一日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台11

```json
{
  "doc_id": "台11",
  "evTitle": "彰化城陷知縣遇害",
  "event": {
    "description": "十一月二十七日夜，彰化匪徒林爽文等結黨四處滋擾，導致前往搜捕的彰化知縣俞峻遇害，彰化縣城隨之失陷，道路梗塞。",
    "howKnown": "轉述",
    "quote": "彰化匪徒林爽文等結黨四擾，十一月二十七夜彰化俞令拿匪遇害，彰城失陷，路途梗塞。",
    "relations": [
      {
        "evidence": "彰化俞令拿匪遇害",
        "relation": "遇害",
        "relation_type": "conflict",
        "source": "林爽文",
        "target": "俞峻"
      }
    ],
    "side": "lin",
    "subtitle": "彰化城陷知縣遇害",
    "whenAr": "1787/01/16",
    "whenCh": "十一月二十七日夜",
    "whenKnownCh": "十二月十一日",
    "where": "彰化縣城",
    "who": [
      "林爽文",
      "俞峻"
    ],
    "who_loc": {
      "俞峻": "彰化縣城",
      "林爽文": "彰化縣城"
    },
    "doc_id": "台11"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "彰化匪徒林爽文等結黨四擾，十一月二十七夜彰化俞令拿匪遇害，彰城失陷，路途梗塞。",
          "reporter": "署淡水同知程峻等",
          "subtitle": "彰化城陷知縣遇害",
          "whenCh": "十一月二十七日夜",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "署淡水同知程峻等",
          "how": "會稟",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "臣於十二月十一日接到署淡水同知程峻等會稟：彰化匪徒林爽文等結黨四擾，十一月二十七夜彰化俞令拿匪遇害，彰城失陷，路途梗塞。等情。",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/01/29",
          "whenCh": "十二月十一日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "彰化匪徒林爽文等結黨四擾，十一月二十七夜彰化俞令拿匪遇害，彰城失陷，路途梗塞。",
            "reporter": "署淡水同知程峻等",
            "subtitle": "彰化城陷知縣遇害",
            "whenCh": "十一月二十七日夜",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "署淡水同知程峻等",
            "how": "會稟",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "臣於十二月十一日接到署淡水同知程峻等會稟：彰化匪徒林爽文等結黨四擾，十一月二十七夜彰化俞令拿匪遇害，彰城失陷，路途梗塞。等情。",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/01/29",
            "whenCh": "十二月十一日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台11

```json
{
  "doc_id": "台11",
  "evTitle": "南北投匪徒糾集滋事",
  "event": {
    "description": "南投、北投一帶亦有匪徒糾集滋事，並聲稱準備進攻彰化縣城。",
    "howKnown": "轉述",
    "quote": "南、北投一帶亦有匪徒糾集滋事，且聞要攻縣城。",
    "relations": [],
    "side": "lin",
    "subtitle": "南北投匪徒糾集滋事",
    "whenAr": "1787/01/17",
    "whenCh": "十一月二十八日",
    "whenKnownCh": "十二月初一日",
    "where": "南投",
    "who": [],
    "who_loc": {},
    "doc_id": "台11"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "南、北投一帶亦有匪徒糾集滋事，且聞要攻縣城。",
          "reporter": "中營王都司",
          "subtitle": "南北投匪徒糾集滋事",
          "whenCh": "乾隆五十一年十一月二十八日",
          "where": "南投、北投"
        }
      ],
      "hops": [
        {
          "from_person": "臺灣鎮柴大紀、臺灣道永福",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "臺灣至塗嶺",
          "quote": "接據臺灣鎮、道十二月初二日來稟……除恭摺馳奏外，合將調兵起程、剿捕緣由，先行具稟。",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/01/20",
          "whenCh": "乾隆五十一年十二月初二日"
        },
        {
          "from_person": "中營王都司",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "臺灣府城",
          "quote": "茲本月初一日接據中營王都司報稱：……南、北投一帶亦有匪徒糾集滋事，且聞要攻縣城。",
          "to_person": "臺灣鎮柴大紀、臺灣道永福",
          "whenAr": "1787/01/19",
          "whenCh": "乾隆五十一年十二月初一日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "南、北投一帶亦有匪徒糾集滋事，且聞要攻縣城。",
            "reporter": "中營王都司",
            "subtitle": "南北投匪徒糾集滋事",
            "whenCh": "乾隆五十一年十一月二十八日",
            "where": "南投、北投"
          }
        ],
        "hops": [
          {
            "from_person": "臺灣鎮柴大紀、臺灣道永福",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "臺灣至塗嶺",
            "quote": "接據臺灣鎮、道十二月初二日來稟……除恭摺馳奏外，合將調兵起程、剿捕緣由，先行具稟。",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/01/20",
            "whenCh": "乾隆五十一年十二月初二日"
          },
          {
            "from_person": "中營王都司",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "臺灣府城",
            "quote": "茲本月初一日接據中營王都司報稱：……南、北投一帶亦有匪徒糾集滋事，且聞要攻縣城。",
            "to_person": "臺灣鎮柴大紀、臺灣道永福",
            "whenAr": "1787/01/19",
            "whenCh": "乾隆五十一年十二月初一日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台8

```json
{
  "doc_id": "台8",
  "evTitle": "楊光勳等結會劫囚滋事",
  "event": {
    "description": "諸羅縣民人楊光勳等人結會樹黨，並聚眾劫囚滋事，引發地方動亂，隨後部分同夥如張烈、賴榮等人脫逃。",
    "howKnown": "到地查辦",
    "quote": "諸羅縣奸民楊光勳等結會樹黨，劫囚滋事",
    "relations": [
      {
        "evidence": "楊光勳等結會樹黨",
        "relation": "同夥",
        "relation_type": "ally",
        "source": "張烈",
        "target": "楊光勳"
      },
      {
        "evidence": "楊光勳等結會樹黨",
        "relation": "同夥",
        "relation_type": "ally",
        "source": "賴榮",
        "target": "楊光勳"
      },
      {
        "evidence": "楊光勳等結會樹黨",
        "relation": "同夥",
        "relation_type": "ally",
        "source": "葉省",
        "target": "楊光勳"
      },
      {
        "evidence": "楊光勳等結會樹黨",
        "relation": "同夥",
        "relation_type": "ally",
        "source": "蔡福",
        "target": "楊光勳"
      },
      {
        "evidence": "楊光勳等結會樹黨",
        "relation": "同夥",
        "relation_type": "ally",
        "source": "張員",
        "target": "楊光勳"
      }
    ],
    "side": "lin",
    "subtitle": "楊光勳等結會劫囚滋事",
    "whenAr": "1786/10/08",
    "whenCh": "乾隆五十一年閏七月十六日以前",
    "whenKnownCh": "乾隆五十一年閏七月",
    "where": "諸羅縣",
    "who": [
      "楊光勳",
      "張烈",
      "賴榮",
      "葉省",
      "蔡福",
      "張員"
    ],
    "who_loc": {
      "張員": "諸羅縣",
      "張烈": "諸羅縣",
      "楊光勳": "諸羅縣",
      "葉省": "諸羅縣",
      "蔡福": "諸羅縣",
      "賴榮": "諸羅縣"
    },
    "doc_id": "台8"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "諸羅縣奸民楊光勳等結會樹黨，劫囚滋事",
          "reporter": "柴大紀、永福",
          "subtitle": "楊光勳等結會劫囚滋事",
          "whenCh": "乾隆五十一年閏七月十六日以前",
          "where": "諸羅縣"
        }
      ],
      "hops": [
        {
          "from_person": "柴大紀、永福",
          "how": "奏聞",
          "inferred": false,
          "layer": 1,
          "place": "臺灣",
          "quote": "於本年閏七月十六日恭摺奏聞",
          "to_person": "乾隆帝",
          "whenAr": "",
          "whenCh": "乾隆五十一年閏七月十六日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "諸羅縣奸民楊光勳等結會樹黨，劫囚滋事",
            "reporter": "柴大紀、永福",
            "subtitle": "楊光勳等結會劫囚滋事",
            "whenCh": "乾隆五十一年閏七月十六日以前",
            "where": "諸羅縣"
          }
        ],
        "hops": [
          {
            "from_person": "柴大紀、永福",
            "how": "奏聞",
            "inferred": false,
            "layer": 1,
            "place": "臺灣",
            "quote": "於本年閏七月十六日恭摺奏聞",
            "to_person": "乾隆帝",
            "whenAr": "",
            "whenCh": "乾隆五十一年閏七月十六日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台12

```json
{
  "doc_id": "台12",
  "evTitle": "賊匪攻陷彰化縣城",
  "event": {
    "description": "臺灣彰化縣城遭到民變賊匪糾眾攻打並陷落。",
    "howKnown": "轉述",
    "quote": "臺灣彰化縣城被賊匪糾眾攻陷城池一案",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪攻陷彰化縣城",
    "whenAr": "",
    "whenCh": "",
    "whenKnownCh": "十二月初十日",
    "where": "臺灣彰化縣城",
    "who": [
      "賊匪"
    ],
    "who_loc": {
      "賊匪": "臺灣彰化縣城"
    },
    "doc_id": "台12"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "臺灣彰化縣城被賊匪糾眾攻陷城池一案",
          "reporter": "福建水師提督黃仕簡",
          "subtitle": "賊匪攻陷彰化縣城",
          "whenCh": "乾隆五十一年十二月初十日前",
          "where": "臺灣彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "福建水師提督黃仕簡",
          "how": "咨會",
          "inferred": false,
          "layer": 1,
          "place": "金門",
          "quote": "臣於乾隆五十一年十二月初十日准福建水師提督臣黃仕簡咨開",
          "to_person": "金門總兵羅英笈",
          "whenAr": "1787/01/28",
          "whenCh": "乾隆五十一年十二月初十日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "臺灣彰化縣城被賊匪糾眾攻陷城池一案",
            "reporter": "福建水師提督黃仕簡",
            "subtitle": "賊匪攻陷彰化縣城",
            "whenCh": "乾隆五十一年十二月初十日前",
            "where": "臺灣彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "福建水師提督黃仕簡",
            "how": "咨會",
            "inferred": false,
            "layer": 1,
            "place": "金門",
            "quote": "臣於乾隆五十一年十二月初十日准福建水師提督臣黃仕簡咨開",
            "to_person": "金門總兵羅英笈",
            "whenAr": "1787/01/28",
            "whenCh": "乾隆五十一年十二月初十日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台13

```json
{
  "doc_id": "台13",
  "evTitle": "匪徒攻陷彰化縣城",
  "event": {
    "description": "林爽文起事民變匪徒於路上截殺彰化知縣俞峻、北協副將赫生額、臺鎮中營遊擊耿世佳，隨後攻破並佔領彰化縣城。",
    "howKnown": "探報",
    "quote": "十一月二十七夜，彰化俞知縣同北協赫副將、臺鎮中營耿遊擊被匪徒攔路截殺，攻破彰化縣，踞住城池。",
    "relations": [
      {
        "evidence": "彰化俞知縣...被匪徒攔路截殺",
        "relation": "攔路截殺",
        "relation_type": "conflict",
        "source": "匪徒",
        "target": "俞知縣"
      },
      {
        "evidence": "北協赫副將...被匪徒攔路截殺",
        "relation": "攔路截殺",
        "relation_type": "conflict",
        "source": "匪徒",
        "target": "赫副將"
      },
      {
        "evidence": "臺鎮中營耿遊擊被匪徒攔路截殺",
        "relation": "攔路截殺",
        "relation_type": "conflict",
        "source": "匪徒",
        "target": "耿遊擊"
      }
    ],
    "side": "lin",
    "subtitle": "匪徒攻陷彰化縣城",
    "whenAr": "1787/01/15",
    "whenCh": "十一月二十七夜",
    "whenKnownCh": "十二月十四日",
    "where": "彰化縣",
    "who": [
      "匪徒",
      "俞知縣",
      "赫副將",
      "耿遊擊"
    ],
    "who_loc": {
      "俞知縣": "彰化縣",
      "匪徒": "彰化縣",
      "耿遊擊": "彰化縣",
      "赫副將": "彰化縣"
    },
    "doc_id": "台13"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "十一月二十七夜，彰化俞知縣同北協赫副將、臺鎮中營耿遊擊被匪徒攔路截殺，攻破彰化縣，踞住城池。",
          "reporter": "林登雲",
          "subtitle": "匪徒攻陷彰化縣城",
          "whenCh": "乾隆五十一年十一月二十七夜",
          "where": "彰化縣"
        }
      ],
      "hops": [
        {
          "from_person": "林登雲",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "接據臣差往探信之守備林登雲稟報，探得十一月二十七夜，彰化俞知縣同北協赫副將、臺鎮中營耿遊擊被匪徒攔路截殺，攻破彰化縣，踞住城池。",
          "to_person": "常青",
          "whenAr": "1787/02/01",
          "whenCh": "乾隆五十一年十二月十四日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "十一月二十七夜，彰化俞知縣同北協赫副將、臺鎮中營耿遊擊被匪徒攔路截殺，攻破彰化縣，踞住城池。",
            "reporter": "林登雲",
            "subtitle": "匪徒攻陷彰化縣城",
            "whenCh": "乾隆五十一年十一月二十七夜",
            "where": "彰化縣"
          }
        ],
        "hops": [
          {
            "from_person": "林登雲",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "接據臣差往探信之守備林登雲稟報，探得十一月二十七夜，彰化俞知縣同北協赫副將、臺鎮中營耿遊擊被匪徒攔路截殺，攻破彰化縣，踞住城池。",
            "to_person": "常青",
            "whenAr": "1787/02/01",
            "whenCh": "乾隆五十一年十二月十四日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台13

```json
{
  "doc_id": "台13",
  "evTitle": "賊匪中港擊散清軍",
  "event": {
    "description": "民變匪徒於中港地方，擊散前來堵禦的淡水同知程峻與守備董得魁所率領的兵役及鄉勇。",
    "howKnown": "探報",
    "quote": "程同知、董守備帶兵並鄉勇往中港堵禦，於本月初七日亦被賊殺散。",
    "relations": [
      {
        "evidence": "程同知...往中港堵禦，於本月初七日亦被賊殺散",
        "relation": "殺散",
        "relation_type": "conflict",
        "source": "賊匪",
        "target": "程峻"
      },
      {
        "evidence": "董守備帶兵並鄉勇往中港堵禦，於本月初七日亦被賊殺散",
        "relation": "殺散",
        "relation_type": "conflict",
        "source": "賊匪",
        "target": "董得魁"
      }
    ],
    "side": "lin",
    "subtitle": "賊匪中港擊散清軍",
    "whenAr": "1787/01/25",
    "whenCh": "十二月初七日",
    "whenKnownCh": "十二月十四日",
    "where": "中港",
    "who": [
      "賊匪",
      "程峻",
      "董得魁"
    ],
    "who_loc": {
      "程峻": "中港",
      "董得魁": "中港",
      "賊匪": "中港"
    },
    "doc_id": "台13"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "我父親會同董守備，帶領兵役、鄉勇赴中港地方堵禦，賊匪眾多，抵敵不住，我父親存亡不知；賊匪於十二月初七日已到竹塹",
          "reporter": "程必大",
          "subtitle": "賊匪中港擊散清軍",
          "whenCh": "乾隆五十一年十二月初七日",
          "where": "中港"
        }
      ],
      "hops": [
        {
          "from_person": "程必大",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "泉州府",
          "quote": "十二日有署淡水同知程峻之子程必大懷取淡防同知關防，赴泉求救",
          "to_person": "王右弼、徐夢麟",
          "whenAr": "1787/01/30",
          "whenCh": "乾隆五十一年十二月十二日"
        },
        {
          "from_person": "王右弼、徐夢麟",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "惠安途次",
          "quote": "臣於十二月十三日夜自塗嶺拜摺後，旋於惠安途次接據泉州府知府王右弼、晉江縣知縣徐夢麟稟稱",
          "to_person": "常青",
          "whenAr": "1787/01/31",
          "whenCh": "乾隆五十一年十二月十三日夜"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "隨同守備董得魁並程廳官帶兵到中港堵禦賊匪；本月初七日不料賊人漸多，兵少不敵",
          "reporter": "虞文光",
          "subtitle": "賊匪中港擊散清軍",
          "whenCh": "乾隆五十一年十二月初七日",
          "where": "中港"
        }
      ],
      "hops": [
        {
          "from_person": "虞文光",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "泉州府",
          "quote": "又有北路竹塹營外委虞文光、兵丁王元浩亦先後到泉。當即隨同六路提督傳詢。據程必大供稱...據外委虞文光供",
          "to_person": "王右弼、徐夢麟",
          "whenAr": "1787/01/30",
          "whenCh": "乾隆五十一年十二月十二日"
        },
        {
          "from_person": "王右弼、徐夢麟",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "惠安途次",
          "quote": "臣於十二月十三日夜自塗嶺拜摺後，旋於惠安途次接據泉州府知府王右弼、晉江縣知縣徐夢麟稟稱",
          "to_person": "常青",
          "whenAr": "1787/01/31",
          "whenCh": "乾隆五十一年十二月十三日夜"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "隨同守備董得魁並程廳官帶兵到中港堵禦賊匪；本月初七日不料賊人漸多，兵少不敵",
          "reporter": "虞文光",
          "subtitle": "賊匪中港擊散清軍",
          "whenCh": "乾隆五十一年十二月初七日",
          "where": "中港"
        }
      ],
      "hops": [
        {
          "from_person": "虞文光",
          "how": "口述",
          "inferred": false,
          "layer": 1,
          "place": "泉州郡城",
          "quote": "於十四日抵泉州郡城，親提虞文光等詢，與前供相同",
          "to_person": "常青",
          "whenAr": "1787/02/01",
          "whenCh": "乾隆五十一年十二月十四日"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "聞得竹塹程同知、董守備帶兵並鄉勇往中港堵禦，於本月初七日亦被賊殺散。",
          "reporter": "林登雲",
          "subtitle": "賊匪中港擊散清軍",
          "whenCh": "乾隆五十一年十二月初七日",
          "where": "中港"
        }
      ],
      "hops": [
        {
          "from_person": "林登雲",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "泉州府",
          "quote": "又，接據臣差往探信之守備林登雲稟報",
          "to_person": "常青",
          "whenAr": "1787/02/01",
          "whenCh": "乾隆五十一年十二月十四日前後"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "我父親會同董守備，帶領兵役、鄉勇赴中港地方堵禦，賊匪眾多，抵敵不住，我父親存亡不知；賊匪於十二月初七日已到竹塹",
            "reporter": "程必大",
            "subtitle": "賊匪中港擊散清軍",
            "whenCh": "乾隆五十一年十二月初七日",
            "where": "中港"
          }
        ],
        "hops": [
          {
            "from_person": "程必大",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "泉州府",
            "quote": "十二日有署淡水同知程峻之子程必大懷取淡防同知關防，赴泉求救",
            "to_person": "王右弼、徐夢麟",
            "whenAr": "1787/01/30",
            "whenCh": "乾隆五十一年十二月十二日"
          },
          {
            "from_person": "王右弼、徐夢麟",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "惠安途次",
            "quote": "臣於十二月十三日夜自塗嶺拜摺後，旋於惠安途次接據泉州府知府王右弼、晉江縣知縣徐夢麟稟稱",
            "to_person": "常青",
            "whenAr": "1787/01/31",
            "whenCh": "乾隆五十一年十二月十三日夜"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "隨同守備董得魁並程廳官帶兵到中港堵禦賊匪；本月初七日不料賊人漸多，兵少不敵",
            "reporter": "虞文光",
            "subtitle": "賊匪中港擊散清軍",
            "whenCh": "乾隆五十一年十二月初七日",
            "where": "中港"
          }
        ],
        "hops": [
          {
            "from_person": "虞文光",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "泉州府",
            "quote": "又有北路竹塹營外委虞文光、兵丁王元浩亦先後到泉。當即隨同六路提督傳詢。據程必大供稱...據外委虞文光供",
            "to_person": "王右弼、徐夢麟",
            "whenAr": "1787/01/30",
            "whenCh": "乾隆五十一年十二月十二日"
          },
          {
            "from_person": "王右弼、徐夢麟",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "惠安途次",
            "quote": "臣於十二月十三日夜自塗嶺拜摺後，旋於惠安途次接據泉州府知府王右弼、晉江縣知縣徐夢麟稟稱",
            "to_person": "常青",
            "whenAr": "1787/01/31",
            "whenCh": "乾隆五十一年十二月十三日夜"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "隨同守備董得魁並程廳官帶兵到中港堵禦賊匪；本月初七日不料賊人漸多，兵少不敵",
            "reporter": "虞文光",
            "subtitle": "賊匪中港擊散清軍",
            "whenCh": "乾隆五十一年十二月初七日",
            "where": "中港"
          }
        ],
        "hops": [
          {
            "from_person": "虞文光",
            "how": "口述",
            "inferred": false,
            "layer": 1,
            "place": "泉州郡城",
            "quote": "於十四日抵泉州郡城，親提虞文光等詢，與前供相同",
            "to_person": "常青",
            "whenAr": "1787/02/01",
            "whenCh": "乾隆五十一年十二月十四日"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "聞得竹塹程同知、董守備帶兵並鄉勇往中港堵禦，於本月初七日亦被賊殺散。",
            "reporter": "林登雲",
            "subtitle": "賊匪中港擊散清軍",
            "whenCh": "乾隆五十一年十二月初七日",
            "where": "中港"
          }
        ],
        "hops": [
          {
            "from_person": "林登雲",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "泉州府",
            "quote": "又，接據臣差往探信之守備林登雲稟報",
            "to_person": "常青",
            "whenAr": "1787/02/01",
            "whenCh": "乾隆五十一年十二月十四日前後"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台13

```json
{
  "doc_id": "台13",
  "evTitle": "賊匪攻佔竹塹四行搶擄",
  "event": {
    "description": "民變匪徒在擊敗中港清軍後，乘勢攻入竹塹（淡水廳治），在當地四處搶劫擄掠。",
    "howKnown": "轉述",
    "quote": "賊匪於十二月初七日已到竹塹，四行搶擄",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪攻佔竹塹四行搶擄",
    "whenAr": "1787/01/25",
    "whenCh": "十二月初七日",
    "whenKnownCh": "十二月十三日",
    "where": "竹塹",
    "who": [
      "賊匪"
    ],
    "who_loc": {
      "賊匪": "竹塹"
    },
    "doc_id": "台13"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "賊匪於十二月初七日已到竹塹，四行搶擄",
          "reporter": "程必大",
          "subtitle": "賊匪攻佔竹塹四行搶擄",
          "whenCh": "十二月初七日",
          "where": "竹塹"
        }
      ],
      "hops": [
        {
          "from_person": "程必大",
          "how": "口述",
          "inferred": false,
          "layer": 1,
          "place": "泉州郡城",
          "quote": "於十四日抵泉州郡城，親提虞文光等詢，與前供相同",
          "to_person": "常青",
          "whenAr": "1787/02/01",
          "whenCh": "十二月十四日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "賊匪於十二月初七日已到竹塹，四行搶擄",
            "reporter": "程必大",
            "subtitle": "賊匪攻佔竹塹四行搶擄",
            "whenCh": "十二月初七日",
            "where": "竹塹"
          }
        ],
        "hops": [
          {
            "from_person": "程必大",
            "how": "口述",
            "inferred": false,
            "layer": 1,
            "place": "泉州郡城",
            "quote": "於十四日抵泉州郡城，親提虞文光等詢，與前供相同",
            "to_person": "常青",
            "whenAr": "1787/02/01",
            "whenCh": "十二月十四日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台14

```json
{
  "doc_id": "台14",
  "evTitle": "匪徒攻劫大墩營盤",
  "event": {
    "description": "林爽文、王芬等聚集匪徒，於十一月二十七日夜間攻劫大墩營盤，擊傷清軍守兵。",
    "howKnown": "轉述",
    "quote": "十一月二十七夜賊匪眾多，攻劫營盤，小的帶傷逃回",
    "relations": [
      {
        "evidence": "林爽文、王芬等聚匪劫營... 攻劫營盤",
        "relation": "攻劫",
        "relation_type": "conflict",
        "source": "林爽文",
        "target": "耿世文"
      },
      {
        "evidence": "林爽文、王芬等聚匪劫營... 攻劫營盤",
        "relation": "攻劫",
        "relation_type": "conflict",
        "source": "王芬",
        "target": "耿世文"
      }
    ],
    "side": "lin",
    "subtitle": "匪徒攻劫大墩營盤",
    "whenAr": "1787/01/16",
    "whenCh": "十一月二十七日夜",
    "whenKnownCh": "十二月十六日",
    "where": "大墩",
    "who": [
      "林爽文",
      "王芬",
      "耿世文"
    ],
    "who_loc": {
      "林爽文": "大墩",
      "王芬": "大墩",
      "耿世文": "大墩"
    },
    "doc_id": "台14"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "十一月二十七夜賊匪眾多，攻劫營盤，小的帶傷逃回",
          "reporter": "楊勝官",
          "subtitle": "匪徒攻劫大墩營盤",
          "whenCh": "乾隆五十一年十一月二十七日夜",
          "where": "大墩"
        }
      ],
      "hops": [
        {
          "from_person": "常青",
          "how": "奏報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "閩浙總督臣常青跪奏，為續據臺灣鎮、道稟報，再行具奏事。...所有續據臺灣鎮道稟報情形，合再恭摺馳奏。",
          "to_person": "乾隆帝",
          "whenAr": "1787/02/04",
          "whenCh": "乾隆五十一年十二月十七日"
        },
        {
          "from_person": "臺灣鎮、道",
          "how": "會稟",
          "inferred": false,
          "layer": 2,
          "place": "臺灣",
          "quote": "茲於十六日復接到該鎮、道會稟：...職道等隨嚴飭本標遊擊李中揚、千總蘇明耀、魏大鵬等，飛馳諸羅剿捕。",
          "to_person": "常青",
          "whenAr": "1787/02/03",
          "whenCh": "乾隆五十一年十二月十六日（接報）"
        },
        {
          "from_person": "楊勝官",
          "how": "面稟",
          "inferred": false,
          "layer": 3,
          "place": "臺灣（途次）",
          "quote": "職道等於初三日途次，據跟隨遊擊耿世文往大墩緝賊之兵丁楊勝官面稟：十一月二十七夜賊匪眾多，攻劫營盤，小的帶傷逃回。",
          "to_person": "臺灣鎮、道",
          "whenAr": "1787/01/21",
          "whenCh": "乾隆五十一年十二月初三日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "十一月二十七夜賊匪眾多，攻劫營盤，小的帶傷逃回",
            "reporter": "楊勝官",
            "subtitle": "匪徒攻劫大墩營盤",
            "whenCh": "乾隆五十一年十一月二十七日夜",
            "where": "大墩"
          }
        ],
        "hops": [
          {
            "from_person": "常青",
            "how": "奏報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "閩浙總督臣常青跪奏，為續據臺灣鎮、道稟報，再行具奏事。...所有續據臺灣鎮道稟報情形，合再恭摺馳奏。",
            "to_person": "乾隆帝",
            "whenAr": "1787/02/04",
            "whenCh": "乾隆五十一年十二月十七日"
          },
          {
            "from_person": "臺灣鎮、道",
            "how": "會稟",
            "inferred": false,
            "layer": 2,
            "place": "臺灣",
            "quote": "茲於十六日復接到該鎮、道會稟：...職道等隨嚴飭本標遊擊李中揚、千總蘇明耀、魏大鵬等，飛馳諸羅剿捕。",
            "to_person": "常青",
            "whenAr": "1787/02/03",
            "whenCh": "乾隆五十一年十二月十六日（接報）"
          },
          {
            "from_person": "楊勝官",
            "how": "面稟",
            "inferred": false,
            "layer": 3,
            "place": "臺灣（途次）",
            "quote": "職道等於初三日途次，據跟隨遊擊耿世文往大墩緝賊之兵丁楊勝官面稟：十一月二十七夜賊匪眾多，攻劫營盤，小的帶傷逃回。",
            "to_person": "臺灣鎮、道",
            "whenAr": "1787/01/21",
            "whenCh": "乾隆五十一年十二月初三日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台14

```json
{
  "doc_id": "台14",
  "evTitle": "賊匪攻陷彰化縣城",
  "event": {
    "description": "賊匪數千人圍攻彰化縣城，於十一月二十八日夜間將城池攻破，殺害都司王宗武（王都司）。",
    "howKnown": "轉述",
    "quote": "有賊匪數千圍攻城池，於二十八夜將縣城攻破，王都司被害",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪攻陷彰化縣城",
    "whenAr": "1787/01/17",
    "whenCh": "十一月二十八日夜",
    "whenKnownCh": "十二月十六日",
    "where": "彰化縣城",
    "who": [
      "王都司"
    ],
    "who_loc": {
      "王都司": "彰化縣城"
    },
    "doc_id": "台14"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "有賊匪數千圍攻城池，於二十八夜將縣城攻破，王都司被害",
          "reporter": "兵丁賴得林",
          "subtitle": "賊匪攻陷彰化縣城",
          "whenCh": "乾隆五十一年十一月二十八日夜",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "臺灣鎮、道（柴大紀、永福）",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "茲於十六日復接到該鎮、道會稟",
          "to_person": "常青",
          "whenAr": "1787/02/03",
          "whenCh": "乾隆五十一年十二月十六日"
        },
        {
          "from_person": "諸羅守備郝輝龍、署諸羅縣俸滿同知董啟埏",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "臺灣",
          "quote": "職道等於初三日途次...復據諸羅守備郝輝龍、署諸羅縣俸滿同知董啟埏稟稱",
          "to_person": "臺灣鎮、道（柴大紀、永福）",
          "whenAr": "1787/01/21",
          "whenCh": "乾隆五十一年十二月初三日"
        },
        {
          "from_person": "兵丁賴得林",
          "how": "稟報",
          "inferred": false,
          "layer": 3,
          "place": "諸羅",
          "quote": "初二日酉刻，據差往彰化投文兵丁賴得林逃回稟稱",
          "to_person": "諸羅守備郝輝龍、署諸羅縣俸滿同知董啟埏",
          "whenAr": "1787/01/20",
          "whenCh": "乾隆五十一年十二月初二日酉刻"
        },
        {
          "from_person": "兵丁賴得林",
          "how": "親見",
          "inferred": false,
          "layer": 4,
          "place": "彰化縣城",
          "quote": "小的蒙差赴彰投文，在彰城中住宿，有賊匪數千圍攻城池，於二十八夜將縣城攻破，王都司被害",
          "to_person": "兵丁賴得林",
          "whenAr": "1787/01/16",
          "whenCh": "乾隆五十一年十一月二十八日夜"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "十一月二十九日，賊匪攻陷彰化",
          "reporter": "臺灣縣典史易鳳翔",
          "subtitle": "賊匪攻陷彰化縣城",
          "whenCh": "乾隆五十一年十一月二十九日",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "興泉永道萬鍾傑",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "旋又接據興泉永道萬鍾傑稟稱",
          "to_person": "常青",
          "whenAr": "1787/02/02",
          "whenCh": "乾隆五十一年十二月十五日"
        },
        {
          "from_person": "臺灣縣典史易鳳翔",
          "how": "口述",
          "inferred": false,
          "layer": 2,
          "place": "廈門",
          "quote": "有臺灣縣典史易鳳翔執持臺灣道印照同永道家人曹泰、諸榮來廈，當即傳詢。據易典史稱",
          "to_person": "興泉永道萬鍾傑",
          "whenAr": "1787/02/02",
          "whenCh": "乾隆五十一年十二月十五日亥刻"
        },
        {
          "from_person": "臺灣縣典史易鳳翔",
          "how": "訪聞",
          "inferred": true,
          "layer": 3,
          "place": "臺灣府城",
          "quote": "十一月二十九日，賊匪攻陷彰化",
          "to_person": "臺灣縣典史易鳳翔",
          "whenAr": "1787/01/17",
          "whenCh": "乾隆五十一年十一月二十九日"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "二十八日賊匪數千攻破縣城",
          "reporter": "鹿港民人",
          "subtitle": "賊匪攻陷彰化縣城",
          "whenCh": "乾隆五十一年十一月二十八日",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "臺灣鎮、道（柴大紀、永福）",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "茲於十六日復接到該鎮、道會稟",
          "to_person": "常青",
          "whenAr": "1787/02/03",
          "whenCh": "乾隆五十一年十二月十六日"
        },
        {
          "from_person": "署鹿仔港守備事千總陳邦光",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "臺灣",
          "quote": "又，據署鹿仔港守備事千總陳邦光稟稱",
          "to_person": "臺灣鎮、道（柴大紀、永福）",
          "whenAr": "1787/01/21",
          "whenCh": "乾隆五十一年十二月初三日"
        },
        {
          "from_person": "鹿港民人",
          "how": "口述",
          "inferred": false,
          "layer": 3,
          "place": "鹿港",
          "quote": "本月二十八日有鹿港民人自彰逃回，俱說",
          "to_person": "署鹿仔港守備事千總陳邦光",
          "whenAr": "1787/01/16",
          "whenCh": "乾隆五十一年十一月二十八日"
        },
        {
          "from_person": "鹿港民人",
          "how": "親見",
          "inferred": false,
          "layer": 4,
          "place": "彰化",
          "quote": "二十八日賊匪數千攻破縣城",
          "to_person": "鹿港民人",
          "whenAr": "1787/01/16",
          "whenCh": "乾隆五十一年十一月二十八日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "有賊匪數千圍攻城池，於二十八夜將縣城攻破，王都司被害",
            "reporter": "兵丁賴得林",
            "subtitle": "賊匪攻陷彰化縣城",
            "whenCh": "乾隆五十一年十一月二十八日夜",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "臺灣鎮、道（柴大紀、永福）",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "茲於十六日復接到該鎮、道會稟",
            "to_person": "常青",
            "whenAr": "1787/02/03",
            "whenCh": "乾隆五十一年十二月十六日"
          },
          {
            "from_person": "諸羅守備郝輝龍、署諸羅縣俸滿同知董啟埏",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "臺灣",
            "quote": "職道等於初三日途次...復據諸羅守備郝輝龍、署諸羅縣俸滿同知董啟埏稟稱",
            "to_person": "臺灣鎮、道（柴大紀、永福）",
            "whenAr": "1787/01/21",
            "whenCh": "乾隆五十一年十二月初三日"
          },
          {
            "from_person": "兵丁賴得林",
            "how": "稟報",
            "inferred": false,
            "layer": 3,
            "place": "諸羅",
            "quote": "初二日酉刻，據差往彰化投文兵丁賴得林逃回稟稱",
            "to_person": "諸羅守備郝輝龍、署諸羅縣俸滿同知董啟埏",
            "whenAr": "1787/01/20",
            "whenCh": "乾隆五十一年十二月初二日酉刻"
          },
          {
            "from_person": "兵丁賴得林",
            "how": "親見",
            "inferred": false,
            "layer": 4,
            "place": "彰化縣城",
            "quote": "小的蒙差赴彰投文，在彰城中住宿，有賊匪數千圍攻城池，於二十八夜將縣城攻破，王都司被害",
            "to_person": "兵丁賴得林",
            "whenAr": "1787/01/16",
            "whenCh": "乾隆五十一年十一月二十八日夜"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "十一月二十九日，賊匪攻陷彰化",
            "reporter": "臺灣縣典史易鳳翔",
            "subtitle": "賊匪攻陷彰化縣城",
            "whenCh": "乾隆五十一年十一月二十九日",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "興泉永道萬鍾傑",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "旋又接據興泉永道萬鍾傑稟稱",
            "to_person": "常青",
            "whenAr": "1787/02/02",
            "whenCh": "乾隆五十一年十二月十五日"
          },
          {
            "from_person": "臺灣縣典史易鳳翔",
            "how": "口述",
            "inferred": false,
            "layer": 2,
            "place": "廈門",
            "quote": "有臺灣縣典史易鳳翔執持臺灣道印照同永道家人曹泰、諸榮來廈，當即傳詢。據易典史稱",
            "to_person": "興泉永道萬鍾傑",
            "whenAr": "1787/02/02",
            "whenCh": "乾隆五十一年十二月十五日亥刻"
          },
          {
            "from_person": "臺灣縣典史易鳳翔",
            "how": "訪聞",
            "inferred": true,
            "layer": 3,
            "place": "臺灣府城",
            "quote": "十一月二十九日，賊匪攻陷彰化",
            "to_person": "臺灣縣典史易鳳翔",
            "whenAr": "1787/01/17",
            "whenCh": "乾隆五十一年十一月二十九日"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "二十八日賊匪數千攻破縣城",
            "reporter": "鹿港民人",
            "subtitle": "賊匪攻陷彰化縣城",
            "whenCh": "乾隆五十一年十一月二十八日",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "臺灣鎮、道（柴大紀、永福）",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "茲於十六日復接到該鎮、道會稟",
            "to_person": "常青",
            "whenAr": "1787/02/03",
            "whenCh": "乾隆五十一年十二月十六日"
          },
          {
            "from_person": "署鹿仔港守備事千總陳邦光",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "臺灣",
            "quote": "又，據署鹿仔港守備事千總陳邦光稟稱",
            "to_person": "臺灣鎮、道（柴大紀、永福）",
            "whenAr": "1787/01/21",
            "whenCh": "乾隆五十一年十二月初三日"
          },
          {
            "from_person": "鹿港民人",
            "how": "口述",
            "inferred": false,
            "layer": 3,
            "place": "鹿港",
            "quote": "本月二十八日有鹿港民人自彰逃回，俱說",
            "to_person": "署鹿仔港守備事千總陳邦光",
            "whenAr": "1787/01/16",
            "whenCh": "乾隆五十一年十一月二十八日"
          },
          {
            "from_person": "鹿港民人",
            "how": "親見",
            "inferred": false,
            "layer": 4,
            "place": "彰化",
            "quote": "二十八日賊匪數千攻破縣城",
            "to_person": "鹿港民人",
            "whenAr": "1787/01/16",
            "whenCh": "乾隆五十一年十一月二十八日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台14

```json
{
  "doc_id": "台14",
  "evTitle": "賊匪攻破諸羅縣城",
  "event": {
    "description": "賊匪於十二月初六日卯時攻破諸羅縣城。",
    "howKnown": "轉述",
    "quote": "十二月初六日卯時，攻破諸羅",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪攻破諸羅縣城",
    "whenAr": "1787/01/24",
    "whenCh": "十二月初六日卯時",
    "whenKnownCh": "十二月十七日",
    "where": "諸羅縣城",
    "who": [],
    "who_loc": {},
    "doc_id": "台14"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "十二月初六日卯時，攻破諸羅",
          "reporter": "易鳳翔",
          "subtitle": "賊匪攻破諸羅縣城",
          "whenCh": "十二月初六日卯時",
          "where": "諸羅縣城"
        }
      ],
      "hops": [
        {
          "from_person": "萬鍾傑",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "旋又接據興泉永道萬鍾傑稟稱",
          "to_person": "常青",
          "whenAr": "1787/02/02",
          "whenCh": "十二月十五日亥刻之後"
        },
        {
          "from_person": "易鳳翔",
          "how": "口述",
          "inferred": false,
          "layer": 2,
          "place": "廈門",
          "quote": "有臺灣縣典史易鳳翔執持臺灣道印照同永道家人曹泰、諸榮來廈，當即傳詢。據易典史稱",
          "to_person": "萬鍾傑",
          "whenAr": "1787/02/02",
          "whenCh": "十二月十五日亥刻"
        },
        {
          "from_person": "臺灣道",
          "how": "口述",
          "inferred": true,
          "layer": 3,
          "place": "臺灣府城",
          "quote": "初七夜，臺道因事勢急迫，令該典史同家人二名來廈請救",
          "to_person": "易鳳翔",
          "whenAr": "1787/01/25",
          "whenCh": "十二月初七日夜"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "十二月初六日卯時，攻破諸羅",
          "reporter": "易鳳翔",
          "subtitle": "賊匪攻破諸羅縣城",
          "whenCh": "十二月初六日卯時",
          "where": "諸羅縣城"
        }
      ],
      "hops": [
        {
          "from_person": "易鳳翔",
          "how": "口述",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "並令該典史齋文來泉，臣即傳喚面詢，據稟情形悉屬相符。",
          "to_person": "常青",
          "whenAr": "",
          "whenCh": "十二月十五日至十七日之間"
        },
        {
          "from_person": "臺灣道",
          "how": "口述",
          "inferred": true,
          "layer": 2,
          "place": "臺灣府城",
          "quote": "初七夜，臺道因事勢急迫，令該典史同家人二名來廈請救",
          "to_person": "易鳳翔",
          "whenAr": "1787/01/25",
          "whenCh": "十二月初七日夜"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "十二月初六日卯時，攻破諸羅",
            "reporter": "易鳳翔",
            "subtitle": "賊匪攻破諸羅縣城",
            "whenCh": "十二月初六日卯時",
            "where": "諸羅縣城"
          }
        ],
        "hops": [
          {
            "from_person": "萬鍾傑",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "旋又接據興泉永道萬鍾傑稟稱",
            "to_person": "常青",
            "whenAr": "1787/02/02",
            "whenCh": "十二月十五日亥刻之後"
          },
          {
            "from_person": "易鳳翔",
            "how": "口述",
            "inferred": false,
            "layer": 2,
            "place": "廈門",
            "quote": "有臺灣縣典史易鳳翔執持臺灣道印照同永道家人曹泰、諸榮來廈，當即傳詢。據易典史稱",
            "to_person": "萬鍾傑",
            "whenAr": "1787/02/02",
            "whenCh": "十二月十五日亥刻"
          },
          {
            "from_person": "臺灣道",
            "how": "口述",
            "inferred": true,
            "layer": 3,
            "place": "臺灣府城",
            "quote": "初七夜，臺道因事勢急迫，令該典史同家人二名來廈請救",
            "to_person": "易鳳翔",
            "whenAr": "1787/01/25",
            "whenCh": "十二月初七日夜"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "十二月初六日卯時，攻破諸羅",
            "reporter": "易鳳翔",
            "subtitle": "賊匪攻破諸羅縣城",
            "whenCh": "十二月初六日卯時",
            "where": "諸羅縣城"
          }
        ],
        "hops": [
          {
            "from_person": "易鳳翔",
            "how": "口述",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "並令該典史齋文來泉，臣即傳喚面詢，據稟情形悉屬相符。",
            "to_person": "常青",
            "whenAr": "",
            "whenCh": "十二月十五日至十七日之間"
          },
          {
            "from_person": "臺灣道",
            "how": "口述",
            "inferred": true,
            "layer": 2,
            "place": "臺灣府城",
            "quote": "初七夜，臺道因事勢急迫，令該典史同家人二名來廈請救",
            "to_person": "易鳳翔",
            "whenAr": "1787/01/25",
            "whenCh": "十二月初七日夜"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台14

```json
{
  "doc_id": "台14",
  "evTitle": "賊匪與柴大紀部交戰",
  "event": {
    "description": "賊匪與清軍臺灣鎮總兵柴大紀在三坎店一帶交戰，遭到清軍火砲轟擊後稍退。",
    "howKnown": "轉述",
    "quote": "十一日柴鎮與賊打仗，大施火砲，賊勢稍退",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪與柴大紀部交戰",
    "whenAr": "1787/01/29",
    "whenCh": "十二月十一日",
    "whenKnownCh": "十二月十七日",
    "where": "三坎店",
    "who": [
      "柴大紀"
    ],
    "who_loc": {
      "柴大紀": "三坎店"
    },
    "doc_id": "台14"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "十一日柴鎮與賊打仗，大施火砲，賊勢稍退",
          "reporter": "臺灣縣典史易鳳翔",
          "subtitle": "賊匪與柴大紀部交戰",
          "whenCh": "十二月十一日",
          "where": "三坎店"
        }
      ],
      "hops": [
        {
          "from_person": "興泉永道萬鍾傑",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "旋又接據興泉永道萬鍾傑稟稱",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/02/02",
          "whenCh": "十二月十五日亥刻之後"
        },
        {
          "from_person": "臺灣縣典史易鳳翔",
          "how": "口述",
          "inferred": false,
          "layer": 2,
          "place": "廈門",
          "quote": "十二月十五亥刻，有臺灣縣典史易鳳翔執持臺灣道印照同永道家人曹泰、諸榮來廈，當即傳詢。據易典史稱",
          "to_person": "興泉永道萬鍾傑",
          "whenAr": "1787/02/02",
          "whenCh": "十二月十五日亥刻"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "十一日柴鎮與賊打仗，大施火砲，賊勢稍退",
            "reporter": "臺灣縣典史易鳳翔",
            "subtitle": "賊匪與柴大紀部交戰",
            "whenCh": "十二月十一日",
            "where": "三坎店"
          }
        ],
        "hops": [
          {
            "from_person": "興泉永道萬鍾傑",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "旋又接據興泉永道萬鍾傑稟稱",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/02/02",
            "whenCh": "十二月十五日亥刻之後"
          },
          {
            "from_person": "臺灣縣典史易鳳翔",
            "how": "口述",
            "inferred": false,
            "layer": 2,
            "place": "廈門",
            "quote": "十二月十五亥刻，有臺灣縣典史易鳳翔執持臺灣道印照同永道家人曹泰、諸榮來廈，當即傳詢。據易典史稱",
            "to_person": "興泉永道萬鍾傑",
            "whenAr": "1787/02/02",
            "whenCh": "十二月十五日亥刻"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台15

```json
{
  "doc_id": "台15",
  "evTitle": "匪徒攻陷諸羅縣城",
  "event": {
    "description": "林爽文起事民變部眾攻陷諸羅縣，並殺害前往督緝的臺灣府知府孫景燧。",
    "howKnown": "轉述",
    "quote": "知府孫景燧自十一月初間，前赴諸羅督緝匪犯，今諸羅失陷，聞得已經被害。",
    "relations": [
      {
        "evidence": "今諸羅失陷，聞得已經被害",
        "relation": "殺害",
        "relation_type": "conflict",
        "source": "匪犯",
        "target": "孫景燧"
      }
    ],
    "side": "lin",
    "subtitle": "匪徒攻陷諸羅縣城",
    "whenAr": "1786/12",
    "whenCh": "十一月",
    "whenKnownCh": "",
    "where": "諸羅",
    "who": [
      "孫景燧",
      "匪犯"
    ],
    "who_loc": {
      "匪犯": "諸羅",
      "孫景燧": "諸羅"
    },
    "doc_id": "台15"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "知府孫景燧自十一月初間，前赴諸羅督緝匪犯，今諸羅失陷，聞得已經被害。",
          "reporter": "臺灣道",
          "subtitle": "匪徒攻陷諸羅縣城",
          "whenCh": "十一月",
          "where": "諸羅"
        }
      ],
      "hops": [
        {
          "from_person": "臺灣道",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "據臺灣道另稟，知府孫景燧自十一月初間，前赴諸羅督緝匪犯，今諸羅失陷，聞得已經被害。等語。",
          "to_person": "常青",
          "whenAr": "",
          "whenCh": "十一月"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "知府孫景燧自十一月初間，前赴諸羅督緝匪犯，今諸羅失陷，聞得已經被害。",
            "reporter": "臺灣道",
            "subtitle": "匪徒攻陷諸羅縣城",
            "whenCh": "十一月",
            "where": "諸羅"
          }
        ],
        "hops": [
          {
            "from_person": "臺灣道",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "據臺灣道另稟，知府孫景燧自十一月初間，前赴諸羅督緝匪犯，今諸羅失陷，聞得已經被害。等語。",
            "to_person": "常青",
            "whenAr": "",
            "whenCh": "十一月"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台16

```json
{
  "doc_id": "台16",
  "evTitle": "林爽文等攻佔彰化城",
  "event": {
    "description": "彰化林爽文等人起事謀反，攻打並佔領彰化城池，隨後勢力開始向外蔓延。",
    "howKnown": "轉述",
    "quote": "彰化賊人林爽文等謀為不軌，攻佔城池，先經臣派撥三路官兵赴剿，嗣聞賊勢蔓延",
    "relations": [],
    "side": "lin",
    "subtitle": "林爽文等攻佔彰化城",
    "whenAr": "",
    "whenCh": "",
    "whenKnownCh": "",
    "where": "彰化",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "彰化"
    },
    "doc_id": "台16"
  },
  "chains": [],
  "_raw": {
    "chains": [],
    "mode": "trace"
  }
}
```

## 台16

```json
{
  "doc_id": "台16",
  "evTitle": "叛軍佔領竹塹",
  "event": {
    "description": "叛軍北上蔓延，攻陷並佔領竹塹地方。",
    "howKnown": "轉述",
    "quote": "竹塹地方亦被賊人佔踞",
    "relations": [],
    "side": "lin",
    "subtitle": "叛軍佔領竹塹",
    "whenAr": "",
    "whenCh": "十二月十三日以前",
    "whenKnownCh": "十二月十三日",
    "where": "竹塹",
    "who": [
      "林爽文部眾"
    ],
    "who_loc": {
      "林爽文部眾": "竹塹"
    },
    "doc_id": "台16"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "竹塹地方亦被賊人佔踞",
          "reporter": "程必大",
          "subtitle": "叛軍佔領竹塹",
          "whenCh": "十二月十三日以前",
          "where": "竹塹"
        }
      ],
      "hops": [
        {
          "from_person": "程必大",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "臣於十三日據淡水同知程峻之子程必大稟報，竹塹地方亦被賊人佔踞",
          "to_person": "常青",
          "whenAr": "1787/01/31",
          "whenCh": "十二月十三日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "竹塹地方亦被賊人佔踞",
            "reporter": "程必大",
            "subtitle": "叛軍佔領竹塹",
            "whenCh": "十二月十三日以前",
            "where": "竹塹"
          }
        ],
        "hops": [
          {
            "from_person": "程必大",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "臣於十三日據淡水同知程峻之子程必大稟報，竹塹地方亦被賊人佔踞",
            "to_person": "常青",
            "whenAr": "1787/01/31",
            "whenCh": "十二月十三日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台16

```json
{
  "doc_id": "台16",
  "evTitle": "郡城外圍賊勢稍退",
  "event": {
    "description": "叛軍進逼臺灣郡城，後因澎湖與安平的清軍援兵相繼抵達，叛軍攻勢受挫並稍微退卻。",
    "howKnown": "探報",
    "quote": "探得澎湖陳副將，差蔡遊擊領兵於十四日到郡，安平林遊擊亦帶兵赴援，現在賊勢稍退。",
    "relations": [],
    "side": "lin",
    "subtitle": "郡城外圍賊勢稍退",
    "whenAr": "",
    "whenCh": "十二月十四日至十八日之間",
    "whenKnownCh": "十二月十八日",
    "where": "臺灣郡城",
    "who": [
      "林爽文部眾"
    ],
    "who_loc": {
      "林爽文部眾": "臺灣郡城"
    },
    "doc_id": "台16"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "澎湖陳副將，差蔡遊擊領兵於十四日到郡，安平林遊擊亦帶兵赴援，現在賊勢稍退。",
          "reporter": "林登雲差往探聽之人",
          "subtitle": "郡城外圍賊勢稍退",
          "whenCh": "乾隆五十一年十二月十四日至十八日之間",
          "where": "臺灣郡城"
        }
      ],
      "hops": [
        {
          "from_person": "守備林登雲",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "惟據差往探聽之守備林登雲稟稱：探得澎湖陳副將，差蔡遊擊領兵於十四日到郡，安平林遊擊亦帶兵赴援，現在賊勢稍退。",
          "to_person": "閩浙總督常青",
          "whenAr": "",
          "whenCh": "乾隆五十一年十二月十八日至二十日之間"
        },
        {
          "from_person": "林登雲差往探聽之人",
          "how": "探報",
          "inferred": true,
          "layer": 2,
          "place": "臺灣郡城",
          "quote": "差往探聽之守備林登雲稟稱：探得",
          "to_person": "守備林登雲",
          "whenAr": "",
          "whenCh": "乾隆五十一年十二月十四日至十八日之間"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "澎湖陳副將，差蔡遊擊領兵於十四日到郡，安平林遊擊亦帶兵赴援，現在賊勢稍退。",
            "reporter": "林登雲差往探聽之人",
            "subtitle": "郡城外圍賊勢稍退",
            "whenCh": "乾隆五十一年十二月十四日至十八日之間",
            "where": "臺灣郡城"
          }
        ],
        "hops": [
          {
            "from_person": "守備林登雲",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "惟據差往探聽之守備林登雲稟稱：探得澎湖陳副將，差蔡遊擊領兵於十四日到郡，安平林遊擊亦帶兵赴援，現在賊勢稍退。",
            "to_person": "閩浙總督常青",
            "whenAr": "",
            "whenCh": "乾隆五十一年十二月十八日至二十日之間"
          },
          {
            "from_person": "林登雲差往探聽之人",
            "how": "探報",
            "inferred": true,
            "layer": 2,
            "place": "臺灣郡城",
            "quote": "差往探聽之守備林登雲稟稱：探得",
            "to_person": "守備林登雲",
            "whenAr": "",
            "whenCh": "乾隆五十一年十二月十四日至十八日之間"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台17

```json
{
  "doc_id": "台17",
  "evTitle": "林爽文等在臺灣起事",
  "event": {
    "description": "臺灣逆匪林爽文等人聚集滋事，反抗清廷，消息傳至福建，引起地方官員戒備。",
    "howKnown": "轉述",
    "quote": "惟時適聞臺灣賊匪滋事……且臺灣逆匪林爽文等又係漳人尤不可不嚴加防範。",
    "relations": [],
    "side": "lin",
    "subtitle": "林爽文等在臺灣起事",
    "whenAr": "1786/12",
    "whenCh": "乾隆五十一年十二月以前",
    "whenKnownCh": "乾隆五十一年十二月十一日以前",
    "where": "臺灣",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "臺灣"
    },
    "doc_id": "台17"
  },
  "chains": [],
  "_raw": {
    "chains": [],
    "mode": "trace"
  }
}
```

## 台17

```json
{
  "doc_id": "台17",
  "evTitle": "陳薦等糾集夥黨行劫",
  "event": {
    "description": "漳、泉匪徒陳薦、林川等人糾集夥黨，藏匿山中，置備器械，屢次行劫傷人，林川並於殺死地保後加入該夥。",
    "howKnown": "審訊得實",
    "quote": "匪徒陳薦等竟敢糾集夥黨，藏匿山中，且有藔洞、器械，屢次行劫傷人……據供起意糾夥、節次搶劫，各確情歷歷不諱。因該犯陳薦為首聚匪、林川於殺死地保後入夥行劫",
    "relations": [
      {
        "evidence": "林川於殺死地保後入夥行劫",
        "relation": "入夥",
        "relation_type": "ally",
        "source": "林川",
        "target": "陳薦"
      },
      {
        "evidence": "盜夥林妙等",
        "relation": "盜夥",
        "relation_type": "ally",
        "source": "林妙",
        "target": "陳薦"
      }
    ],
    "side": "lin",
    "subtitle": "陳薦等糾集夥黨行劫",
    "whenAr": "1786/12",
    "whenCh": "乾隆五十一年十二月以前",
    "whenKnownCh": "乾隆五十一年十二月",
    "where": "漳州、泉州一帶山中",
    "who": [
      "陳薦",
      "林川",
      "林妙"
    ],
    "who_loc": {
      "林妙": "漳州、泉州一帶山中",
      "林川": "漳州、泉州一帶山中",
      "陳薦": "漳州、泉州一帶山中"
    },
    "doc_id": "台17"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "因該犯陳薦為首聚匪、林川於殺死地保後入夥行劫",
          "reporter": "陳薦、林川",
          "subtitle": "陳薦等糾集夥黨行劫",
          "whenCh": "乾隆五十一年十二月以前",
          "where": "漳州、泉州一帶山中"
        }
      ],
      "hops": [
        {
          "from_person": "常青",
          "how": "奏摺",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "所有欽奉諭旨緣由，理合恭摺覆奏，伏祈皇上睿鑒。謹奏。",
          "to_person": "乾隆帝",
          "whenAr": "1787/02/09",
          "whenCh": "乾隆五十一年十二月二十二日"
        },
        {
          "from_person": "陳薦、林川",
          "how": "口供",
          "inferred": false,
          "layer": 2,
          "place": "福建省城",
          "quote": "會同撫臣悉心嚴審，據供起意糾夥、節次搶劫，各確情歷歷不諱。因該犯陳薦為首聚匪、林川於殺死地保後入夥行劫",
          "to_person": "常青、徐嗣曾",
          "whenAr": "",
          "whenCh": "乾隆五十一年十二月十一日以前"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "因該犯陳薦為首聚匪、林川於殺死地保後入夥行劫",
            "reporter": "陳薦、林川",
            "subtitle": "陳薦等糾集夥黨行劫",
            "whenCh": "乾隆五十一年十二月以前",
            "where": "漳州、泉州一帶山中"
          }
        ],
        "hops": [
          {
            "from_person": "常青",
            "how": "奏摺",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "所有欽奉諭旨緣由，理合恭摺覆奏，伏祈皇上睿鑒。謹奏。",
            "to_person": "乾隆帝",
            "whenAr": "1787/02/09",
            "whenCh": "乾隆五十一年十二月二十二日"
          },
          {
            "from_person": "陳薦、林川",
            "how": "口供",
            "inferred": false,
            "layer": 2,
            "place": "福建省城",
            "quote": "會同撫臣悉心嚴審，據供起意糾夥、節次搶劫，各確情歷歷不諱。因該犯陳薦為首聚匪、林川於殺死地保後入夥行劫",
            "to_person": "常青、徐嗣曾",
            "whenAr": "",
            "whenCh": "乾隆五十一年十二月十一日以前"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台18

```json
{
  "doc_id": "台18",
  "evTitle": "彰化起事民變蔓延四擾",
  "event": {
    "description": "彰化林爽文等人起事後，其部眾在臺灣各地蔓延並四處滋擾，造成地方動盪。",
    "howKnown": "轉述",
    "quote": "彰化逆匪林爽文等蔓延四擾",
    "relations": [],
    "side": "lin",
    "subtitle": "彰化起事民變蔓延四擾",
    "whenAr": "",
    "whenCh": "乾隆五十一年十一月至十二月",
    "whenKnownCh": "",
    "where": "臺灣",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "臺灣"
    },
    "doc_id": "台18"
  },
  "chains": [],
  "_raw": {
    "chains": [],
    "mode": "trace"
  }
}
```

## 台18

```json
{
  "doc_id": "台18",
  "evTitle": "叛軍攻佔並據守竹塹",
  "event": {
    "description": "林爽文起事部眾向北擴張，成功攻佔並據守竹塹地區。",
    "howKnown": "探報",
    "quote": "臣因聞竹塹已被賊踞",
    "relations": [],
    "side": "lin",
    "subtitle": "叛軍攻佔並據守竹塹",
    "whenAr": "",
    "whenCh": "乾隆五十一年十二月",
    "whenKnownCh": "",
    "where": "竹塹",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "竹塹"
    },
    "doc_id": "台18"
  },
  "chains": [],
  "_raw": {
    "chains": [],
    "mode": "trace"
  }
}
```

## 台19

```json
{
  "doc_id": "台19",
  "evTitle": "賊匪糾眾攻打彰化縣城",
  "event": {
    "description": "臺灣彰化縣之民變賊匪糾集部眾，攻打彰化縣城，引發大亂。",
    "howKnown": "轉述",
    "quote": "臺灣彰化縣被賊匪糾眾攻城",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪糾眾攻打彰化縣城",
    "whenAr": "",
    "whenCh": "",
    "whenKnownCh": "",
    "where": "臺灣彰化縣",
    "who": [
      "賊匪"
    ],
    "who_loc": {
      "賊匪": "臺灣彰化縣"
    },
    "doc_id": "台19"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "臺灣彰化縣被賊匪糾眾攻城",
          "reporter": "黃仕簡",
          "subtitle": "賊匪糾眾攻打彰化縣城",
          "whenCh": "乾隆五十一年",
          "where": "臺灣彰化縣"
        }
      ],
      "hops": [
        {
          "from_person": "孫士毅",
          "how": "奏",
          "inferred": false,
          "layer": 1,
          "place": "廣東",
          "quote": "兩廣總督兼署廣東巡撫臣孫士毅跪奏，為奏聞事。",
          "to_person": "乾隆帝",
          "whenAr": "1787/02/11",
          "whenCh": "乾隆五十一年十二月二十四日"
        },
        {
          "from_person": "彭承堯",
          "how": "咨會",
          "inferred": false,
          "layer": 2,
          "place": "廣東",
          "quote": "臣現接署提臣彭承堯咨會",
          "to_person": "孫士毅",
          "whenAr": "",
          "whenCh": "乾隆五十一年十二月"
        },
        {
          "from_person": "六廷柱",
          "how": "轉據",
          "inferred": false,
          "layer": 3,
          "place": "南澳",
          "quote": "淮南澳鎮臣六廷柱轉據",
          "to_person": "彭承堯",
          "whenAr": "",
          "whenCh": "乾隆五十一年十二月"
        },
        {
          "from_person": "黃仕簡",
          "how": "移咨",
          "inferred": false,
          "layer": 4,
          "place": "福建",
          "quote": "福建水師提臣黃仕簡咨開",
          "to_person": "六廷柱",
          "whenAr": "",
          "whenCh": "乾隆五十一年十二月"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "臺灣彰化縣被賊匪糾眾攻城",
            "reporter": "黃仕簡",
            "subtitle": "賊匪糾眾攻打彰化縣城",
            "whenCh": "乾隆五十一年",
            "where": "臺灣彰化縣"
          }
        ],
        "hops": [
          {
            "from_person": "孫士毅",
            "how": "奏",
            "inferred": false,
            "layer": 1,
            "place": "廣東",
            "quote": "兩廣總督兼署廣東巡撫臣孫士毅跪奏，為奏聞事。",
            "to_person": "乾隆帝",
            "whenAr": "1787/02/11",
            "whenCh": "乾隆五十一年十二月二十四日"
          },
          {
            "from_person": "彭承堯",
            "how": "咨會",
            "inferred": false,
            "layer": 2,
            "place": "廣東",
            "quote": "臣現接署提臣彭承堯咨會",
            "to_person": "孫士毅",
            "whenAr": "",
            "whenCh": "乾隆五十一年十二月"
          },
          {
            "from_person": "六廷柱",
            "how": "轉據",
            "inferred": false,
            "layer": 3,
            "place": "南澳",
            "quote": "淮南澳鎮臣六廷柱轉據",
            "to_person": "彭承堯",
            "whenAr": "",
            "whenCh": "乾隆五十一年十二月"
          },
          {
            "from_person": "黃仕簡",
            "how": "移咨",
            "inferred": false,
            "layer": 4,
            "place": "福建",
            "quote": "福建水師提臣黃仕簡咨開",
            "to_person": "六廷柱",
            "whenAr": "",
            "whenCh": "乾隆五十一年十二月"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台20

```json
{
  "doc_id": "台20",
  "evTitle": "賊兵攻佔彰化竹塹",
  "event": {
    "description": "彰化天地會起事，匪眾蔓延，攻佔彰化與竹塹等處地方。",
    "howKnown": "轉述",
    "quote": "彰化天地會匪四虐蔓延，彰化、竹塹各處被佔",
    "relations": [],
    "side": "lin",
    "subtitle": "賊兵攻佔彰化竹塹",
    "whenAr": "",
    "whenCh": "十二月以前",
    "whenKnownCh": "十二月二十四日",
    "where": "彰化、竹塹",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "彰化"
    },
    "doc_id": "台20"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "彰化天地會匪四虐蔓延，彰化、竹塹各處被佔",
          "reporter": "易連",
          "subtitle": "賊兵攻佔彰化竹塹",
          "whenCh": "十二月以前",
          "where": "彰化、竹塹"
        }
      ],
      "hops": [
        {
          "from_person": "易連",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "茲於十二月二十四日，接據署北路淡水營都司事守備易連稟稱：竊照彰化天地會匪四虐蔓延，彰化、竹塹各處被佔，稟報難通",
          "to_person": "常青",
          "whenAr": "1787/02/11",
          "whenCh": "十二月二十四日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "彰化天地會匪四虐蔓延，彰化、竹塹各處被佔",
            "reporter": "易連",
            "subtitle": "賊兵攻佔彰化竹塹",
            "whenCh": "十二月以前",
            "where": "彰化、竹塹"
          }
        ],
        "hops": [
          {
            "from_person": "易連",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "茲於十二月二十四日，接據署北路淡水營都司事守備易連稟稱：竊照彰化天地會匪四虐蔓延，彰化、竹塹各處被佔，稟報難通",
            "to_person": "常青",
            "whenAr": "1787/02/11",
            "whenCh": "十二月二十四日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台20

```json
{
  "doc_id": "台20",
  "evTitle": "八芝蘭賊首樹旗招匪",
  "event": {
    "description": "八芝蘭賊首賴水、郭穩等樹立大旗招募千餘人，並派遣吳異人（吳志趙）等人前往艋舺聲稱借道接應。",
    "howKnown": "轉述",
    "quote": "本月初十日巳刻，有八芝蘭賊首賴水、郭穩等樹立大旗，招匪千餘人，遣夥吳異人，即貢生吳志趙，同胞叔吳尊、伊弟吳淑夜、游異等，挺身到艋，聲稱要帶兵前往接應，借道經過",
    "relations": [
      {
        "evidence": "遣夥吳異人",
        "relation": "遣",
        "relation_type": "command",
        "source": "賴水",
        "target": "吳異人"
      },
      {
        "evidence": "遣夥吳異人",
        "relation": "遣",
        "relation_type": "command",
        "source": "郭穩",
        "target": "吳異人"
      },
      {
        "evidence": "同胞叔吳尊",
        "relation": "同胞叔",
        "relation_type": "kinship",
        "source": "吳異人",
        "target": "吳尊"
      },
      {
        "evidence": "伊弟吳淑",
        "relation": "伊弟",
        "relation_type": "kinship",
        "source": "吳異人",
        "target": "吳淑"
      }
    ],
    "side": "lin",
    "subtitle": "八芝蘭賊首樹旗招匪",
    "whenAr": "1787/01/28",
    "whenCh": "十二月初十日",
    "whenKnownCh": "十二月二十四日",
    "where": "八芝蘭",
    "who": [
      "賴水",
      "郭穩",
      "吳異人",
      "吳尊",
      "吳淑",
      "游異"
    ],
    "who_loc": {
      "吳尊": "艋舺",
      "吳淑": "艋舺",
      "吳異人": "艋舺",
      "游異": "艋舺",
      "賴水": "八芝蘭",
      "郭穩": "八芝蘭"
    },
    "doc_id": "台20"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "本月初十日巳刻，有八芝蘭賊首賴水、郭穩等樹立大旗，招匪千餘人，遣夥吳異人，即貢生吳志趙，同胞叔吳尊、伊弟吳淑夜、游異等，挺身到艋，聲稱要帶兵前往接應，借道經過，並不傷民，不必驚惶阻擋。",
          "reporter": "防禦義民",
          "subtitle": "八芝蘭賊首樹旗招匪",
          "whenCh": "十二月初十日巳刻",
          "where": "八芝蘭"
        }
      ],
      "hops": [
        {
          "from_person": "署北路淡水營都司事守備易連",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "茲於十二月二十四日，接據署北路淡水營都司事守備易連稟稱",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/02/11",
          "whenCh": "十二月二十四日"
        },
        {
          "from_person": "防禦義民",
          "how": "報知",
          "inferred": false,
          "layer": 2,
          "place": "艋舺",
          "quote": "經防禦義民即來報知，署都司",
          "to_person": "署北路淡水營都司事守備易連",
          "whenAr": "1787/01/28",
          "whenCh": "十二月初十日"
        },
        {
          "from_person": "吳異人",
          "how": "口述",
          "inferred": false,
          "layer": 3,
          "place": "艋舺",
          "quote": "遣夥吳異人，即貢生吳志趙，同胞叔吳尊、伊弟吳淑夜、游異等，挺身到艋，聲稱要帶兵前往接應，借道經過，並不傷民，不必驚惶阻擋。等語。經防禦義民即來報知",
          "to_person": "防禦義民",
          "whenAr": "1787/01/28",
          "whenCh": "十二月初十日巳刻"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "本月初十日巳刻，有八芝蘭賊首賴水、郭穩等樹立大旗，招匪千餘人，遣夥吳異人，即貢生吳志趙，同胞叔吳尊、伊弟吳淑夜、游異等，挺身到艋，聲稱要帶兵前往接應，借道經過，並不傷民，不必驚惶阻擋。",
            "reporter": "防禦義民",
            "subtitle": "八芝蘭賊首樹旗招匪",
            "whenCh": "十二月初十日巳刻",
            "where": "八芝蘭"
          }
        ],
        "hops": [
          {
            "from_person": "署北路淡水營都司事守備易連",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "茲於十二月二十四日，接據署北路淡水營都司事守備易連稟稱",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/02/11",
            "whenCh": "十二月二十四日"
          },
          {
            "from_person": "防禦義民",
            "how": "報知",
            "inferred": false,
            "layer": 2,
            "place": "艋舺",
            "quote": "經防禦義民即來報知，署都司",
            "to_person": "署北路淡水營都司事守備易連",
            "whenAr": "1787/01/28",
            "whenCh": "十二月初十日"
          },
          {
            "from_person": "吳異人",
            "how": "口述",
            "inferred": false,
            "layer": 3,
            "place": "艋舺",
            "quote": "遣夥吳異人，即貢生吳志趙，同胞叔吳尊、伊弟吳淑夜、游異等，挺身到艋，聲稱要帶兵前往接應，借道經過，並不傷民，不必驚惶阻擋。等語。經防禦義民即來報知",
            "to_person": "防禦義民",
            "whenAr": "1787/01/28",
            "whenCh": "十二月初十日巳刻"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台20

```json
{
  "doc_id": "台20",
  "evTitle": "北路各庄賊匪蜂起焚殺",
  "event": {
    "description": "新庄、下庄仔、中港厝、擺接庄、戶尾、八里坌、長道坑等處賊首各招匪千餘人，豎立大旗佔據民房，焚殺居民並折毀新庄衙門。",
    "howKnown": "轉述",
    "quote": "同日賊匪四處蜂起，新庄賊首林小文、劉長芳、林三奇、賴欲等，下庄仔、中港厝賊黨黃祖成、葉山林、陳軒、李壬等，擺接庄賊黨賴樹、賴國等；戶尾、八里坌、長道坑等庄賊黨何馬、何記、吳三奇、莊漢等，各招匪千餘人，俱豎立大旗，佔踞各處地方民房、店房，男婦老幼俱被焚殺，折毀新庄衙門。",
    "relations": [],
    "side": "lin",
    "subtitle": "北路各庄賊匪蜂起焚殺",
    "whenAr": "1787/01/28",
    "whenCh": "十二月初十日",
    "whenKnownCh": "十二月二十四日",
    "where": "新庄",
    "who": [
      "林小文",
      "劉長芳",
      "林三奇",
      "賴欲",
      "黃祖成",
      "葉山林",
      "陳軒",
      "李壬",
      "賴樹",
      "賴國",
      "何馬",
      "何記",
      "吳三奇",
      "莊漢"
    ],
    "who_loc": {
      "何記": "戶尾",
      "何馬": "戶尾",
      "劉長芳": "新庄",
      "吳三奇": "戶尾",
      "李壬": "下庄仔",
      "林三奇": "新庄",
      "林小文": "新庄",
      "莊漢": "戶尾",
      "葉山林": "下庄仔",
      "賴國": "擺接庄",
      "賴樹": "擺接庄",
      "賴欲": "新庄",
      "陳軒": "下庄仔",
      "黃祖成": "下庄仔"
    },
    "doc_id": "台20"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "同日賊匪四處蜂起，新庄賊首林小文、劉長芳、林三奇、賴欲等，下庄仔、中港厝賊黨黃祖成、葉山林、陳軒、李壬等，擺接庄賊黨賴樹、賴國等；戶尾、八里坌、長道坑等庄賊黨何馬、何記、吳三奇、莊漢等，各招匪千餘人，俱豎立大旗，佔踞各處地方民房、店房，男婦老幼俱被焚殺，折毀新庄衙門。",
          "reporter": "署北路淡水營都司事守備易連",
          "subtitle": "北路各庄賊匪蜂起焚殺",
          "whenCh": "十二月初十日",
          "where": "新庄、下庄仔、中港厝、擺接庄、戶尾、八里坌、長道坑"
        }
      ],
      "hops": [
        {
          "from_person": "署北路淡水營都司事守備易連",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "茲於十二月二十四日，接據署北路淡水營都司事守備易連稟稱：...為此飛稟。等情到臣。",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/02/11",
          "whenCh": "乾隆五十一年十二月二十四日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "同日賊匪四處蜂起，新庄賊首林小文、劉長芳、林三奇、賴欲等，下庄仔、中港厝賊黨黃祖成、葉山林、陳軒、李壬等，擺接庄賊黨賴樹、賴國等；戶尾、八里坌、長道坑等庄賊黨何馬、何記、吳三奇、莊漢等，各招匪千餘人，俱豎立大旗，佔踞各處地方民房、店房，男婦老幼俱被焚殺，折毀新庄衙門。",
            "reporter": "署北路淡水營都司事守備易連",
            "subtitle": "北路各庄賊匪蜂起焚殺",
            "whenCh": "十二月初十日",
            "where": "新庄、下庄仔、中港厝、擺接庄、戶尾、八里坌、長道坑"
          }
        ],
        "hops": [
          {
            "from_person": "署北路淡水營都司事守備易連",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "茲於十二月二十四日，接據署北路淡水營都司事守備易連稟稱：...為此飛稟。等情到臣。",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/02/11",
            "whenCh": "乾隆五十一年十二月二十四日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台20

```json
{
  "doc_id": "台20",
  "evTitle": "新庄中港厝等處禦敵交戰",
  "event": {
    "description": "賊匪於新庄、下庄、中港厝、海山頭等地與署都司易連率領的兵民及義民激烈交戰，被擊殺五十餘人。",
    "howKnown": "轉述",
    "quote": "署都司於十三日辰刻，帶領兵民先攻新庄...直攻下庄至草店尾大街...進攻中港厝...分路進攻海山頭...四面攻殺，鎗炮齊發，殺死賊匪五十餘人",
    "relations": [],
    "side": "lin",
    "subtitle": "新庄中港厝等處禦敵交戰",
    "whenAr": "1787/01/31",
    "whenCh": "十二月十三日",
    "whenKnownCh": "十二月二十四日",
    "where": "新庄",
    "who": [],
    "who_loc": {},
    "doc_id": "台20"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "署都司於十三日辰刻，帶領兵民先攻新庄，以扼其吭；守備董得魁、把總蘇陞等，帶領義民五百名，由艋舺渡河，直攻下庄至草店尾大街；都司同千總席榮等帶兵三百名，由草店尾河坡先斷浮橋，進攻國王廟邊；李因、鄭追、李明、黃挽等督率義民五百名，由武朥灣進攻中港厝；監生黃朝陽、林講、徐修等督率義民六百名，由中港厝分路進攻海山頭；又廣省義民邱龍四、林貴陽等埋伏彭厝庄，四面攻殺，鎗炮齊發，殺死賊匪五十餘人",
          "reporter": "署北路淡水營都司事守備易連",
          "subtitle": "新庄中港厝等處禦敵交戰",
          "whenCh": "十二月十三日",
          "where": "新庄"
        }
      ],
      "hops": [
        {
          "from_person": "署北路淡水營都司事守備易連",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "茲於十二月二十四日，接據署北路淡水營都司事守備易連稟稱",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/02/11",
          "whenCh": "十二月二十四日"
        },
        {
          "from_person": "署北路淡水營都司事守備易連",
          "how": "親見",
          "inferred": true,
          "layer": 2,
          "place": "新庄",
          "quote": "署都司於十三日辰刻，帶領兵民先攻新庄",
          "to_person": "署北路淡水營都司事守備易連",
          "whenAr": "1787/01/31",
          "whenCh": "十二月十三日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "署都司於十三日辰刻，帶領兵民先攻新庄，以扼其吭；守備董得魁、把總蘇陞等，帶領義民五百名，由艋舺渡河，直攻下庄至草店尾大街；都司同千總席榮等帶兵三百名，由草店尾河坡先斷浮橋，進攻國王廟邊；李因、鄭追、李明、黃挽等督率義民五百名，由武朥灣進攻中港厝；監生黃朝陽、林講、徐修等督率義民六百名，由中港厝分路進攻海山頭；又廣省義民邱龍四、林貴陽等埋伏彭厝庄，四面攻殺，鎗炮齊發，殺死賊匪五十餘人",
            "reporter": "署北路淡水營都司事守備易連",
            "subtitle": "新庄中港厝等處禦敵交戰",
            "whenCh": "十二月十三日",
            "where": "新庄"
          }
        ],
        "hops": [
          {
            "from_person": "署北路淡水營都司事守備易連",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "茲於十二月二十四日，接據署北路淡水營都司事守備易連稟稱",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/02/11",
            "whenCh": "十二月二十四日"
          },
          {
            "from_person": "署北路淡水營都司事守備易連",
            "how": "親見",
            "inferred": true,
            "layer": 2,
            "place": "新庄",
            "quote": "署都司於十三日辰刻，帶領兵民先攻新庄",
            "to_person": "署北路淡水營都司事守備易連",
            "whenAr": "1787/01/31",
            "whenCh": "十二月十三日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台20

```json
{
  "doc_id": "台20",
  "evTitle": "戶尾八里坌等處禦敵交戰",
  "event": {
    "description": "賊匪於戶尾、八里坌、長道坑等處與義民交戰，被擊殺五十餘人，官眷被救出。",
    "howKnown": "轉述",
    "quote": "十三日派撥戶尾庄蔡才...進攻戶尾、八里坌、長道坑等處，殺死賊匪五十餘人，救出程同知并前任新庄司李國楷兩家官眷",
    "relations": [],
    "side": "lin",
    "subtitle": "戶尾八里坌等處禦敵交戰",
    "whenAr": "1787/01/31",
    "whenCh": "十二月十三日",
    "whenKnownCh": "十二月二十四日",
    "where": "戶尾",
    "who": [],
    "who_loc": {},
    "doc_id": "台20"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "十三日派撥戶尾庄蔡才、陳口、林球等率領義民三百名，和尚洲庄鄭窓、楊口、黃天麟、趙暢等率領義民六百名，大坪頂庄黃英、王倍、王步雲等率領義民四百名，進攻戶尾、八里坌、長道坑等處，殺死賊匪五十餘人，救出程同知并前任新庄司李國楷兩家官眷，守禦港口。",
          "reporter": "易連",
          "subtitle": "戶尾八里坌等處禦敵交戰",
          "whenCh": "十二月十三日",
          "where": "戶尾、八里坌、長道坑等處"
        }
      ],
      "hops": [
        {
          "from_person": "易連",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "茲於十二月二十四日，接據署北路淡水營都司事守備易連稟稱……為此飛稟。等情到臣。",
          "to_person": "常青",
          "whenAr": "1787/02/11",
          "whenCh": "十二月二十四日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "十三日派撥戶尾庄蔡才、陳口、林球等率領義民三百名，和尚洲庄鄭窓、楊口、黃天麟、趙暢等率領義民六百名，大坪頂庄黃英、王倍、王步雲等率領義民四百名，進攻戶尾、八里坌、長道坑等處，殺死賊匪五十餘人，救出程同知并前任新庄司李國楷兩家官眷，守禦港口。",
            "reporter": "易連",
            "subtitle": "戶尾八里坌等處禦敵交戰",
            "whenCh": "十二月十三日",
            "where": "戶尾、八里坌、長道坑等處"
          }
        ],
        "hops": [
          {
            "from_person": "易連",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "茲於十二月二十四日，接據署北路淡水營都司事守備易連稟稱……為此飛稟。等情到臣。",
            "to_person": "常青",
            "whenAr": "1787/02/11",
            "whenCh": "十二月二十四日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台20

```json
{
  "doc_id": "台20",
  "evTitle": "內湖八芝蘭與兵民血戰",
  "event": {
    "description": "賊匪於內湖、八芝蘭一帶與官兵及義民對敵血戰，殺死義民百餘人，奪其大炮，後被擊散。",
    "howKnown": "轉述",
    "quote": "十四日...殺賊抵内湖，集攻八芝蘭，與賊對敵，義民被殺百餘人，大炮沉溺一枝，殺賊五十餘名。義民血戰，餘賊逃散",
    "relations": [],
    "side": "lin",
    "subtitle": "內湖八芝蘭與兵民血戰",
    "whenAr": "1787/02/01",
    "whenCh": "十二月十四日",
    "whenKnownCh": "十二月二十四日",
    "where": "內湖",
    "who": [],
    "who_loc": {},
    "doc_id": "台20"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "十四日署都司同千總張正耀等，率兵三百名，和尚洲庄鄭享、蔡論、陳唇等率領義民五百名，由北投琪里岸；孫立勳、黃采、黃辛元、黃光等率領義民六百名由上埤頭，殺賊抵内湖，集攻八芝蘭，與賊對敵，義民被殺百餘人，大炮沉溺一枝，殺賊五十餘名。義民血戰，餘賊逃散，奪回大旗四桿、馬一匹。",
          "reporter": "易連",
          "subtitle": "內湖八芝蘭與兵民血戰",
          "whenCh": "十二月十四日",
          "where": "內湖、八芝蘭"
        }
      ],
      "hops": [
        {
          "from_person": "易連",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "茲於十二月二十四日，接據署北路淡水營都司事守備易連稟稱：...為此飛稟。等情到臣。",
          "to_person": "常青",
          "whenAr": "1787/02/11",
          "whenCh": "十二月二十四日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "十四日署都司同千總張正耀等，率兵三百名，和尚洲庄鄭享、蔡論、陳唇等率領義民五百名，由北投琪里岸；孫立勳、黃采、黃辛元、黃光等率領義民六百名由上埤頭，殺賊抵内湖，集攻八芝蘭，與賊對敵，義民被殺百餘人，大炮沉溺一枝，殺賊五十餘名。義民血戰，餘賊逃散，奪回大旗四桿、馬一匹。",
            "reporter": "易連",
            "subtitle": "內湖八芝蘭與兵民血戰",
            "whenCh": "十二月十四日",
            "where": "內湖、八芝蘭"
          }
        ],
        "hops": [
          {
            "from_person": "易連",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "茲於十二月二十四日，接據署北路淡水營都司事守備易連稟稱：...為此飛稟。等情到臣。",
            "to_person": "常青",
            "whenAr": "1787/02/11",
            "whenCh": "十二月二十四日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台20

```json
{
  "doc_id": "台20",
  "evTitle": "擺接庄紮排欲渡河",
  "event": {
    "description": "賊匪於夜間蜂擁至擺接一帶，豎立大旗，紮備竹排，企圖渡河。",
    "howKnown": "轉述",
    "quote": "是夜，賊匪蜂擁至擺接一帶豎立大旗，紮備竹排，正欲渡河時",
    "relations": [],
    "side": "lin",
    "subtitle": "擺接庄紮排欲渡河",
    "whenAr": "1787/02/01",
    "whenCh": "十二月十四日",
    "whenKnownCh": "十二月二十四日",
    "where": "擺接",
    "who": [],
    "who_loc": {},
    "doc_id": "台20"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "是夜，賊匪蜂擁至擺接一帶豎立大旗，紮備竹排，正欲渡河時",
          "reporter": "易連",
          "subtitle": "擺接庄紮排欲渡河",
          "whenCh": "十二月十四日夜",
          "where": "擺接"
        }
      ],
      "hops": [
        {
          "from_person": "易連",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "茲於十二月二十四日，接據署北路淡水營都司事守備易連稟稱：...是夜，賊匪蜂擁至擺接一帶豎立大旗，紮備竹排，正欲渡河時，方回軍之際，立即嚴行堵禦。",
          "to_person": "常青",
          "whenAr": "1787/02/11",
          "whenCh": "十二月二十四日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "是夜，賊匪蜂擁至擺接一帶豎立大旗，紮備竹排，正欲渡河時",
            "reporter": "易連",
            "subtitle": "擺接庄紮排欲渡河",
            "whenCh": "十二月十四日夜",
            "where": "擺接"
          }
        ],
        "hops": [
          {
            "from_person": "易連",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "茲於十二月二十四日，接據署北路淡水營都司事守備易連稟稱：...是夜，賊匪蜂擁至擺接一帶豎立大旗，紮備竹排，正欲渡河時，方回軍之際，立即嚴行堵禦。",
            "to_person": "常青",
            "whenAr": "1787/02/11",
            "whenCh": "十二月二十四日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台20

```json
{
  "doc_id": "台20",
  "evTitle": "賊匪復聚暗坑仔出沒",
  "event": {
    "description": "敗散之賊匪重新聚集於暗坑仔等處，不時出沒。",
    "howKnown": "轉述",
    "quote": "但賊匪雖暫奔散，現在復聚暗坑仔等處，不時出沒",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪復聚暗坑仔出沒",
    "whenAr": "",
    "whenCh": "十二月十五日之後",
    "whenKnownCh": "十二月二十四日",
    "where": "暗坑仔",
    "who": [],
    "who_loc": {},
    "doc_id": "台20"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "但賊匪雖暫奔散，現在復聚暗坑仔等處，不時出沒",
          "reporter": "署北路淡水營都司事守備易連",
          "subtitle": "賊匪復聚暗坑仔出沒",
          "whenCh": "十二月十五日之後",
          "where": "暗坑仔"
        }
      ],
      "hops": [
        {
          "from_person": "署北路淡水營都司事守備易連",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "茲於十二月二十四日，接據署北路淡水營都司事守備易連稟稱：...為此飛稟。等情到臣。",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/02/11",
          "whenCh": "乾隆五十一年十二月二十四日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "但賊匪雖暫奔散，現在復聚暗坑仔等處，不時出沒",
            "reporter": "署北路淡水營都司事守備易連",
            "subtitle": "賊匪復聚暗坑仔出沒",
            "whenCh": "十二月十五日之後",
            "where": "暗坑仔"
          }
        ],
        "hops": [
          {
            "from_person": "署北路淡水營都司事守備易連",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "茲於十二月二十四日，接據署北路淡水營都司事守備易連稟稱：...為此飛稟。等情到臣。",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/02/11",
            "whenCh": "乾隆五十一年十二月二十四日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台22

```json
{
  "doc_id": "台22",
  "evTitle": "林爽文結黨騷擾地方",
  "event": {
    "description": "乾隆五十一年十一月間，林爽文在彰化縣結黨滋事，騷擾地方，文武官員未能將其擒獲。",
    "howKnown": "轉述",
    "quote": "本年十一月間，卑職等聞彰化縣匪徒林爽文結黨四虐，騷擾地方，文武官員擒捕未獲。",
    "relations": [],
    "side": "lin",
    "subtitle": "林爽文結黨騷擾地方",
    "whenAr": "1786/12",
    "whenCh": "十一月間",
    "whenKnownCh": "十二月初九日",
    "where": "彰化縣",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "彰化縣"
    },
    "doc_id": "台22"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "本年十一月間，卑職等聞彰化縣匪徒林爽文結黨四虐，騷擾地方，文武官員擒捕未獲。",
          "reporter": "程峻、董得魁",
          "subtitle": "林爽文結黨騷擾地方",
          "whenCh": "乾隆五十一年十一月間",
          "where": "彰化縣"
        }
      ],
      "hops": [
        {
          "from_person": "楊添",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "本年十二月初九日亥刻，臣接據署臺灣府淡水同知程峻、竹塹營守備董得魁會銜差役楊添投稟報稱...當即傳喚該差楊添進署，面加詢問",
          "to_person": "任承恩",
          "whenAr": "1787/01/27",
          "whenCh": "乾隆五十一年十二月初九日亥刻"
        },
        {
          "from_person": "程峻、董得魁",
          "how": "差遣",
          "inferred": true,
          "layer": 2,
          "place": "淡水",
          "quote": "隨即專差搭船馳稟",
          "to_person": "楊添",
          "whenAr": "",
          "whenCh": "乾隆五十一年十一月二十九日後"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "本年十一月間，卑職等聞彰化縣匪徒林爽文結黨四虐，騷擾地方，文武官員擒捕未獲。",
            "reporter": "程峻、董得魁",
            "subtitle": "林爽文結黨騷擾地方",
            "whenCh": "乾隆五十一年十一月間",
            "where": "彰化縣"
          }
        ],
        "hops": [
          {
            "from_person": "楊添",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "本年十二月初九日亥刻，臣接據署臺灣府淡水同知程峻、竹塹營守備董得魁會銜差役楊添投稟報稱...當即傳喚該差楊添進署，面加詢問",
            "to_person": "任承恩",
            "whenAr": "1787/01/27",
            "whenCh": "乾隆五十一年十二月初九日亥刻"
          },
          {
            "from_person": "程峻、董得魁",
            "how": "差遣",
            "inferred": true,
            "layer": 2,
            "place": "淡水",
            "quote": "隨即專差搭船馳稟",
            "to_person": "楊添",
            "whenAr": "",
            "whenCh": "乾隆五十一年十一月二十九日後"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台22

```json
{
  "doc_id": "台22",
  "evTitle": "大墩地方殺害官員",
  "event": {
    "description": "乾隆五十一年十一月二十七日夜，彰化知縣俞峻與北路副將赫生額在大墩地方搜捕匪徒時，遭林爽文部眾殺害。",
    "howKnown": "轉述",
    "quote": "此月二十七日夜，本縣俞在大墩地方拿匪遇害...聞得傳說北路赫副將與俞知縣在大墩地方拿匪，同時被害",
    "relations": [
      {
        "evidence": "此月二十七日夜，本縣俞在大墩地方拿匪遇害",
        "relation": "殺害",
        "relation_type": "conflict",
        "source": "林爽文",
        "target": "俞峻"
      },
      {
        "evidence": "北路赫副將與俞知縣在大墩地方拿匪，同時被害",
        "relation": "殺害",
        "relation_type": "conflict",
        "source": "林爽文",
        "target": "赫生額"
      }
    ],
    "side": "lin",
    "subtitle": "大墩地方殺害官員",
    "whenAr": "1786/12/17",
    "whenCh": "十一月二十七日夜",
    "whenKnownCh": "十二月初九日",
    "where": "大墩",
    "who": [
      "林爽文",
      "俞峻",
      "赫生額"
    ],
    "who_loc": {
      "俞峻": "大墩",
      "林爽文": "大墩",
      "赫生額": "大墩"
    },
    "doc_id": "台22"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "此月二十七日夜，本縣俞在大墩地方拿匪遇害",
          "reporter": "彰邑大肚社番",
          "subtitle": "大墩地方殺害官員",
          "whenCh": "十一月二十七日夜",
          "where": "大墩"
        }
      ],
      "hops": [
        {
          "from_person": "署臺灣府淡水同知程峻、竹塹營守備董得魁",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "臣接據署臺灣府淡水同知程峻、竹塹營守備董得魁會銜差役楊添投稟報稱",
          "to_person": "福建陸路提督任承恩",
          "whenAr": "1787/01/27",
          "whenCh": "乾隆五十一年十二月初九日亥刻"
        },
        {
          "from_person": "淡屬大甲社通事",
          "how": "轉述",
          "inferred": false,
          "layer": 2,
          "place": "淡水",
          "quote": "乃於十一月二十九日，該番忽將原文帶回，並有彰邑大肚社番字寄淡屬大甲社通事據稱",
          "to_person": "署臺灣府淡水同知程峻、竹塹營守備董得魁",
          "whenAr": "1787/01/17",
          "whenCh": "乾隆五十一年十一月二十九日"
        },
        {
          "from_person": "彰邑大肚社番",
          "how": "書信",
          "inferred": false,
          "layer": 3,
          "place": "大肚社",
          "quote": "彰邑大肚社番字寄淡屬大甲社通事據稱",
          "to_person": "淡屬大甲社通事",
          "whenAr": "",
          "whenCh": "乾隆五十一年十一月二十七日至二十九日之間"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "北路赫副將與俞知縣在大墩地方拿匪，同時被害",
          "reporter": "差役楊添",
          "subtitle": "大墩地方殺害官員",
          "whenCh": "十一月二十七日夜",
          "where": "大墩"
        }
      ],
      "hops": [
        {
          "from_person": "差役楊添",
          "how": "口述",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "復據該差楊添口稱：小的起身在路上時，聞得傳說北路赫副將與俞知縣在大墩地方拿匪，同時被害",
          "to_person": "福建陸路提督任承恩",
          "whenAr": "1787/01/27",
          "whenCh": "乾隆五十一年十二月初九日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "此月二十七日夜，本縣俞在大墩地方拿匪遇害",
            "reporter": "彰邑大肚社番",
            "subtitle": "大墩地方殺害官員",
            "whenCh": "十一月二十七日夜",
            "where": "大墩"
          }
        ],
        "hops": [
          {
            "from_person": "署臺灣府淡水同知程峻、竹塹營守備董得魁",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "臣接據署臺灣府淡水同知程峻、竹塹營守備董得魁會銜差役楊添投稟報稱",
            "to_person": "福建陸路提督任承恩",
            "whenAr": "1787/01/27",
            "whenCh": "乾隆五十一年十二月初九日亥刻"
          },
          {
            "from_person": "淡屬大甲社通事",
            "how": "轉述",
            "inferred": false,
            "layer": 2,
            "place": "淡水",
            "quote": "乃於十一月二十九日，該番忽將原文帶回，並有彰邑大肚社番字寄淡屬大甲社通事據稱",
            "to_person": "署臺灣府淡水同知程峻、竹塹營守備董得魁",
            "whenAr": "1787/01/17",
            "whenCh": "乾隆五十一年十一月二十九日"
          },
          {
            "from_person": "彰邑大肚社番",
            "how": "書信",
            "inferred": false,
            "layer": 3,
            "place": "大肚社",
            "quote": "彰邑大肚社番字寄淡屬大甲社通事據稱",
            "to_person": "淡屬大甲社通事",
            "whenAr": "",
            "whenCh": "乾隆五十一年十一月二十七日至二十九日之間"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "北路赫副將與俞知縣在大墩地方拿匪，同時被害",
            "reporter": "差役楊添",
            "subtitle": "大墩地方殺害官員",
            "whenCh": "十一月二十七日夜",
            "where": "大墩"
          }
        ],
        "hops": [
          {
            "from_person": "差役楊添",
            "how": "口述",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "復據該差楊添口稱：小的起身在路上時，聞得傳說北路赫副將與俞知縣在大墩地方拿匪，同時被害",
            "to_person": "福建陸路提督任承恩",
            "whenAr": "1787/01/27",
            "whenCh": "乾隆五十一年十二月初九日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台22

```json
{
  "doc_id": "台22",
  "evTitle": "匪徒攻陷彰化縣城",
  "event": {
    "description": "乾隆五十一年十一月，林爽文等匪徒攻陷彰化縣城並予以竊踞，導致路途梗塞，文報無法傳遞。",
    "howKnown": "轉述",
    "quote": "本日早彰城失陷，路途梗塞，不能前遞...現在彰化既為匪徒竊踞",
    "relations": [],
    "side": "lin",
    "subtitle": "匪徒攻陷彰化縣城",
    "whenAr": "1786/12/19",
    "whenCh": "十一月二十九日以前",
    "whenKnownCh": "十二月初九日",
    "where": "彰化縣城",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "彰化縣城"
    },
    "doc_id": "台22"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "本日早彰城失陷，路途梗塞，不能前遞",
          "reporter": "彰邑大肚社番",
          "subtitle": "匪徒攻陷彰化縣城",
          "whenCh": "十一月二十八日早",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "楊添",
          "how": "口述",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "臣接閱之下，不勝駭異。當即傳喚該差楊添進署，面加詢問，其所稱在淡水得知賊匪殺官占城情形，與該廳、營所稟大概相同。",
          "to_person": "任承恩",
          "whenAr": "1787/01/27",
          "whenCh": "十二月初九日亥刻"
        },
        {
          "from_person": "程峻、董得魁",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "淡水",
          "quote": "適有商船飄泊淡港，隨即專差搭船馳稟。",
          "to_person": "楊添",
          "whenAr": "",
          "whenCh": "十一月二十九日以後"
        },
        {
          "from_person": "淡屬大甲社通事",
          "how": "轉述",
          "inferred": true,
          "layer": 3,
          "place": "淡水",
          "quote": "並有彰邑大肚社番字寄淡屬大甲社通事據稱",
          "to_person": "程峻、董得魁",
          "whenAr": "1787/01/17",
          "whenCh": "十一月二十九日"
        },
        {
          "from_person": "彰邑大肚社番",
          "how": "移會",
          "inferred": false,
          "layer": 4,
          "place": "大肚社",
          "quote": "並有彰邑大肚社番字寄淡屬大甲社通事",
          "to_person": "淡屬大甲社通事",
          "whenAr": "",
          "whenCh": "十一月二十九日以前"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "本日早彰城失陷，路途梗塞，不能前遞",
            "reporter": "彰邑大肚社番",
            "subtitle": "匪徒攻陷彰化縣城",
            "whenCh": "十一月二十八日早",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "楊添",
            "how": "口述",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "臣接閱之下，不勝駭異。當即傳喚該差楊添進署，面加詢問，其所稱在淡水得知賊匪殺官占城情形，與該廳、營所稟大概相同。",
            "to_person": "任承恩",
            "whenAr": "1787/01/27",
            "whenCh": "十二月初九日亥刻"
          },
          {
            "from_person": "程峻、董得魁",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "淡水",
            "quote": "適有商船飄泊淡港，隨即專差搭船馳稟。",
            "to_person": "楊添",
            "whenAr": "",
            "whenCh": "十一月二十九日以後"
          },
          {
            "from_person": "淡屬大甲社通事",
            "how": "轉述",
            "inferred": true,
            "layer": 3,
            "place": "淡水",
            "quote": "並有彰邑大肚社番字寄淡屬大甲社通事據稱",
            "to_person": "程峻、董得魁",
            "whenAr": "1787/01/17",
            "whenCh": "十一月二十九日"
          },
          {
            "from_person": "彰邑大肚社番",
            "how": "移會",
            "inferred": false,
            "layer": 4,
            "place": "大肚社",
            "quote": "並有彰邑大肚社番字寄淡屬大甲社通事",
            "to_person": "淡屬大甲社通事",
            "whenAr": "",
            "whenCh": "十一月二十九日以前"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台23

```json
{
  "doc_id": "台23",
  "evTitle": "賊匪攻破彰化縣城",
  "event": {
    "description": "臺灣民變起事之賊匪滋事，並攻破彰化縣城。",
    "howKnown": "轉述",
    "quote": "臺灣又有賊匪滋攻破彰化縣城",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪攻破彰化縣城",
    "whenAr": "",
    "whenCh": "",
    "whenKnownCh": "十二月初八日",
    "where": "彰化縣城",
    "who": [
      "賊匪"
    ],
    "who_loc": {
      "賊匪": "彰化縣城"
    },
    "doc_id": "台23"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "臺灣又有賊匪滋攻破彰化縣城",
          "reporter": "黃仕簡",
          "subtitle": "賊匪攻破彰化縣城",
          "whenCh": "",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "黃仕簡",
          "how": "札達",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "臣先於十二月初八日接到水師提臣黃仕簡札達，訪聞得臺灣又有賊匪滋攻破彰化縣城...囑令臣一體留心",
          "to_person": "任承恩",
          "whenAr": "1787/01/26",
          "whenCh": "乾隆五十一年十二月初八日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "臺灣又有賊匪滋攻破彰化縣城",
            "reporter": "黃仕簡",
            "subtitle": "賊匪攻破彰化縣城",
            "whenCh": "",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "黃仕簡",
            "how": "札達",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "臣先於十二月初八日接到水師提臣黃仕簡札達，訪聞得臺灣又有賊匪滋攻破彰化縣城...囑令臣一體留心",
            "to_person": "任承恩",
            "whenAr": "1787/01/26",
            "whenCh": "乾隆五十一年十二月初八日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台21

```json
{
  "doc_id": "台21",
  "evTitle": "林爽文結黨騷擾地方",
  "event": {
    "description": "乾隆五十一年十一月初間，林爽文於彰化縣地方結黨四虐、騷擾地方，地方文武官員未能將其擒獲。",
    "howKnown": "轉述",
    "quote": "十一月初間，聞有彰化縣匪徒林爽文結黨四虐，騷擾地方，文武官員擒捕未獲。",
    "relations": [],
    "side": "lin",
    "subtitle": "林爽文結黨騷擾地方",
    "whenAr": "1786/12",
    "whenCh": "十一月初間",
    "whenKnownCh": "十一月二十九日",
    "where": "彰化縣",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "彰化縣"
    },
    "doc_id": "台21"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "十一月初間，聞有彰化縣匪徒林爽文結黨四虐，騷擾地方，文武官員擒捕未獲。",
          "reporter": "程峻、董得魁",
          "subtitle": "林爽文結黨騷擾地方",
          "whenCh": "乾隆五十一年十一月初間",
          "where": "彰化縣"
        }
      ],
      "hops": [
        {
          "from_person": "程峻、董得魁",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "坊口",
          "quote": "途次坊口，接據署淡防廳程峻、竹塹營守備董得魁會稟，十一月初間，聞有彰化縣匪徒林爽文結黨四虐，騷擾地方，文武官員擒捕未獲。",
          "to_person": "常青",
          "whenAr": "",
          "whenCh": "乾隆五十一年十一月二十九日後"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "十一月初間，聞有彰化縣匪徒林爽文結黨四虐，騷擾地方，文武官員擒捕未獲。",
            "reporter": "程峻、董得魁",
            "subtitle": "林爽文結黨騷擾地方",
            "whenCh": "乾隆五十一年十一月初間",
            "where": "彰化縣"
          }
        ],
        "hops": [
          {
            "from_person": "程峻、董得魁",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "坊口",
            "quote": "途次坊口，接據署淡防廳程峻、竹塹營守備董得魁會稟，十一月初間，聞有彰化縣匪徒林爽文結黨四虐，騷擾地方，文武官員擒捕未獲。",
            "to_person": "常青",
            "whenAr": "",
            "whenCh": "乾隆五十一年十一月二十九日後"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台21

```json
{
  "doc_id": "台21",
  "evTitle": "匪徒於大墩殺害知縣",
  "event": {
    "description": "乾隆五十一年十一月二十七日夜間，彰化知縣俞峻在大墩地方搜捕匪徒時，遭民變匪徒襲擊遇害。",
    "howKnown": "轉述",
    "quote": "十一月二十七夜，彰化俞知縣在大墩地方拿匪遇害。",
    "relations": [
      {
        "evidence": "彰化俞知縣在大墩地方拿匪遇害",
        "relation": "殺害",
        "relation_type": "conflict",
        "source": "林爽文",
        "target": "俞知縣"
      }
    ],
    "side": "lin",
    "subtitle": "匪徒於大墩殺害知縣",
    "whenAr": "1787/01/16",
    "whenCh": "十一月二十七夜",
    "whenKnownCh": "十一月二十九日",
    "where": "大墩",
    "who": [
      "林爽文",
      "俞知縣"
    ],
    "who_loc": {
      "俞知縣": "大墩",
      "林爽文": "大墩"
    },
    "doc_id": "台21"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "十一月二十七夜，彰化俞知縣在大墩地方拿匪遇害。",
          "reporter": "彰邑大肚社番",
          "subtitle": "匪徒於大墩殺害知縣",
          "whenCh": "乾隆五十一年十一月二十七日夜",
          "where": "大墩"
        }
      ],
      "hops": [
        {
          "from_person": "署淡防廳程峻、竹塹營守備董得魁",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "坊口",
          "quote": "途次坊口，接據署淡防廳程峻、竹塹營守備董得魁會稟...等情到臣。",
          "to_person": "閩浙總督常青",
          "whenAr": "",
          "whenCh": "乾隆五十一年十二月十一日後"
        },
        {
          "from_person": "淡屬大甲社通事",
          "how": "轉述",
          "inferred": false,
          "layer": 2,
          "place": "淡水",
          "quote": "十一月二十九日，據該番帶回原文，並有彰邑大肚社番寄字淡屬大甲社通事據稱...等語。",
          "to_person": "署淡防廳程峻、竹塹營守備董得魁",
          "whenAr": "",
          "whenCh": "乾隆五十一年十一月二十九日"
        },
        {
          "from_person": "彰邑大肚社番",
          "how": "寄字",
          "inferred": false,
          "layer": 3,
          "place": "大甲社",
          "quote": "彰邑大肚社番寄字淡屬大甲社通事據稱",
          "to_person": "淡屬大甲社通事",
          "whenAr": "",
          "whenCh": "乾隆五十一年十一月二十七日夜至二十九日之間"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "十一月二十七夜，彰化俞知縣在大墩地方拿匪遇害。",
            "reporter": "彰邑大肚社番",
            "subtitle": "匪徒於大墩殺害知縣",
            "whenCh": "乾隆五十一年十一月二十七日夜",
            "where": "大墩"
          }
        ],
        "hops": [
          {
            "from_person": "署淡防廳程峻、竹塹營守備董得魁",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "坊口",
            "quote": "途次坊口，接據署淡防廳程峻、竹塹營守備董得魁會稟...等情到臣。",
            "to_person": "閩浙總督常青",
            "whenAr": "",
            "whenCh": "乾隆五十一年十二月十一日後"
          },
          {
            "from_person": "淡屬大甲社通事",
            "how": "轉述",
            "inferred": false,
            "layer": 2,
            "place": "淡水",
            "quote": "十一月二十九日，據該番帶回原文，並有彰邑大肚社番寄字淡屬大甲社通事據稱...等語。",
            "to_person": "署淡防廳程峻、竹塹營守備董得魁",
            "whenAr": "",
            "whenCh": "乾隆五十一年十一月二十九日"
          },
          {
            "from_person": "彰邑大肚社番",
            "how": "寄字",
            "inferred": false,
            "layer": 3,
            "place": "大甲社",
            "quote": "彰邑大肚社番寄字淡屬大甲社通事據稱",
            "to_person": "淡屬大甲社通事",
            "whenAr": "",
            "whenCh": "乾隆五十一年十一月二十七日夜至二十九日之間"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台21

```json
{
  "doc_id": "台21",
  "evTitle": "匪徒攻陷彰化縣城",
  "event": {
    "description": "乾隆五十一年十一月二十八日清晨，民變匪徒攻陷彰化縣城並予以竊踞，導致南北路途梗塞，文報無法通行。",
    "howKnown": "轉述",
    "quote": "本日早彰城失陷，路途梗塞，不能前進",
    "relations": [],
    "side": "lin",
    "subtitle": "匪徒攻陷彰化縣城",
    "whenAr": "1787/01/17",
    "whenCh": "十一月二十八日早",
    "whenKnownCh": "十一月二十九日",
    "where": "彰化縣城",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "彰化縣城"
    },
    "doc_id": "台21"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "本日早彰城失陷，路途梗塞，不能前進",
          "reporter": "彰邑大肚社番",
          "subtitle": "匪徒攻陷彰化縣城",
          "whenCh": "十一月二十八日早",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "署淡防廳程峻、竹塹營守備董得魁",
          "how": "會稟",
          "inferred": false,
          "layer": 1,
          "place": "坊口",
          "quote": "途次坊口，接據署淡防廳程峻、竹塹營守備董得魁會稟",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/01/29",
          "whenCh": "乾隆五十一年十二月十一日後"
        },
        {
          "from_person": "該番",
          "how": "轉遞",
          "inferred": false,
          "layer": 2,
          "place": "交界地方",
          "quote": "十一月二十九日，據該番帶回原文，並有彰邑大肚社番寄字淡屬大甲社通事據稱",
          "to_person": "署淡防廳程峻、竹塹營守備董得魁",
          "whenAr": "1787/01/17",
          "whenCh": "乾隆五十一年十一月二十九日"
        },
        {
          "from_person": "淡屬大甲社通事",
          "how": "轉述",
          "inferred": true,
          "layer": 3,
          "place": "大甲社",
          "quote": "並有彰邑大肚社番寄字淡屬大甲社通事據稱",
          "to_person": "該番",
          "whenAr": "",
          "whenCh": "乾隆五十一年十一月二十九日以前"
        },
        {
          "from_person": "彰邑大肚社番",
          "how": "寄字",
          "inferred": false,
          "layer": 4,
          "place": "大甲社",
          "quote": "彰邑大肚社番寄字淡屬大甲社通事據稱",
          "to_person": "淡屬大甲社通事",
          "whenAr": "1787/01/16",
          "whenCh": "乾隆五十一年十一月二十八日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "本日早彰城失陷，路途梗塞，不能前進",
            "reporter": "彰邑大肚社番",
            "subtitle": "匪徒攻陷彰化縣城",
            "whenCh": "十一月二十八日早",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "署淡防廳程峻、竹塹營守備董得魁",
            "how": "會稟",
            "inferred": false,
            "layer": 1,
            "place": "坊口",
            "quote": "途次坊口，接據署淡防廳程峻、竹塹營守備董得魁會稟",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/01/29",
            "whenCh": "乾隆五十一年十二月十一日後"
          },
          {
            "from_person": "該番",
            "how": "轉遞",
            "inferred": false,
            "layer": 2,
            "place": "交界地方",
            "quote": "十一月二十九日，據該番帶回原文，並有彰邑大肚社番寄字淡屬大甲社通事據稱",
            "to_person": "署淡防廳程峻、竹塹營守備董得魁",
            "whenAr": "1787/01/17",
            "whenCh": "乾隆五十一年十一月二十九日"
          },
          {
            "from_person": "淡屬大甲社通事",
            "how": "轉述",
            "inferred": true,
            "layer": 3,
            "place": "大甲社",
            "quote": "並有彰邑大肚社番寄字淡屬大甲社通事據稱",
            "to_person": "該番",
            "whenAr": "",
            "whenCh": "乾隆五十一年十一月二十九日以前"
          },
          {
            "from_person": "彰邑大肚社番",
            "how": "寄字",
            "inferred": false,
            "layer": 4,
            "place": "大甲社",
            "quote": "彰邑大肚社番寄字淡屬大甲社通事據稱",
            "to_person": "淡屬大甲社通事",
            "whenAr": "1787/01/16",
            "whenCh": "乾隆五十一年十一月二十八日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台24

```json
{
  "doc_id": "台24",
  "evTitle": "林爽文等結黨搶劫",
  "event": {
    "description": "彰化北路大里杙等莊奸民林爽文、王芬等結黨搶劫滋事。",
    "howKnown": "轉述",
    "quote": "北路大里杙等莊，有奸民林爽文、王芬等結黨搶劫",
    "relations": [
      {
        "evidence": "林爽文、王芬等結黨",
        "relation": "結黨",
        "relation_type": "ally",
        "source": "林爽文",
        "target": "王芬"
      }
    ],
    "side": "lin",
    "subtitle": "林爽文等結黨搶劫",
    "whenAr": "1786/12",
    "whenCh": "十一月",
    "whenKnownCh": "十二月十四日",
    "where": "大里杙",
    "who": [
      "林爽文",
      "王芬"
    ],
    "who_loc": {
      "林爽文": "大里杙",
      "王芬": "大里杙"
    },
    "doc_id": "台24"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "北路大里杙等莊，有奸民林爽文、王芬等結黨搶劫",
          "reporter": "臺灣鎮總兵柴大紀、臺灣道永福",
          "subtitle": "林爽文等結黨搶劫",
          "whenCh": "十一月",
          "where": "大里杙"
        }
      ],
      "hops": [
        {
          "from_person": "臺灣鎮總兵柴大紀、臺灣道永福",
          "how": "移稟",
          "inferred": false,
          "layer": 1,
          "place": "臺灣府城",
          "quote": "十四日丑刻，始接據臺灣鎮總兵柴大紀及該道永福移稟...即於初二日由臺灣府城繕稟封發",
          "to_person": "福建巡撫徐嗣曾",
          "whenAr": "1787/01/20",
          "whenCh": "乾隆五十一年十二月初二日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "北路大里杙等莊，有奸民林爽文、王芬等結黨搶劫",
            "reporter": "臺灣鎮總兵柴大紀、臺灣道永福",
            "subtitle": "林爽文等結黨搶劫",
            "whenCh": "十一月",
            "where": "大里杙"
          }
        ],
        "hops": [
          {
            "from_person": "臺灣鎮總兵柴大紀、臺灣道永福",
            "how": "移稟",
            "inferred": false,
            "layer": 1,
            "place": "臺灣府城",
            "quote": "十四日丑刻，始接據臺灣鎮總兵柴大紀及該道永福移稟...即於初二日由臺灣府城繕稟封發",
            "to_person": "福建巡撫徐嗣曾",
            "whenAr": "1787/01/20",
            "whenCh": "乾隆五十一年十二月初二日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台24

```json
{
  "doc_id": "台24",
  "evTitle": "賊匪夜劫大墩營盤",
  "event": {
    "description": "數千名賊匪於十一月二十七日夜四更散而復聚，前往搶劫大墩營盤。",
    "howKnown": "轉述",
    "quote": "二十七日夜四更時候，賊匪散而復聚，竟有數千人往劫大墩營盤。",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪夜劫大墩營盤",
    "whenAr": "1786/12/17",
    "whenCh": "十一月二十七日",
    "whenKnownCh": "十二月十四日",
    "where": "大墩",
    "who": [],
    "who_loc": {},
    "doc_id": "台24"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "二十七日夜四更時候，賊匪散而復聚，竟有數千人往劫大墩營盤。",
          "reporter": "北路中營都司",
          "subtitle": "賊匪夜劫大墩營盤",
          "whenCh": "十一月二十七日夜四更",
          "where": "大墩"
        }
      ],
      "hops": [
        {
          "from_person": "柴大紀、永福",
          "how": "移稟",
          "inferred": false,
          "layer": 1,
          "place": "福建省城",
          "quote": "十四日丑刻，始接據臺灣鎮總兵柴大紀及該道永福移稟",
          "to_person": "徐嗣曾",
          "whenAr": "1787/02/01",
          "whenCh": "十二月十四日丑刻"
        },
        {
          "from_person": "北路中營都司",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "臺灣府城",
          "quote": "本鎮等訪聞北路大里杙等莊……本月初一日辰刻，據北路中營都司報稱",
          "to_person": "柴大紀、永福",
          "whenAr": "1786/12/22",
          "whenCh": "十一月初二日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "二十七日夜四更時候，賊匪散而復聚，竟有數千人往劫大墩營盤。",
            "reporter": "北路中營都司",
            "subtitle": "賊匪夜劫大墩營盤",
            "whenCh": "十一月二十七日夜四更",
            "where": "大墩"
          }
        ],
        "hops": [
          {
            "from_person": "柴大紀、永福",
            "how": "移稟",
            "inferred": false,
            "layer": 1,
            "place": "福建省城",
            "quote": "十四日丑刻，始接據臺灣鎮總兵柴大紀及該道永福移稟",
            "to_person": "徐嗣曾",
            "whenAr": "1787/02/01",
            "whenCh": "十二月十四日丑刻"
          },
          {
            "from_person": "北路中營都司",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "臺灣府城",
            "quote": "本鎮等訪聞北路大里杙等莊……本月初一日辰刻，據北路中營都司報稱",
            "to_person": "柴大紀、永福",
            "whenAr": "1786/12/22",
            "whenCh": "十一月初二日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台24

```json
{
  "doc_id": "台24",
  "evTitle": "賊匪大肚溪截路及南投糾集",
  "event": {
    "description": "賊匪於大肚溪邊聚眾截斷道路，致使信息不通，且在南、北投一帶糾集，意圖進攻彰化縣城。",
    "howKnown": "轉述",
    "quote": "並於大肚溪邊聚匪截路，以致信息不通。南、北〔投〕一帶亦有匪徒糾集，且聞要攻縣城。",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪大肚溪截路及南投糾集",
    "whenAr": "1786/12/18",
    "whenCh": "十一月二十八日",
    "whenKnownCh": "十二月十四日",
    "where": "大肚溪",
    "who": [],
    "who_loc": {},
    "doc_id": "台24"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "並於大肚溪邊聚匪截路，以致信息不通。南、北〔投〕一帶亦有匪徒糾集，且聞要攻縣城。",
          "reporter": "北路中營都司",
          "subtitle": "賊匪大肚溪截路及南投糾集",
          "whenAr": "1786/12/18",
          "whenCh": "乾隆五十一年十一月二十八日",
          "where": "大肚溪、南投、北投"
        }
      ],
      "hops": [
        {
          "from_person": "柴大紀、永福",
          "how": "移稟",
          "inferred": false,
          "layer": 1,
          "place": "福建省城",
          "quote": "十四日丑刻，始接據臺灣鎮總兵柴大紀及該道永福移稟...即於初二日由臺灣府城繕稟封發",
          "to_person": "徐嗣曾",
          "whenAr": "1787/01/03",
          "whenCh": "乾隆五十一年十二月十四日丑刻"
        },
        {
          "from_person": "北路中營都司",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "臺灣府城",
          "quote": "本月初一日辰刻，據北路中營都司報稱...並於大肚溪邊聚匪截路，以致信息不通。南、北〔投〕一帶亦有匪徒糾集，且聞要攻縣城。",
          "to_person": "柴大紀、永福",
          "whenAr": "1786/12/21",
          "whenCh": "乾隆五十一年十二月初一日辰刻"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "並於大肚溪邊聚匪截路，以致信息不通。南、北〔投〕一帶亦有匪徒糾集，且聞要攻縣城。",
            "reporter": "北路中營都司",
            "subtitle": "賊匪大肚溪截路及南投糾集",
            "whenAr": "1786/12/18",
            "whenCh": "乾隆五十一年十一月二十八日",
            "where": "大肚溪、南投、北投"
          }
        ],
        "hops": [
          {
            "from_person": "柴大紀、永福",
            "how": "移稟",
            "inferred": false,
            "layer": 1,
            "place": "福建省城",
            "quote": "十四日丑刻，始接據臺灣鎮總兵柴大紀及該道永福移稟...即於初二日由臺灣府城繕稟封發",
            "to_person": "徐嗣曾",
            "whenAr": "1787/01/03",
            "whenCh": "乾隆五十一年十二月十四日丑刻"
          },
          {
            "from_person": "北路中營都司",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "臺灣府城",
            "quote": "本月初一日辰刻，據北路中營都司報稱...並於大肚溪邊聚匪截路，以致信息不通。南、北〔投〕一帶亦有匪徒糾集，且聞要攻縣城。",
            "to_person": "柴大紀、永福",
            "whenAr": "1786/12/21",
            "whenCh": "乾隆五十一年十二月初一日辰刻"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台24

```json
{
  "doc_id": "台24",
  "evTitle": "賊匪攻陷彰化殺害官員",
  "event": {
    "description": "賊匪攻陷彰化縣城，殺害城內各官員。",
    "howKnown": "轉述",
    "quote": "十一月二十九日在鹿仔港口內，聽得人說彰化縣城内被賊殺害各官",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪攻陷彰化殺害官員",
    "whenAr": "1786/12/19",
    "whenCh": "十一月二十九日",
    "whenKnownCh": "十二月十三日",
    "where": "彰化縣城",
    "who": [],
    "who_loc": {},
    "doc_id": "台24"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "十一月二十九日在鹿仔港口內，聽得人說彰化縣城内被賊殺害各官",
          "reporter": "舵工黃斌",
          "subtitle": "賊匪攻陷彰化殺害官員",
          "whenCh": "乾隆五十一年十一月二十九日",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "蚶江通判陳惇",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建省城",
          "quote": "十三日午刻，據蚶江通判陳惇稟稱",
          "to_person": "福建巡撫徐嗣曾",
          "whenAr": "1787/01/31",
          "whenCh": "乾隆五十一年十二月十三日午刻"
        },
        {
          "from_person": "舵工黃斌",
          "how": "口述",
          "inferred": false,
          "layer": 2,
          "place": "蚶江",
          "quote": "初十日酉時，民人紀長錦船只由鹿仔港來蚶進口，詢據舵工黃斌供稱",
          "to_person": "蚶江通判陳惇",
          "whenAr": "1787/01/28",
          "whenCh": "乾隆五十一年十二月初十日酉時"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "十一月二十九日在鹿仔港口內，聽得人說彰化縣城内被賊殺害各官",
            "reporter": "舵工黃斌",
            "subtitle": "賊匪攻陷彰化殺害官員",
            "whenCh": "乾隆五十一年十一月二十九日",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "蚶江通判陳惇",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建省城",
            "quote": "十三日午刻，據蚶江通判陳惇稟稱",
            "to_person": "福建巡撫徐嗣曾",
            "whenAr": "1787/01/31",
            "whenCh": "乾隆五十一年十二月十三日午刻"
          },
          {
            "from_person": "舵工黃斌",
            "how": "口述",
            "inferred": false,
            "layer": 2,
            "place": "蚶江",
            "quote": "初十日酉時，民人紀長錦船只由鹿仔港來蚶進口，詢據舵工黃斌供稱",
            "to_person": "蚶江通判陳惇",
            "whenAr": "1787/01/28",
            "whenCh": "乾隆五十一年十二月初十日酉時"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台24

```json
{
  "doc_id": "台24",
  "evTitle": "賊匪進攻諸羅縣城",
  "event": {
    "description": "賊匪前往諸羅縣攻打縣城，與官兵交戰，傳聞被官兵殺死二千餘人。",
    "howKnown": "轉述",
    "quote": "又聽人傳說，賊人赴諸羅縣攻城，被官兵殺死二千餘人。",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪進攻諸羅縣城",
    "whenAr": "1786/12",
    "whenCh": "十一月",
    "whenKnownCh": "十二月十三日",
    "where": "諸羅縣城",
    "who": [],
    "who_loc": {},
    "doc_id": "台24"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "又聽人傳說，賊人赴諸羅縣攻城，被官兵殺死二千餘人。",
          "reporter": "舵工黃斌",
          "subtitle": "賊匪進攻諸羅縣城",
          "whenCh": "十一月",
          "where": "諸羅縣城"
        }
      ],
      "hops": [
        {
          "from_person": "蚶江通判陳惇",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "省城",
          "quote": "十三日午刻，據蚶江通判陳惇稟稱，初十日酉時，民人紀長錦船只由鹿仔港來蚶進口，詢據舵工黃斌供稱：十一月二十九日在鹿仔港口內，聽得人說彰化縣城内被賊殺害各官，小的就將船開至口外躲避。又聽人傳說，賊人赴諸羅縣攻城，被官兵殺死二千餘人。等語。",
          "to_person": "福建巡撫徐嗣曾",
          "whenAr": "",
          "whenCh": "十二月十三日午刻"
        },
        {
          "from_person": "舵工黃斌",
          "how": "口述",
          "inferred": false,
          "layer": 2,
          "place": "蚶江",
          "quote": "詢據舵工黃斌供稱：十一月二十九日在鹿仔港口內...又聽人傳說，賊人赴諸羅縣攻城，被官兵殺死二千餘人。",
          "to_person": "蚶江通判陳惇",
          "whenAr": "",
          "whenCh": "十二月初十日酉時"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "又聽人傳說，賊人赴諸羅縣攻城，被官兵殺死二千餘人。",
            "reporter": "舵工黃斌",
            "subtitle": "賊匪進攻諸羅縣城",
            "whenCh": "十一月",
            "where": "諸羅縣城"
          }
        ],
        "hops": [
          {
            "from_person": "蚶江通判陳惇",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "省城",
            "quote": "十三日午刻，據蚶江通判陳惇稟稱，初十日酉時，民人紀長錦船只由鹿仔港來蚶進口，詢據舵工黃斌供稱：十一月二十九日在鹿仔港口內，聽得人說彰化縣城内被賊殺害各官，小的就將船開至口外躲避。又聽人傳說，賊人赴諸羅縣攻城，被官兵殺死二千餘人。等語。",
            "to_person": "福建巡撫徐嗣曾",
            "whenAr": "",
            "whenCh": "十二月十三日午刻"
          },
          {
            "from_person": "舵工黃斌",
            "how": "口述",
            "inferred": false,
            "layer": 2,
            "place": "蚶江",
            "quote": "詢據舵工黃斌供稱：十一月二十九日在鹿仔港口內...又聽人傳說，賊人赴諸羅縣攻城，被官兵殺死二千餘人。",
            "to_person": "蚶江通判陳惇",
            "whenAr": "",
            "whenCh": "十二月初十日酉時"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台26

```json
{
  "doc_id": "台26",
  "evTitle": "林爽文等結黨滋事",
  "event": {
    "description": "彰化縣匪徒林爽文等結黨四虐，擾害地方，文武官員擒捕未獲。",
    "howKnown": "轉述",
    "quote": "十一日初間，聞彰化縣匪徒林爽文等結黨四虐，擾害地方，文武官員擒捕未獲。",
    "relations": [],
    "side": "lin",
    "subtitle": "林爽文等結黨滋事",
    "whenAr": "1786/12/20",
    "whenCh": "十一月初間",
    "whenKnownCh": "十一月二十九日",
    "where": "彰化縣",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "彰化縣"
    },
    "doc_id": "台26"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "本年十一日初間，聞彰化縣匪徒林爽文等結黨四虐，擾害地方，文武官員擒捕未獲。",
          "reporter": "署臺灣府淡水同知程峻、竹塹營守備董得魁",
          "subtitle": "林爽文等結黨滋事",
          "whenCh": "十一日初間",
          "where": "彰化縣"
        }
      ],
      "hops": [
        {
          "from_person": "署臺灣府淡水同知程峻、竹塹營守備董得魁",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "十二日辰刻，接據署臺灣府淡水同知程峻、竹塹營守備董得魁稟稱...彰化已為匪徒竊據，通報內地文稟，不能由正口直達。適有商船飄泊淡港，隨即專差搭船馳稟。",
          "to_person": "福建巡撫徐嗣曾",
          "whenAr": "1787/01/30",
          "whenCh": "十二月十二日辰刻"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "本年十一日初間，聞彰化縣匪徒林爽文等結黨四虐，擾害地方，文武官員擒捕未獲。",
            "reporter": "署臺灣府淡水同知程峻、竹塹營守備董得魁",
            "subtitle": "林爽文等結黨滋事",
            "whenCh": "十一日初間",
            "where": "彰化縣"
          }
        ],
        "hops": [
          {
            "from_person": "署臺灣府淡水同知程峻、竹塹營守備董得魁",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "十二日辰刻，接據署臺灣府淡水同知程峻、竹塹營守備董得魁稟稱...彰化已為匪徒竊據，通報內地文稟，不能由正口直達。適有商船飄泊淡港，隨即專差搭船馳稟。",
            "to_person": "福建巡撫徐嗣曾",
            "whenAr": "1787/01/30",
            "whenCh": "十二月十二日辰刻"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台26

```json
{
  "doc_id": "台26",
  "evTitle": "大墩地方官員遇害",
  "event": {
    "description": "彰化縣知縣俞峻在大墩地方搜捕匪徒時，遭到林爽文等民變分子襲擊被害。",
    "howKnown": "轉述",
    "quote": "二十七夜，彰化縣俞知縣在大墩地方拿匪被害。",
    "relations": [
      {
        "evidence": "彰化縣俞知縣在大墩地方拿匪被害",
        "relation": "被害",
        "relation_type": "conflict",
        "source": "林爽文",
        "target": "俞峻"
      }
    ],
    "side": "lin",
    "subtitle": "大墩地方官員遇害",
    "whenAr": "1787/01/15",
    "whenCh": "十一月二十七日夜",
    "whenKnownCh": "十一月二十九日",
    "where": "大墩",
    "who": [
      "俞峻",
      "林爽文"
    ],
    "who_loc": {
      "俞峻": "大墩",
      "林爽文": "大墩"
    },
    "doc_id": "台26"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "二十七夜，彰化縣俞知縣在大墩地方拿匪被害。",
          "reporter": "彰化大肚社番",
          "subtitle": "大墩地方官員遇害",
          "whenCh": "十一月二十七日夜",
          "where": "大墩"
        }
      ],
      "hops": [
        {
          "from_person": "彰化大肚社番",
          "how": "寄字",
          "inferred": true,
          "layer": 3,
          "place": "大甲社",
          "quote": "彰化大肚社番寄字淡屬大甲社通事",
          "to_person": "淡屬大甲社通事",
          "whenAr": "",
          "whenCh": "十一月二十八日"
        },
        {
          "from_person": "淡屬大甲社通事",
          "how": "轉述",
          "inferred": false,
          "layer": 2,
          "place": "淡水",
          "quote": "十一月二十九日，據該番帶回原文，並有彰化大肚社番寄字淡屬大甲社通事據稱",
          "to_person": "署臺灣府淡水同知程峻、竹塹營守備董得魁",
          "whenAr": "1787/01/18",
          "whenCh": "十一月二十九日"
        },
        {
          "from_person": "署臺灣府淡水同知程峻、竹塹營守備董得魁",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "十二日辰刻，接據署臺灣府淡水同知程峻、竹塹營守備董得魁稟稱...隨即專差搭船馳稟",
          "to_person": "福建巡撫臣徐嗣曾",
          "whenAr": "1787/01/31",
          "whenCh": "十二月十二日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "二十七夜，彰化縣俞知縣在大墩地方拿匪被害。",
            "reporter": "彰化大肚社番",
            "subtitle": "大墩地方官員遇害",
            "whenCh": "十一月二十七日夜",
            "where": "大墩"
          }
        ],
        "hops": [
          {
            "from_person": "彰化大肚社番",
            "how": "寄字",
            "inferred": true,
            "layer": 3,
            "place": "大甲社",
            "quote": "彰化大肚社番寄字淡屬大甲社通事",
            "to_person": "淡屬大甲社通事",
            "whenAr": "",
            "whenCh": "十一月二十八日"
          },
          {
            "from_person": "淡屬大甲社通事",
            "how": "轉述",
            "inferred": false,
            "layer": 2,
            "place": "淡水",
            "quote": "十一月二十九日，據該番帶回原文，並有彰化大肚社番寄字淡屬大甲社通事據稱",
            "to_person": "署臺灣府淡水同知程峻、竹塹營守備董得魁",
            "whenAr": "1787/01/18",
            "whenCh": "十一月二十九日"
          },
          {
            "from_person": "署臺灣府淡水同知程峻、竹塹營守備董得魁",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "十二日辰刻，接據署臺灣府淡水同知程峻、竹塹營守備董得魁稟稱...隨即專差搭船馳稟",
            "to_person": "福建巡撫臣徐嗣曾",
            "whenAr": "1787/01/31",
            "whenCh": "十二月十二日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台26

```json
{
  "doc_id": "台26",
  "evTitle": "民變軍攻陷彰化城",
  "event": {
    "description": "林爽文等民變勢力於二十八日清晨攻陷彰化縣城，導致道路梗塞，交通中斷。",
    "howKnown": "轉述",
    "quote": "本日早彰城失陷，路途梗塞，不能前遞",
    "relations": [],
    "side": "lin",
    "subtitle": "民變軍攻陷彰化城",
    "whenAr": "1787/01/16",
    "whenCh": "十一月二十八日早",
    "whenKnownCh": "十一月二十九日",
    "where": "彰化城",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "彰化城"
    },
    "doc_id": "台26"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "二十七夜，彰化縣俞知縣在大墩地方拿匪被害。本日早彰城失陷，路途梗塞，不能前遞",
          "reporter": "彰化大肚社番",
          "subtitle": "民變軍攻陷彰化城",
          "whenCh": "乾隆五十一年十一月二十八日早",
          "where": "彰化城"
        }
      ],
      "hops": [
        {
          "from_person": "署臺灣府淡水同知程峻、竹塹營守備董得魁",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "十二日辰刻，接據署臺灣府淡水同知程峻、竹塹營守備董得魁稟稱",
          "to_person": "福建巡撫徐嗣曾",
          "whenAr": "1787/01/30",
          "whenCh": "乾隆五十一年十二月十二日辰刻"
        },
        {
          "from_person": "淡屬大甲社通事",
          "how": "轉述",
          "inferred": true,
          "layer": 2,
          "place": "淡水",
          "quote": "十一月二十九日，據該番帶回原文，並有彰化大肚社番寄字淡屬大甲社通事據稱",
          "to_person": "署臺灣府淡水同知程峻、竹塹營守備董得魁",
          "whenAr": "1787/01/17",
          "whenCh": "乾隆五十一年十一月二十九日"
        },
        {
          "from_person": "彰化大肚社番",
          "how": "寄字",
          "inferred": false,
          "layer": 3,
          "place": "大甲社",
          "quote": "彰化大肚社番寄字淡屬大甲社通事據稱",
          "to_person": "淡屬大甲社通事",
          "whenAr": "1787/01/16",
          "whenCh": "乾隆五十一年十一月二十八日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "二十七夜，彰化縣俞知縣在大墩地方拿匪被害。本日早彰城失陷，路途梗塞，不能前遞",
            "reporter": "彰化大肚社番",
            "subtitle": "民變軍攻陷彰化城",
            "whenCh": "乾隆五十一年十一月二十八日早",
            "where": "彰化城"
          }
        ],
        "hops": [
          {
            "from_person": "署臺灣府淡水同知程峻、竹塹營守備董得魁",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "十二日辰刻，接據署臺灣府淡水同知程峻、竹塹營守備董得魁稟稱",
            "to_person": "福建巡撫徐嗣曾",
            "whenAr": "1787/01/30",
            "whenCh": "乾隆五十一年十二月十二日辰刻"
          },
          {
            "from_person": "淡屬大甲社通事",
            "how": "轉述",
            "inferred": true,
            "layer": 2,
            "place": "淡水",
            "quote": "十一月二十九日，據該番帶回原文，並有彰化大肚社番寄字淡屬大甲社通事據稱",
            "to_person": "署臺灣府淡水同知程峻、竹塹營守備董得魁",
            "whenAr": "1787/01/17",
            "whenCh": "乾隆五十一年十一月二十九日"
          },
          {
            "from_person": "彰化大肚社番",
            "how": "寄字",
            "inferred": false,
            "layer": 3,
            "place": "大甲社",
            "quote": "彰化大肚社番寄字淡屬大甲社通事據稱",
            "to_person": "淡屬大甲社通事",
            "whenAr": "1787/01/16",
            "whenCh": "乾隆五十一年十一月二十八日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台25

```json
{
  "doc_id": "台25",
  "evTitle": "匪徒於大墩殺害官員",
  "event": {
    "description": "彰化縣匪徒在大墩地方聚集，於十一月二十-七日夜，將前來捕匪的官員「俞」（指彰化縣知縣俞峻）殺害。",
    "howKnown": "轉述",
    "quote": "本月二十七日夜，本縣俞在大墩地方拿匪被害。",
    "relations": [
      {
        "evidence": "本月二十七日夜，本縣俞在大墩地方拿匪被害",
        "relation": "殺害",
        "relation_type": "conflict",
        "source": "林爽文黨羽",
        "target": "俞"
      }
    ],
    "side": "lin",
    "subtitle": "匪徒於大墩殺害官員",
    "whenAr": "1787/01/15",
    "whenCh": "十一月二十七日夜",
    "whenKnownCh": "十二月初十日",
    "where": "大墩",
    "who": [
      "林爽文黨羽",
      "俞"
    ],
    "who_loc": {
      "俞": "大墩",
      "林爽文黨羽": "大墩"
    },
    "doc_id": "台25"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "本月二十七日夜，本縣俞在大墩地方拿匪被害。",
          "reporter": "彰邑大肚社番",
          "subtitle": "匪徒於大墩殺害官員",
          "whenCh": "乾隆五十一年十一月二十七日夜",
          "where": "大墩"
        }
      ],
      "hops": [
        {
          "from_person": "署北路淡水同知程峻、守備董得魁",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "廈門（登舟處）",
          "quote": "接據署北路淡水同知程峻、守備董得魁會稟稱...等情前來。",
          "to_person": "福建水師提督黃仕簡",
          "whenAr": "1787/01/28",
          "whenCh": "乾隆五十一年十二月初十日"
        },
        {
          "from_person": "淡屬大甲社通事",
          "how": "轉述",
          "inferred": true,
          "layer": 2,
          "place": "淡水",
          "quote": "彰邑大肚社番字寄淡屬大甲社通事據稱",
          "to_person": "署北路淡水同知程峻、守備董得魁",
          "whenAr": "1787/01/17",
          "whenCh": "乾隆五十一年十一月二十九日"
        },
        {
          "from_person": "彰邑大肚社番",
          "how": "字寄",
          "inferred": false,
          "layer": 3,
          "place": "大甲社",
          "quote": "十一月二十九日，彰邑大肚社番字寄淡屬大甲社通事據稱",
          "to_person": "淡屬大甲社通事",
          "whenAr": "1787/01/17",
          "whenCh": "乾隆五十一年十一月二十九日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "本月二十七日夜，本縣俞在大墩地方拿匪被害。",
            "reporter": "彰邑大肚社番",
            "subtitle": "匪徒於大墩殺害官員",
            "whenCh": "乾隆五十一年十一月二十七日夜",
            "where": "大墩"
          }
        ],
        "hops": [
          {
            "from_person": "署北路淡水同知程峻、守備董得魁",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "廈門（登舟處）",
            "quote": "接據署北路淡水同知程峻、守備董得魁會稟稱...等情前來。",
            "to_person": "福建水師提督黃仕簡",
            "whenAr": "1787/01/28",
            "whenCh": "乾隆五十一年十二月初十日"
          },
          {
            "from_person": "淡屬大甲社通事",
            "how": "轉述",
            "inferred": true,
            "layer": 2,
            "place": "淡水",
            "quote": "彰邑大肚社番字寄淡屬大甲社通事據稱",
            "to_person": "署北路淡水同知程峻、守備董得魁",
            "whenAr": "1787/01/17",
            "whenCh": "乾隆五十一年十一月二十九日"
          },
          {
            "from_person": "彰邑大肚社番",
            "how": "字寄",
            "inferred": false,
            "layer": 3,
            "place": "大甲社",
            "quote": "十一月二十九日，彰邑大肚社番字寄淡屬大甲社通事據稱",
            "to_person": "淡屬大甲社通事",
            "whenAr": "1787/01/17",
            "whenCh": "乾隆五十一年十一月二十九日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台25

```json
{
  "doc_id": "台25",
  "evTitle": "林爽文等攻陷彰化縣城",
  "event": {
    "description": "林爽文等聚集會黨，於十一月二十九日辰刻攻打彰化縣城，至午刻將城池攻陷，城內文武官員生死不明。",
    "howKnown": "訪聞",
    "quote": "於十一月二十九日辰刻，攻打彰化縣城。至午刻，縣城被陷，文武官員不知生死之事。",
    "relations": [
      {
        "evidence": "攻打彰化縣城。至午刻，縣城被陷，文武官員不知生死之事",
        "relation": "攻打",
        "relation_type": "conflict",
        "source": "林爽文",
        "target": "彰化縣文武官員"
      }
    ],
    "side": "lin",
    "subtitle": "林爽文等攻陷彰化縣城",
    "whenAr": "1787/01/17",
    "whenCh": "十一月二十九日",
    "whenKnownCh": "十二月初五日",
    "where": "彰化縣城",
    "who": [
      "林爽文",
      "彰化縣文武官員"
    ],
    "who_loc": {
      "彰化縣文武官員": "彰化縣城",
      "林爽文": "彰化縣城"
    },
    "doc_id": "台25"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "二十九早，彰城失陷",
          "reporter": "彰邑大肚社番",
          "subtitle": "林爽文等攻陷彰化縣城",
          "whenCh": "十一月二十九日",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "署北路淡水同知程峻、守備董得魁",
          "how": "會稟",
          "inferred": false,
          "layer": 1,
          "place": "廈門",
          "quote": "接據署北路淡水同知程峻、守備董得魁會稟稱...二十九早，彰城失陷...等情前來。",
          "to_person": "福建水師提督黃仕簡",
          "whenAr": "1787/01/28",
          "whenCh": "十二月初十日"
        },
        {
          "from_person": "淡屬大甲社通事",
          "how": "稟報",
          "inferred": true,
          "layer": 2,
          "place": "淡水",
          "quote": "淡屬大甲社通事據稱...二十九早，彰城失陷",
          "to_person": "署北路淡水同知程峻、守備董得魁",
          "whenAr": "",
          "whenCh": "十一月二十九日後"
        },
        {
          "from_person": "彰邑大肚社番",
          "how": "字寄",
          "inferred": false,
          "layer": 3,
          "place": "淡屬大甲社",
          "quote": "十一月二十九日，彰邑大肚社番字寄淡屬大甲社通事據稱",
          "to_person": "淡屬大甲社通事",
          "whenAr": "1787/01/17",
          "whenCh": "十一月二十九日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "二十九早，彰城失陷",
            "reporter": "彰邑大肚社番",
            "subtitle": "林爽文等攻陷彰化縣城",
            "whenCh": "十一月二十九日",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "署北路淡水同知程峻、守備董得魁",
            "how": "會稟",
            "inferred": false,
            "layer": 1,
            "place": "廈門",
            "quote": "接據署北路淡水同知程峻、守備董得魁會稟稱...二十九早，彰城失陷...等情前來。",
            "to_person": "福建水師提督黃仕簡",
            "whenAr": "1787/01/28",
            "whenCh": "十二月初十日"
          },
          {
            "from_person": "淡屬大甲社通事",
            "how": "稟報",
            "inferred": true,
            "layer": 2,
            "place": "淡水",
            "quote": "淡屬大甲社通事據稱...二十九早，彰城失陷",
            "to_person": "署北路淡水同知程峻、守備董得魁",
            "whenAr": "",
            "whenCh": "十一月二十九日後"
          },
          {
            "from_person": "彰邑大肚社番",
            "how": "字寄",
            "inferred": false,
            "layer": 3,
            "place": "淡屬大甲社",
            "quote": "十一月二十九日，彰邑大肚社番字寄淡屬大甲社通事據稱",
            "to_person": "淡屬大甲社通事",
            "whenAr": "1787/01/17",
            "whenCh": "十一月二十九日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台28

```json
{
  "doc_id": "台28",
  "evTitle": "臺匪糾眾滋事",
  "event": {
    "description": "臺灣地區的林爽文等民變勢力糾集群眾，發動起事，造成地方動亂。",
    "howKnown": "訪聞",
    "quote": "竊臣前聞臺匪糾眾滋事",
    "relations": [],
    "side": "lin",
    "subtitle": "臺匪糾眾滋事",
    "whenAr": "",
    "whenCh": "",
    "whenKnownCh": "十二月",
    "where": "臺灣",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "臺灣"
    },
    "doc_id": "台28"
  },
  "chains": [],
  "_raw": {
    "chains": [],
    "mode": "trace"
  }
}
```

## 台29

```json
{
  "doc_id": "台29",
  "evTitle": "叛軍夜襲大墩營盤",
  "event": {
    "description": "林爽文糾集數千人，於十一月二十七日夜間搶劫大墩營盤，致使清軍耿遊擊、赫副將等全軍覆沒。",
    "howKnown": "轉述",
    "quote": "詎該犯等，始則竄匿山邊，旋復糾約數千人，於十一月二十七夜搶劫大墩營盤，全軍俱陷。",
    "relations": [
      {
        "evidence": "於十一月二十七夜搶劫大墩營盤，全軍俱陷",
        "relation": "搶劫",
        "relation_type": "conflict",
        "source": "林爽文",
        "target": "耿遊擊"
      }
    ],
    "side": "lin",
    "subtitle": "叛軍夜襲大墩營盤",
    "whenAr": "1786/12/17",
    "whenCh": "十一月二十七日",
    "whenKnownCh": "十二月二十七日",
    "where": "大墩庄",
    "who": [
      "林爽文",
      "耿遊擊",
      "赫副將",
      "俞峻"
    ],
    "who_loc": {
      "俞峻": "大墩庄",
      "林爽文": "大墩庄",
      "耿遊擊": "大墩庄",
      "赫副將": "大墩庄"
    },
    "doc_id": "台29"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "詎該犯等，始則竄匿山邊，旋復糾約數千人，於十一月二十七夜搶劫大墩營盤，全軍俱陷。",
          "reporter": "北協中營千總帥挺、外委許瑪及目兵人等",
          "subtitle": "叛軍夜襲大墩營盤",
          "whenCh": "十一月二十七日夜",
          "where": "大墩庄"
        }
      ],
      "hops": [
        {
          "from_person": "署鹿仔港守備事千總陳邦光",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "茲於十二月二十七日亥刻，接得該署備陳邦光兩稟同時並到，內十二月十一日一稟據稱",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/02/14",
          "whenCh": "十二月二十七日亥刻"
        },
        {
          "from_person": "北協中營千總帥挺、外委許瑪及目兵人等",
          "how": "口述",
          "inferred": true,
          "layer": 2,
          "place": "鹿港",
          "quote": "邦光同鹿仔港泉、粵義民，并受傷來港之北協中營千總帥挺、外委許瑪及目兵人等，俱在鹿港會齊",
          "to_person": "署鹿仔港守備事千總陳邦光",
          "whenAr": "",
          "whenCh": "十一月二十七日後至十二月十一日前"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "詎該犯等，始則竄匿山邊，旋復糾約數千人，於十一月二十七夜搶劫大墩營盤，全軍俱陷。",
            "reporter": "北協中營千總帥挺、外委許瑪及目兵人等",
            "subtitle": "叛軍夜襲大墩營盤",
            "whenCh": "十一月二十七日夜",
            "where": "大墩庄"
          }
        ],
        "hops": [
          {
            "from_person": "署鹿仔港守備事千總陳邦光",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "茲於十二月二十七日亥刻，接得該署備陳邦光兩稟同時並到，內十二月十一日一稟據稱",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/02/14",
            "whenCh": "十二月二十七日亥刻"
          },
          {
            "from_person": "北協中營千總帥挺、外委許瑪及目兵人等",
            "how": "口述",
            "inferred": true,
            "layer": 2,
            "place": "鹿港",
            "quote": "邦光同鹿仔港泉、粵義民，并受傷來港之北協中營千總帥挺、外委許瑪及目兵人等，俱在鹿港會齊",
            "to_person": "署鹿仔港守備事千總陳邦光",
            "whenAr": "",
            "whenCh": "十一月二十七日後至十二月十一日前"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台29

```json
{
  "doc_id": "台29",
  "evTitle": "叛軍攻陷彰化縣城",
  "event": {
    "description": "叛軍於十一月二十九日攻入彰化縣城，殺害知府孫景燧、同知長庚、劉亨基、巡檢馮啟宗、都司王都司等官兵。",
    "howKnown": "轉述",
    "quote": "二十九日即劫彰化縣城，因存兵無多，被賊攻入，孫知府并理番同知長庚、前署彰化縣事俸滿臺防同知劉亨基、署典史事鹿港巡檢馮啟宗、北協中營王都司及弁兵數十人俱被殺害。",
    "relations": [
      {
        "evidence": "被賊攻入，孫知府并理番同知長庚、前署彰化縣事俸滿臺防同知劉亨基、署典史事鹿港巡檢馮啟宗、北協中營王都司及弁兵數十人俱被殺害",
        "relation": "殺害",
        "relation_type": "conflict",
        "source": "林爽文",
        "target": "孫知府"
      }
    ],
    "side": "lin",
    "subtitle": "叛軍攻陷彰化縣城",
    "whenAr": "1786/12/19",
    "whenCh": "十一月二十九日",
    "whenKnownCh": "十二月二十七日",
    "where": "彰化縣城",
    "who": [
      "林爽文",
      "孫知府",
      "長庚",
      "劉亨基",
      "馮啟宗",
      "王都司"
    ],
    "who_loc": {
      "劉亨基": "彰化縣城",
      "孫知府": "彰化縣城",
      "林爽文": "彰化縣城",
      "王都司": "彰化縣城",
      "長庚": "彰化縣城",
      "馮啟宗": "彰化縣城"
    },
    "doc_id": "台29"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "二十九日即劫彰化縣城，因存兵無多，被賊攻入，孫知府并理番同知長庚、前署彰化縣事俸滿臺防同知劉亨基、署典史事鹿港巡檢馮啟宗、北協中營王都司及弁兵數十人俱被殺害。",
          "reporter": "署鹿仔港守備事千總陳邦光",
          "subtitle": "叛軍攻陷彰化縣城",
          "whenCh": "十一月二十九日",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "署鹿仔港守備事千總陳邦光",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "鹿港",
          "quote": "接得該署備陳邦光兩稟同時並到，內十二月十一日一稟據稱：...二十九日即劫彰化縣城，因存兵無多，被賊攻入，孫知府并理番同知長庚、前署彰化縣事俸滿臺防同知劉亨基、署典史事鹿港巡檢馮啟宗、北協中營王都司及弁兵數十人俱被殺害。",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/01/29",
          "whenCh": "十二月十一日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "二十九日即劫彰化縣城，因存兵無多，被賊攻入，孫知府并理番同知長庚、前署彰化縣事俸滿臺防同知劉亨基、署典史事鹿港巡檢馮啟宗、北協中營王都司及弁兵數十人俱被殺害。",
            "reporter": "署鹿仔港守備事千總陳邦光",
            "subtitle": "叛軍攻陷彰化縣城",
            "whenCh": "十一月二十九日",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "署鹿仔港守備事千總陳邦光",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "鹿港",
            "quote": "接得該署備陳邦光兩稟同時並到，內十二月十一日一稟據稱：...二十九日即劫彰化縣城，因存兵無多，被賊攻入，孫知府并理番同知長庚、前署彰化縣事俸滿臺防同知劉亨基、署典史事鹿港巡檢馮啟宗、北協中營王都司及弁兵數十人俱被殺害。",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/01/29",
            "whenCh": "十二月十一日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台29

```json
{
  "doc_id": "台29",
  "evTitle": "分兵進攻鹿港淡水",
  "event": {
    "description": "叛軍攻陷彰化城後，進一步分兵攻擊鹿仔港，並分路進攻淡水等處。",
    "howKnown": "轉述",
    "quote": "復來攻擊鹿仔港，並分攻淡水諸邑。",
    "relations": [],
    "side": "lin",
    "subtitle": "分兵進攻鹿港淡水",
    "whenAr": "1786/12/19",
    "whenCh": "十一月二十九日後",
    "whenKnownCh": "十二月二十七日",
    "where": "鹿仔港",
    "who": [
      "林爽文"
    ],
    "who_loc": {},
    "doc_id": "台29"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "復來攻擊鹿仔港，並分攻淡水諸邑。",
          "reporter": "署鹿仔港守備事千總陳邦光",
          "subtitle": "分兵進攻鹿港淡水",
          "whenCh": "乾隆五十一年十一月二十九日後",
          "where": "鹿仔港、淡水"
        }
      ],
      "hops": [
        {
          "from_person": "署鹿仔港守備事千總陳邦光",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "鹿港至福建",
          "quote": "茲於十二月二十七日亥刻，接得該署備陳邦光兩稟同時並到，內十二月十一日一稟據稱：... 復來攻擊鹿仔港，並分攻淡水諸邑。",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/01/29-1787/02/14",
          "whenCh": "乾隆五十一年十二月十一日至十二月二十七日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "復來攻擊鹿仔港，並分攻淡水諸邑。",
            "reporter": "署鹿仔港守備事千總陳邦光",
            "subtitle": "分兵進攻鹿港淡水",
            "whenCh": "乾隆五十一年十一月二十九日後",
            "where": "鹿仔港、淡水"
          }
        ],
        "hops": [
          {
            "from_person": "署鹿仔港守備事千總陳邦光",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "鹿港至福建",
            "quote": "茲於十二月二十七日亥刻，接得該署備陳邦光兩稟同時並到，內十二月十一日一稟據稱：... 復來攻擊鹿仔港，並分攻淡水諸邑。",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/01/29-1787/02/14",
            "whenCh": "乾隆五十一年十二月十一日至十二月二十七日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台29

```json
{
  "doc_id": "台29",
  "evTitle": "咳咍庄賊匪謀攻鹿港",
  "event": {
    "description": "咳咍等庄叛軍企圖進攻鹿港，於大突、二林一帶遭遇守備陳邦光與義民伏擊，叛軍戰敗，其村庄被焚。",
    "howKnown": "轉述",
    "quote": "十八日據大突庄義民報稱，復有咳咍等庄賊匪謀攻鹿港，邦光傳令泉、粵義民乘夜以行，至大突二林地方預先埋伏，適遇賊匪衝鋒而來，隨令義民百餘誘敵，引至埋伏處所，兩頭夾攻，殺賊百餘名，焚燬咳咍、湳仔、內灣、二八水等賊庄。",
    "relations": [],
    "side": "lin",
    "subtitle": "咳咍庄賊匪謀攻鹿港",
    "whenAr": "1787/02/05",
    "whenCh": "十二月十八日",
    "whenKnownCh": "十二月二十七日",
    "where": "大突",
    "who": [],
    "who_loc": {},
    "doc_id": "台29"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "十八日據大突庄義民報稱，復有咳咍等庄賊匪謀攻鹿港，邦光傳令泉、粵義民乘夜以行，至大突二林地方預先埋伏，適遇賊匪衝鋒而來，隨令義民百餘誘敵，引至埋伏處所，兩頭夾攻，殺賊百餘名，焚燬咳咍、湳仔、內灣、二八水等賊庄。",
          "reporter": "大突庄義民",
          "subtitle": "咳咍庄賊匪謀攻鹿港",
          "whenCh": "乾隆五十一年十二月十八日",
          "where": "大突"
        }
      ],
      "hops": [
        {
          "from_person": "署鹿仔港守備事千總陳邦光",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建福州",
          "quote": "茲於十二月二十七日亥刻，接得該署備陳邦光兩稟同時並到……又，十二月二十一日一稟內稱",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/02/14",
          "whenCh": "乾隆五十一年十二月二十七日亥刻"
        },
        {
          "from_person": "大突庄義民",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "臺灣鹿港",
          "quote": "十八日據大突庄義民報稱，復有咳咍等庄賊匪謀攻鹿港",
          "to_person": "署鹿仔港守備事千總陳邦光",
          "whenAr": "1787/02/05",
          "whenCh": "乾隆五十一年十二月十八日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "十八日據大突庄義民報稱，復有咳咍等庄賊匪謀攻鹿港，邦光傳令泉、粵義民乘夜以行，至大突二林地方預先埋伏，適遇賊匪衝鋒而來，隨令義民百餘誘敵，引至埋伏處所，兩頭夾攻，殺賊百餘名，焚燬咳咍、湳仔、內灣、二八水等賊庄。",
            "reporter": "大突庄義民",
            "subtitle": "咳咍庄賊匪謀攻鹿港",
            "whenCh": "乾隆五十一年十二月十八日",
            "where": "大突"
          }
        ],
        "hops": [
          {
            "from_person": "署鹿仔港守備事千總陳邦光",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建福州",
            "quote": "茲於十二月二十七日亥刻，接得該署備陳邦光兩稟同時並到……又，十二月二十一日一稟內稱",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/02/14",
            "whenCh": "乾隆五十一年十二月二十七日亥刻"
          },
          {
            "from_person": "大突庄義民",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "臺灣鹿港",
            "quote": "十八日據大突庄義民報稱，復有咳咍等庄賊匪謀攻鹿港",
            "to_person": "署鹿仔港守備事千總陳邦光",
            "whenAr": "1787/02/05",
            "whenCh": "乾隆五十一年十二月十八日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台29

```json
{
  "doc_id": "台29",
  "evTitle": "大肚賊匪焚劫泉粵庄",
  "event": {
    "description": "大肚等庄叛軍焚燒搶劫泉、粵各庄，後遭牛罵頭義民與陳邦光夾擊，退守烏日庄。",
    "howKnown": "轉述",
    "quote": "十九日早，又據牛罵頭義民報稱，大肚等庄賊匪焚劫泉、粵各庄，邦光遂密約牛罵頭等庄義民，於二十日辰刻由沙轆進攻水裡、大肚、茄投等賊巢，並率義民襲後，追逐至猫霧捒，賊匪退踞烏日庄",
    "relations": [],
    "side": "lin",
    "subtitle": "大肚賊匪焚劫泉粵庄",
    "whenAr": "1787/02/06",
    "whenCh": "十二月十九日",
    "whenKnownCh": "十二月二十七日",
    "where": "大肚",
    "who": [],
    "who_loc": {},
    "doc_id": "台29"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "大肚等庄賊匪焚劫泉、粵各庄",
          "reporter": "牛罵頭義民",
          "subtitle": "大肚賊匪焚劫泉粵庄",
          "whenCh": "十二月十九日",
          "where": "大肚等庄"
        }
      ],
      "hops": [
        {
          "from_person": "陳邦光",
          "how": "稟報",
          "inferred": true,
          "layer": 1,
          "place": "泉州",
          "quote": "茲於十二月二十七日亥刻，接得該署備陳邦光兩稟同時並到……又，十二月二十一日一稟內稱",
          "to_person": "常青",
          "whenAr": "1787/02/08",
          "whenCh": "十二月二十一日至十二月二十七日"
        },
        {
          "from_person": "牛罵頭義民",
          "how": "報稱",
          "inferred": true,
          "layer": 2,
          "place": "鹿港",
          "quote": "十九日早，又據牛罵頭義民報稱，大肚等庄賊匪焚劫泉、粵各庄",
          "to_person": "陳邦光",
          "whenAr": "1787/02/06",
          "whenCh": "十二月十九日早"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "大肚等庄賊匪焚劫泉、粵各庄",
            "reporter": "牛罵頭義民",
            "subtitle": "大肚賊匪焚劫泉粵庄",
            "whenCh": "十二月十九日",
            "where": "大肚等庄"
          }
        ],
        "hops": [
          {
            "from_person": "陳邦光",
            "how": "稟報",
            "inferred": true,
            "layer": 1,
            "place": "泉州",
            "quote": "茲於十二月二十七日亥刻，接得該署備陳邦光兩稟同時並到……又，十二月二十一日一稟內稱",
            "to_person": "常青",
            "whenAr": "1787/02/08",
            "whenCh": "十二月二十一日至十二月二十七日"
          },
          {
            "from_person": "牛罵頭義民",
            "how": "報稱",
            "inferred": true,
            "layer": 2,
            "place": "鹿港",
            "quote": "十九日早，又據牛罵頭義民報稱，大肚等庄賊匪焚劫泉、粵各庄",
            "to_person": "陳邦光",
            "whenAr": "1787/02/06",
            "whenCh": "十二月十九日早"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台29

```json
{
  "doc_id": "台29",
  "evTitle": "彰化西門外迎戰義民",
  "event": {
    "description": "守備陳邦光率義民抵達彰化，叛軍出西門外駐劄並施放鎗砲迎戰，結果大敗，偽官楊振國、高文麟等四人被擒。",
    "howKnown": "轉述",
    "quote": "十二日午刻，率同各義民從鹿港抵彰，賊匪聞知，隨出西門外駐劄，各執器械，并用劫搶彰城營汛之鎗炮施放。邦光令義民分為兩隊上前攻殺，賊人退走，不能相顧，當即擒獲執旗之偽副元帥楊振國、偽協鎮高文麟、偽先鋒陳高、偽辦理水師軍務楊軒等四名",
    "relations": [
      {
        "evidence": "當即擒獲執旗之偽副元帥楊振國",
        "relation": "擒獲",
        "relation_type": "conflict",
        "source": "陳邦光",
        "target": "楊振國"
      }
    ],
    "side": "lin",
    "subtitle": "彰化西門外迎戰義民",
    "whenAr": "1787/01/30",
    "whenCh": "十二月十二日",
    "whenKnownCh": "十二月二十八日",
    "where": "彰化城西門外",
    "who": [
      "楊振國",
      "高文麟",
      "陳高",
      "楊軒",
      "陳邦光"
    ],
    "who_loc": {
      "楊振國": "彰化城",
      "楊軒": "彰化城",
      "陳邦光": "彰化城",
      "陳高": "彰化城",
      "高文麟": "彰化城"
    },
    "doc_id": "台29"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "十二日午刻，率同各義民從鹿港抵彰，賊匪聞知，隨出西門外駐劄，各執器械，并用劫搶彰城營汛之鎗炮施放。邦光令義民分為兩隊上前攻殺，賊人退走，不能相顧，當即擒獲執旗之偽副元帥楊振國、偽協鎮高文麟、偽先鋒陳高、偽辦理水師軍務楊軒等四名",
          "reporter": "署鹿仔港守備陳邦光",
          "subtitle": "彰化西門外迎戰義民",
          "whenCh": "十二月十二日",
          "where": "彰化城西門外"
        }
      ],
      "hops": [
        {
          "from_person": "署鹿仔港守備陳邦光",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "自鹿港至福建",
          "quote": "復於二十八日接據該署備十四日來稟内稱",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/02/01-1787/02/15",
          "whenCh": "十二月十四日至十二月二十八日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "十二日午刻，率同各義民從鹿港抵彰，賊匪聞知，隨出西門外駐劄，各執器械，并用劫搶彰城營汛之鎗炮施放。邦光令義民分為兩隊上前攻殺，賊人退走，不能相顧，當即擒獲執旗之偽副元帥楊振國、偽協鎮高文麟、偽先鋒陳高、偽辦理水師軍務楊軒等四名",
            "reporter": "署鹿仔港守備陳邦光",
            "subtitle": "彰化西門外迎戰義民",
            "whenCh": "十二月十二日",
            "where": "彰化城西門外"
          }
        ],
        "hops": [
          {
            "from_person": "署鹿仔港守備陳邦光",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "自鹿港至福建",
            "quote": "復於二十八日接據該署備十四日來稟内稱",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/02/01-1787/02/15",
            "whenCh": "十二月十四日至十二月二十八日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台29

```json
{
  "doc_id": "台29",
  "evTitle": "陳泮吳領焚庄後退守",
  "event": {
    "description": "林爽文黨羽陳泮、吳領等燒燬泉、粵民庄，遭義民追捕後，退歸南、北投。",
    "howKnown": "轉述",
    "quote": "二十三日林爽文黨羽陳泮、吳領等燒燬泉、粵民庄隨率義民前往追捕，殺死賊夥三十餘名...賊人退歸南、北投而去。",
    "relations": [],
    "side": "lin",
    "subtitle": "陳泮吳領焚庄後退守",
    "whenAr": "1787/02/10",
    "whenCh": "十二月二十三日",
    "whenKnownCh": "十二月二十八日",
    "where": "泉、粵民庄",
    "who": [
      "陳泮",
      "吳領"
    ],
    "who_loc": {
      "吳領": "南北投",
      "陳泮": "南北投"
    },
    "doc_id": "台29"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "二十三日林爽文黨羽陳泮、吳領等燒燬泉、粵民庄隨率義民前往追捕，殺死賊夥三十餘名，十獲紅旗四枝、器械四十餘件，併力追趕，賊人退歸南、北投而去。",
          "reporter": "陳邦光",
          "subtitle": "陳泮吳領焚庄後退守",
          "whenCh": "十二月二十三日",
          "where": "泉、粵民庄"
        }
      ],
      "hops": [
        {
          "from_person": "陳邦光",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福州",
          "quote": "茲於十二月二十七日亥刻，接得該署備陳邦光兩稟同時並到...又，續據該署備二十四日來稟內稱",
          "to_person": "常青",
          "whenAr": "1787/02/14",
          "whenCh": "十二月二十七日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "二十三日林爽文黨羽陳泮、吳領等燒燬泉、粵民庄隨率義民前往追捕，殺死賊夥三十餘名，十獲紅旗四枝、器械四十餘件，併力追趕，賊人退歸南、北投而去。",
            "reporter": "陳邦光",
            "subtitle": "陳泮吳領焚庄後退守",
            "whenCh": "十二月二十三日",
            "where": "泉、粵民庄"
          }
        ],
        "hops": [
          {
            "from_person": "陳邦光",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福州",
            "quote": "茲於十二月二十七日亥刻，接得該署備陳邦光兩稟同時並到...又，續據該署備二十四日來稟內稱",
            "to_person": "常青",
            "whenAr": "1787/02/14",
            "whenCh": "十二月二十七日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台27

```json
{
  "doc_id": "台27",
  "evTitle": "林爽文結黨攻陷彰化",
  "event": {
    "description": "彰化匪徒林爽文結黨騷擾地方，殺害清廷官長，並攻陷彰化城池。",
    "howKnown": "轉述",
    "quote": "彰化匪徒林爽文結黨騷擾、殺害官長、攻陷城池",
    "relations": [
      {
        "evidence": "殺害官長",
        "relation": "殺害",
        "relation_type": "conflict",
        "source": "林爽文",
        "target": "官長"
      }
    ],
    "side": "lin",
    "subtitle": "林爽文結黨攻陷彰化",
    "whenAr": "",
    "whenCh": "",
    "whenKnownCh": "",
    "where": "彰化",
    "who": [
      "林爽文",
      "官長"
    ],
    "who_loc": {
      "官長": "彰化",
      "林爽文": "彰化"
    },
    "doc_id": "台27"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "彰化匪徒林爽文結黨騷擾、殺害官長、攻陷城池",
          "reporter": "淡防廳",
          "subtitle": "林爽文結黨攻陷彰化",
          "whenCh": "乾隆五十一年",
          "where": "彰化"
        }
      ],
      "hops": [
        {
          "from_person": "浙閩督臣常青",
          "how": "咨會",
          "inferred": false,
          "layer": 1,
          "place": "江南",
          "quote": "接准浙閩督臣常青來咯",
          "to_person": "兩江總督臣李世傑",
          "whenAr": "",
          "whenCh": "乾隆五十一年十二月"
        },
        {
          "from_person": "淡防廳",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "福建",
          "quote": "據淡防廳稟稱",
          "to_person": "浙閩督臣常青",
          "whenAr": "",
          "whenCh": "乾隆五十一年十二月"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "彰化匪徒林爽文結黨騷擾、殺害官長、攻陷城池",
            "reporter": "淡防廳",
            "subtitle": "林爽文結黨攻陷彰化",
            "whenCh": "乾隆五十一年",
            "where": "彰化"
          }
        ],
        "hops": [
          {
            "from_person": "浙閩督臣常青",
            "how": "咨會",
            "inferred": false,
            "layer": 1,
            "place": "江南",
            "quote": "接准浙閩督臣常青來咯",
            "to_person": "兩江總督臣李世傑",
            "whenAr": "",
            "whenCh": "乾隆五十一年十二月"
          },
          {
            "from_person": "淡防廳",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "福建",
            "quote": "據淡防廳稟稱",
            "to_person": "浙閩督臣常青",
            "whenAr": "",
            "whenCh": "乾隆五十一年十二月"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台31

```json
{
  "doc_id": "台31",
  "evTitle": "賊匪攻陷彰化縣城",
  "event": {
    "description": "林爽文起事賊匪攻陷彰化縣城，殺害駐城官員，並阻絕往來文書傳報。",
    "howKnown": "轉述",
    "quote": "彰化縣城被賊匪攻陷，殺害官員，阻絕文報。",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪攻陷彰化縣城",
    "whenAr": "1787/01/16",
    "whenCh": "十一月二十七日",
    "whenKnownCh": "十二月初九日",
    "where": "彰化縣城",
    "who": [
      "賊匪"
    ],
    "who_loc": {
      "賊匪": "彰化縣城"
    },
    "doc_id": "台31"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "彰化縣城被賊匪攻陷，殺害官員，阻絕文報。",
          "reporter": "程峻、董得魁",
          "subtitle": "賊匪攻陷彰化縣城",
          "whenCh": "十一月二十七日",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "程峻、董得魁",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "十二月初九日，奴才接據臺灣淡防同知程峻、竹塹營守備董得魁稟報：彰化縣城被賊匪攻陷，殺害官員，阻絕文報。",
          "to_person": "任承恩",
          "whenAr": "1787/01/27",
          "whenCh": "十二月初九日"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "彰化地方已被賊踞",
          "reporter": "程必大",
          "subtitle": "賊匪攻陷彰化縣城",
          "whenCh": "十一月二十七日",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "程必大",
          "how": "口述",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "茲于十二日有該廳程峻之子程必大，奔赴奴才轅門求見...據程必大供：...又因彰化地方已被賊踞，不能前往府城",
          "to_person": "任承恩",
          "whenAr": "1787/01/30",
          "whenCh": "十二月十二日"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "彰化地方已被賊踞",
          "reporter": "虞文光",
          "subtitle": "賊匪攻陷彰化縣城",
          "whenCh": "十一月二十七日",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "虞文光",
          "how": "口述",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "問據外委虞文光供：...彰化地方已被賊踞，不得往府求救。",
          "to_person": "任承恩",
          "whenAr": "1787/01/30",
          "whenCh": "十二月十二日"
        },
        {
          "from_person": "董得魁",
          "how": "口述",
          "inferred": false,
          "layer": 2,
          "place": "中港",
          "quote": "董守備不及寫稟，面諭外委隨帶步兵王元浩搭船到泉求救。",
          "to_person": "虞文光",
          "whenAr": "1787/01/25",
          "whenCh": "十二月初七日"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "彰化地方已被賊踞",
          "reporter": "王元浩",
          "subtitle": "賊匪攻陷彰化縣城",
          "whenCh": "十一月二十七日",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "王元浩",
          "how": "口述",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "又問據兵丁王元浩供同。",
          "to_person": "任承恩",
          "whenAr": "1787/01/30",
          "whenCh": "十二月十二日"
        },
        {
          "from_person": "董得魁",
          "how": "口述",
          "inferred": false,
          "layer": 2,
          "place": "中港",
          "quote": "董守備不及寫稟，面諭外委隨帶步兵王元浩搭船到泉求救。",
          "to_person": "王元浩",
          "whenAr": "1787/01/25",
          "whenCh": "十二月初七日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "彰化縣城被賊匪攻陷，殺害官員，阻絕文報。",
            "reporter": "程峻、董得魁",
            "subtitle": "賊匪攻陷彰化縣城",
            "whenCh": "十一月二十七日",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "程峻、董得魁",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "十二月初九日，奴才接據臺灣淡防同知程峻、竹塹營守備董得魁稟報：彰化縣城被賊匪攻陷，殺害官員，阻絕文報。",
            "to_person": "任承恩",
            "whenAr": "1787/01/27",
            "whenCh": "十二月初九日"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "彰化地方已被賊踞",
            "reporter": "程必大",
            "subtitle": "賊匪攻陷彰化縣城",
            "whenCh": "十一月二十七日",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "程必大",
            "how": "口述",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "茲于十二日有該廳程峻之子程必大，奔赴奴才轅門求見...據程必大供：...又因彰化地方已被賊踞，不能前往府城",
            "to_person": "任承恩",
            "whenAr": "1787/01/30",
            "whenCh": "十二月十二日"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "彰化地方已被賊踞",
            "reporter": "虞文光",
            "subtitle": "賊匪攻陷彰化縣城",
            "whenCh": "十一月二十七日",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "虞文光",
            "how": "口述",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "問據外委虞文光供：...彰化地方已被賊踞，不得往府求救。",
            "to_person": "任承恩",
            "whenAr": "1787/01/30",
            "whenCh": "十二月十二日"
          },
          {
            "from_person": "董得魁",
            "how": "口述",
            "inferred": false,
            "layer": 2,
            "place": "中港",
            "quote": "董守備不及寫稟，面諭外委隨帶步兵王元浩搭船到泉求救。",
            "to_person": "虞文光",
            "whenAr": "1787/01/25",
            "whenCh": "十二月初七日"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "彰化地方已被賊踞",
            "reporter": "王元浩",
            "subtitle": "賊匪攻陷彰化縣城",
            "whenCh": "十一月二十七日",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "王元浩",
            "how": "口述",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "又問據兵丁王元浩供同。",
            "to_person": "任承恩",
            "whenAr": "1787/01/30",
            "whenCh": "十二月十二日"
          },
          {
            "from_person": "董得魁",
            "how": "口述",
            "inferred": false,
            "layer": 2,
            "place": "中港",
            "quote": "董守備不及寫稟，面諭外委隨帶步兵王元浩搭船到泉求救。",
            "to_person": "王元浩",
            "whenAr": "1787/01/25",
            "whenCh": "十二月初七日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台31

```json
{
  "doc_id": "台31",
  "evTitle": "賊匪於中港擊潰官兵",
  "event": {
    "description": "賊匪與前來堵禦的淡水同知程峻、守備董得魁所率兵役鄉勇在中港交戰。因賊匪人數眾多，官兵抵敵不住而潰散。",
    "howKnown": "轉述",
    "quote": "我父親會同董守備帶領兵役鄉勇，前赴中港地方堵禦。賊匪眾多，抵敵不住",
    "relations": [
      {
        "evidence": "賊匪眾多，抵敵不住",
        "relation": "抵敵不住",
        "relation_type": "conflict",
        "source": "賊匪",
        "target": "程峻"
      },
      {
        "evidence": "賊匪眾多，抵敵不住",
        "relation": "抵敵不住",
        "relation_type": "conflict",
        "source": "賊匪",
        "target": "董得魁"
      }
    ],
    "side": "lin",
    "subtitle": "賊匪於中港擊潰官兵",
    "whenAr": "",
    "whenCh": "十二月初七日前",
    "whenKnownCh": "十二月十二日",
    "where": "中港",
    "who": [
      "賊匪",
      "程峻",
      "董得魁"
    ],
    "who_loc": {
      "程峻": "中港",
      "董得魁": "中港",
      "賊匪": "中港"
    },
    "doc_id": "台31"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "我父親會同董守備帶領兵役鄉勇，前赴中港地方堵禦。賊匪眾多，抵敵不住",
          "reporter": "程必大",
          "subtitle": "賊匪於中港擊潰官兵",
          "whenCh": "十二月初七日前",
          "where": "中港"
        }
      ],
      "hops": [
        {
          "from_person": "程必大",
          "how": "口述",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "茲于十二日有該廳程峻之子程必大，奔赴奴才轅門求見，奴才立即傳進。據程必大懷取淡防同知關防，請求救援。...據程必大供：我父親程峻，現署淡水同知，駐紮竹塹。因彰化賊匪滋事，我父親會同董守備帶領兵役鄉勇，前赴中港地方堵禦。賊匪眾多，抵敵不住",
          "to_person": "任承恩",
          "whenAr": "1787/01/30",
          "whenCh": "十二月十二日"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "連日隨同守備董得魁會同程廳官帶兵在中港地方堵禦賊匪。到本月初七日，不料賊匪漸多，兵少不敵",
          "reporter": "虞文光、王元浩",
          "subtitle": "賊匪於中港擊潰官兵",
          "whenCh": "十二月初七日",
          "where": "中港"
        }
      ],
      "hops": [
        {
          "from_person": "虞文光、王元浩",
          "how": "口述",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "外委虞文光、兵丁王元浩，亦先後投到求救。...問據外委虞文光供：外委係現任臺灣北路竹塹營外委，連日隨同守備董得魁會同程廳官帶兵在中港地方堵禦賊匪。到本月初七日，不料賊匪漸多，兵少不敵",
          "to_person": "任承恩",
          "whenAr": "1787/01/30",
          "whenCh": "十二月十二日"
        },
        {
          "from_person": "董得魁",
          "how": "口述",
          "inferred": false,
          "layer": 2,
          "place": "中港",
          "quote": "董守備不及寫稟，面諭外委隨帶步兵王元浩搭船到泉求救。",
          "to_person": "虞文光、王元浩",
          "whenAr": "1787/01/25",
          "whenCh": "十二月初七日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "我父親會同董守備帶領兵役鄉勇，前赴中港地方堵禦。賊匪眾多，抵敵不住",
            "reporter": "程必大",
            "subtitle": "賊匪於中港擊潰官兵",
            "whenCh": "十二月初七日前",
            "where": "中港"
          }
        ],
        "hops": [
          {
            "from_person": "程必大",
            "how": "口述",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "茲于十二日有該廳程峻之子程必大，奔赴奴才轅門求見，奴才立即傳進。據程必大懷取淡防同知關防，請求救援。...據程必大供：我父親程峻，現署淡水同知，駐紮竹塹。因彰化賊匪滋事，我父親會同董守備帶領兵役鄉勇，前赴中港地方堵禦。賊匪眾多，抵敵不住",
            "to_person": "任承恩",
            "whenAr": "1787/01/30",
            "whenCh": "十二月十二日"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "連日隨同守備董得魁會同程廳官帶兵在中港地方堵禦賊匪。到本月初七日，不料賊匪漸多，兵少不敵",
            "reporter": "虞文光、王元浩",
            "subtitle": "賊匪於中港擊潰官兵",
            "whenCh": "十二月初七日",
            "where": "中港"
          }
        ],
        "hops": [
          {
            "from_person": "虞文光、王元浩",
            "how": "口述",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "外委虞文光、兵丁王元浩，亦先後投到求救。...問據外委虞文光供：外委係現任臺灣北路竹塹營外委，連日隨同守備董得魁會同程廳官帶兵在中港地方堵禦賊匪。到本月初七日，不料賊匪漸多，兵少不敵",
            "to_person": "任承恩",
            "whenAr": "1787/01/30",
            "whenCh": "十二月十二日"
          },
          {
            "from_person": "董得魁",
            "how": "口述",
            "inferred": false,
            "layer": 2,
            "place": "中港",
            "quote": "董守備不及寫稟，面諭外委隨帶步兵王元浩搭船到泉求救。",
            "to_person": "虞文光、王元浩",
            "whenAr": "1787/01/25",
            "whenCh": "十二月初七日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台31

```json
{
  "doc_id": "台31",
  "evTitle": "賊匪攻佔竹塹四處擄搶",
  "event": {
    "description": "賊匪於十二月初七日攻抵竹塹，並在當地四處擄掠搶奪，迫使淡水同知之子程必大攜印改裝逃往八里坌內渡求救。",
    "howKnown": "轉述",
    "quote": "賊匪於十二月初七日已到竹塹，四行擄搶。",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪攻佔竹塹四處擄搶",
    "whenAr": "1787/01/25",
    "whenCh": "十二月初七日",
    "whenKnownCh": "十二月十二日",
    "where": "竹塹",
    "who": [
      "賊匪"
    ],
    "who_loc": {
      "賊匪": "竹塹"
    },
    "doc_id": "台31"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "賊匪於十二月初七日已到竹塹，四行擄搶。",
          "reporter": "程必大",
          "subtitle": "賊匪攻佔竹塹四處擄搶",
          "whenCh": "十二月初七日",
          "where": "竹塹"
        }
      ],
      "hops": [
        {
          "from_person": "程必大",
          "how": "口述",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "茲于十二日有該廳程峻之子程必大，奔赴奴才轅門求見，奴才立即傳進。... 據程必大供：... 賊匪於十二月初七日已到竹塹，四行擄搶。",
          "to_person": "任承恩",
          "whenAr": "1787/01/30",
          "whenCh": "十二月十二日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "賊匪於十二月初七日已到竹塹，四行擄搶。",
            "reporter": "程必大",
            "subtitle": "賊匪攻佔竹塹四處擄搶",
            "whenCh": "十二月初七日",
            "where": "竹塹"
          }
        ],
        "hops": [
          {
            "from_person": "程必大",
            "how": "口述",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "茲于十二日有該廳程峻之子程必大，奔赴奴才轅門求見，奴才立即傳進。... 據程必大供：... 賊匪於十二月初七日已到竹塹，四行擄搶。",
            "to_person": "任承恩",
            "whenAr": "1787/01/30",
            "whenCh": "十二月十二日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台35

```json
{
  "doc_id": "台35",
  "evTitle": "匪徒攻陷彰化縣城",
  "event": {
    "description": "叛軍於十一月二十七日夜間攔路截殺彰化知縣俞峻、北協副將赫生額及臺鎮中營遊擊耿世文，隨後攻破並佔領彰化縣城。",
    "howKnown": "探報",
    "quote": "探得十一月二十七夜，彰化俞知縣同北協赫副將、臺鎮中營耿遊擊，被匪徒攔路截殺，攻破彰化縣，踞住城池。",
    "relations": [
      {
        "evidence": "彰化俞知縣同北協赫副將、臺鎮中營耿遊擊，被匪徒攔路截殺",
        "relation": "攔路截殺",
        "relation_type": "conflict",
        "source": "匪徒",
        "target": "俞知縣"
      },
      {
        "evidence": "彰化俞知縣同北協赫副將、臺鎮中營耿遊擊，被匪徒攔路截殺",
        "relation": "攔路截殺",
        "relation_type": "conflict",
        "source": "匪徒",
        "target": "赫副將"
      },
      {
        "evidence": "彰化俞知縣同北協赫副將、臺鎮中營耿遊擊，被匪徒攔路截殺",
        "relation": "攔路截殺",
        "relation_type": "conflict",
        "source": "匪徒",
        "target": "耿遊擊"
      }
    ],
    "side": "lin",
    "subtitle": "匪徒攻陷彰化縣城",
    "whenAr": "1787/01/16",
    "whenCh": "十一月二十七日夜",
    "whenKnownCh": "十二月十四日",
    "where": "彰化縣",
    "who": [
      "匪徒",
      "俞知縣",
      "赫副將",
      "耿遊擊"
    ],
    "who_loc": {
      "俞知縣": "彰化縣",
      "匪徒": "彰化縣",
      "耿遊擊": "彰化縣",
      "赫副將": "彰化縣"
    },
    "doc_id": "台35"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "探得十一月二十七夜，彰化俞知縣同北協赫副將、臺鎮中營耿遊擊，被匪徒攔路截殺，攻破彰化縣，踞住城池。",
          "reporter": "守備林登雲",
          "subtitle": "匪徒攻陷彰化縣城",
          "whenCh": "十一月二十七日夜",
          "where": "彰化縣"
        }
      ],
      "hops": [
        {
          "from_person": "守備林登雲",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "接據臣差往探信之守備林登雲稟報：探得十一月二十七夜，彰化俞知縣同北協赫副將、臺鎮中營耿遊擊，被匪徒攔路截殺，攻破彰化縣，踞住城池。",
          "to_person": "閩浙總督常青",
          "whenAr": "",
          "whenCh": "十二月"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "探得十一月二十七夜，彰化俞知縣同北協赫副將、臺鎮中營耿遊擊，被匪徒攔路截殺，攻破彰化縣，踞住城池。",
            "reporter": "守備林登雲",
            "subtitle": "匪徒攻陷彰化縣城",
            "whenCh": "十一月二十七日夜",
            "where": "彰化縣"
          }
        ],
        "hops": [
          {
            "from_person": "守備林登雲",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "接據臣差往探信之守備林登雲稟報：探得十一月二十七夜，彰化俞知縣同北協赫副將、臺鎮中營耿遊擊，被匪徒攔路截殺，攻破彰化縣，踞住城池。",
            "to_person": "閩浙總督常青",
            "whenAr": "",
            "whenCh": "十二月"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台35

```json
{
  "doc_id": "台35",
  "evTitle": "中港擊散官兵",
  "event": {
    "description": "叛軍於十二月初七日在中港地方與前來堵禦的淡水同知程峻、守備董得魁等官兵及鄉勇交戰，因人數眾多將官兵擊散。",
    "howKnown": "探報",
    "quote": "又聞得竹塹程同知、董守備，帶兵並鄉勇往中港堵禦，於本月初七日亦被賊殺散。",
    "relations": [
      {
        "evidence": "程同知、董守備，帶兵並鄉勇往中港堵禦，於本月初七日亦被賊殺散",
        "relation": "擊散",
        "relation_type": "conflict",
        "source": "賊匪",
        "target": "程峻"
      },
      {
        "evidence": "程同知、董守備，帶兵並鄉勇往中港堵禦，於本月初七日亦被賊殺散",
        "relation": "擊散",
        "relation_type": "conflict",
        "source": "賊匪",
        "target": "董得魁"
      }
    ],
    "side": "lin",
    "subtitle": "中港擊散官兵",
    "whenAr": "1787/01/25",
    "whenCh": "十二月初七日",
    "whenKnownCh": "十二月十四日",
    "where": "中港",
    "who": [
      "賊匪",
      "程峻",
      "董得魁"
    ],
    "who_loc": {
      "程峻": "中港",
      "董得魁": "中港",
      "賊匪": "中港"
    },
    "doc_id": "台35"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "又聞得竹塹程同知、董守備，帶兵並鄉勇往中港堵禦，於本月初七日亦被賊殺散。",
          "reporter": "守備林登雲",
          "subtitle": "中港擊散官兵",
          "whenCh": "乾隆五十一年十二月初七日",
          "where": "中港"
        }
      ],
      "hops": [
        {
          "from_person": "守備林登雲",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "泉州",
          "quote": "又接據臣差往探信之守備林登雲稟報：...又聞得竹塹程同知、董守備，帶兵並鄉勇往中港堵禦，於本月初七日亦被賊殺散。等語。",
          "to_person": "閩浙總督常青",
          "whenAr": "",
          "whenCh": "乾隆五十一年十二月"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "隨同守備董得魁，並程廳官帶兵到中港堵禦賊匪。本月初七日，不料賊人漸多，兵少不敵。",
          "reporter": "竹塹營外委虞文光",
          "subtitle": "中港擊散官兵",
          "whenCh": "乾隆五十一年十二月初七日",
          "where": "中港"
        }
      ],
      "hops": [
        {
          "from_person": "竹塹營外委虞文光",
          "how": "口述",
          "inferred": false,
          "layer": 2,
          "place": "泉州",
          "quote": "又有北路竹塹營外委虞文光、兵丁王元浩，亦先後到泉，當即隨同六路提督傳詢。...據外委虞文光供：...本月初七日，不料賊人漸多，兵少不敵。",
          "to_person": "泉州府知府王右弼、晉江縣知縣徐夢麟",
          "whenAr": "1787/01/20",
          "whenCh": "乾隆五十一年十二月十二日"
        },
        {
          "from_person": "泉州府知府王右弼、晉江縣知縣徐夢麟",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "惠安",
          "quote": "旋於惠安途次接據泉州府知府王右弼、晉江縣知縣徐夢麟稟稱：...又有北路竹塹營外委虞文光、兵丁王元浩，亦先後到泉...等由到臣。",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/01/21",
          "whenCh": "乾隆五十一年十二月十三日"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "我父親會同董守備，帶領兵役鄉勇，赴中港地方堵禦。賊匪眾多，抵敵不住，我父親存亡不知。",
          "reporter": "署淡水同知程峻之子程必大",
          "subtitle": "中港擊散官兵",
          "whenCh": "乾隆五十一年十二月初七日",
          "where": "中港"
        }
      ],
      "hops": [
        {
          "from_person": "署淡水同知程峻之子程必大",
          "how": "口述",
          "inferred": false,
          "layer": 2,
          "place": "泉州",
          "quote": "十二日有署淡水同知程峻之子程必大...赴泉求救。...據程必大供稱：...我父親會同董守備，帶領兵役鄉勇，赴中港地方堵禦。賊匪眾多，抵敵不住，我父親存亡不知。",
          "to_person": "泉州府知府王右弼、晉江縣知縣徐夢麟",
          "whenAr": "1787/01/20",
          "whenCh": "乾隆五十一年十二月十二日"
        },
        {
          "from_person": "泉州府知府王右弼、晉江縣知縣徐夢麟",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "惠安",
          "quote": "旋於惠安途次接據泉州府知府王右弼、晉江縣知縣徐夢麟稟稱：十二日有署淡水同知程峻之子程必大...赴泉求救。...等由到臣。",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/01/21",
          "whenCh": "乾隆五十一年十二月十三日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "又聞得竹塹程同知、董守備，帶兵並鄉勇往中港堵禦，於本月初七日亦被賊殺散。",
            "reporter": "守備林登雲",
            "subtitle": "中港擊散官兵",
            "whenCh": "乾隆五十一年十二月初七日",
            "where": "中港"
          }
        ],
        "hops": [
          {
            "from_person": "守備林登雲",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "泉州",
            "quote": "又接據臣差往探信之守備林登雲稟報：...又聞得竹塹程同知、董守備，帶兵並鄉勇往中港堵禦，於本月初七日亦被賊殺散。等語。",
            "to_person": "閩浙總督常青",
            "whenAr": "",
            "whenCh": "乾隆五十一年十二月"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "隨同守備董得魁，並程廳官帶兵到中港堵禦賊匪。本月初七日，不料賊人漸多，兵少不敵。",
            "reporter": "竹塹營外委虞文光",
            "subtitle": "中港擊散官兵",
            "whenCh": "乾隆五十一年十二月初七日",
            "where": "中港"
          }
        ],
        "hops": [
          {
            "from_person": "竹塹營外委虞文光",
            "how": "口述",
            "inferred": false,
            "layer": 2,
            "place": "泉州",
            "quote": "又有北路竹塹營外委虞文光、兵丁王元浩，亦先後到泉，當即隨同六路提督傳詢。...據外委虞文光供：...本月初七日，不料賊人漸多，兵少不敵。",
            "to_person": "泉州府知府王右弼、晉江縣知縣徐夢麟",
            "whenAr": "1787/01/20",
            "whenCh": "乾隆五十一年十二月十二日"
          },
          {
            "from_person": "泉州府知府王右弼、晉江縣知縣徐夢麟",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "惠安",
            "quote": "旋於惠安途次接據泉州府知府王右弼、晉江縣知縣徐夢麟稟稱：...又有北路竹塹營外委虞文光、兵丁王元浩，亦先後到泉...等由到臣。",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/01/21",
            "whenCh": "乾隆五十一年十二月十三日"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "我父親會同董守備，帶領兵役鄉勇，赴中港地方堵禦。賊匪眾多，抵敵不住，我父親存亡不知。",
            "reporter": "署淡水同知程峻之子程必大",
            "subtitle": "中港擊散官兵",
            "whenCh": "乾隆五十一年十二月初七日",
            "where": "中港"
          }
        ],
        "hops": [
          {
            "from_person": "署淡水同知程峻之子程必大",
            "how": "口述",
            "inferred": false,
            "layer": 2,
            "place": "泉州",
            "quote": "十二日有署淡水同知程峻之子程必大...赴泉求救。...據程必大供稱：...我父親會同董守備，帶領兵役鄉勇，赴中港地方堵禦。賊匪眾多，抵敵不住，我父親存亡不知。",
            "to_person": "泉州府知府王右弼、晉江縣知縣徐夢麟",
            "whenAr": "1787/01/20",
            "whenCh": "乾隆五十一年十二月十二日"
          },
          {
            "from_person": "泉州府知府王右弼、晉江縣知縣徐夢麟",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "惠安",
            "quote": "旋於惠安途次接據泉州府知府王右弼、晉江縣知縣徐夢麟稟稱：十二日有署淡水同知程峻之子程必大...赴泉求救。...等由到臣。",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/01/21",
            "whenCh": "乾隆五十一年十二月十三日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台35

```json
{
  "doc_id": "台35",
  "evTitle": "賊匪攻入竹塹搶擄",
  "event": {
    "description": "叛軍於十二月初七日攻抵竹塹，並在當地四處搶劫擄掠。",
    "howKnown": "轉述",
    "quote": "賊匪于十初七日已到竹塹，四行搶擄",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪攻入竹塹搶擄",
    "whenAr": "1787/01/25",
    "whenCh": "十二月初七日",
    "whenKnownCh": "十二月十二日",
    "where": "竹塹",
    "who": [
      "賊匪"
    ],
    "who_loc": {
      "賊匪": "竹塹"
    },
    "doc_id": "台35"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "賊匪于十初七日已到竹塹，四行搶擄",
          "reporter": "程必大",
          "subtitle": "賊匪攻入竹塹搶擄",
          "whenCh": "十初七日",
          "where": "竹塹"
        }
      ],
      "hops": [
        {
          "from_person": "王右弼、徐夢麟",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "惠安途次",
          "quote": "旋於惠安途次接據泉州府知府王右弼、晉江縣知縣徐夢麟稟稱：十二日有署淡水同知程峻之子程必大，懷取淡防同知關防，赴泉求救。...等由到臣。",
          "to_person": "常青",
          "whenAr": "",
          "whenCh": "十二月十三日夜"
        },
        {
          "from_person": "程必大",
          "how": "口述",
          "inferred": false,
          "layer": 2,
          "place": "泉州",
          "quote": "十二日有署淡水同知程峻之子程必大，懷取淡防同知關防，赴泉求救。...據程必大供稱：...賊匪于十初七日已到竹塹，四行搶擄",
          "to_person": "王右弼、徐夢麟",
          "whenAr": "",
          "whenCh": "十二月十二日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "賊匪于十初七日已到竹塹，四行搶擄",
            "reporter": "程必大",
            "subtitle": "賊匪攻入竹塹搶擄",
            "whenCh": "十初七日",
            "where": "竹塹"
          }
        ],
        "hops": [
          {
            "from_person": "王右弼、徐夢麟",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "惠安途次",
            "quote": "旋於惠安途次接據泉州府知府王右弼、晉江縣知縣徐夢麟稟稱：十二日有署淡水同知程峻之子程必大，懷取淡防同知關防，赴泉求救。...等由到臣。",
            "to_person": "常青",
            "whenAr": "",
            "whenCh": "十二月十三日夜"
          },
          {
            "from_person": "程必大",
            "how": "口述",
            "inferred": false,
            "layer": 2,
            "place": "泉州",
            "quote": "十二日有署淡水同知程峻之子程必大，懷取淡防同知關防，赴泉求救。...據程必大供稱：...賊匪于十初七日已到竹塹，四行搶擄",
            "to_person": "王右弼、徐夢麟",
            "whenAr": "",
            "whenCh": "十二月十二日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台33

```json
{
  "doc_id": "台33",
  "evTitle": "林爽文等結黨四擾",
  "event": {
    "description": "彰化匪徒林爽文、王芬等在深山大里杙等莊結黨，乘值歲暮四處搶劫滋事。",
    "howKnown": "轉述",
    "quote": "彰化匪徒林爽文等結黨四擾……大里杙等莊有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
    "relations": [
      {
        "evidence": "林爽文、王芬等結黨",
        "relation": "結黨",
        "relation_type": "ally",
        "source": "林爽文",
        "target": "王芬"
      }
    ],
    "side": "lin",
    "subtitle": "林爽文等結黨四擾",
    "whenAr": "",
    "whenCh": "十一月",
    "whenKnownCh": "十二月十一日",
    "where": "大里杙",
    "who": [
      "林爽文",
      "王芬"
    ],
    "who_loc": {
      "林爽文": "大里杙",
      "王芬": "大里杙"
    },
    "doc_id": "台33"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "彰化匪徒林爽文等結黨四擾",
          "reporter": "程峻",
          "subtitle": "林爽文等結黨四擾",
          "whenCh": "乾隆五十一年十一月",
          "where": "彰化"
        }
      ],
      "hops": [
        {
          "from_person": "程峻",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "十二月十一日接到署淡水同知程峻等會稟：彰化匪徒林爽文等結黨四擾",
          "to_person": "常青",
          "whenAr": "1787/01/29",
          "whenCh": "乾隆五十一年十二月十一日"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "大里杙等莊有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
          "reporter": "耿世文",
          "subtitle": "林爽文等結黨四擾",
          "whenCh": "乾隆五十一年十一月",
          "where": "大里杙"
        }
      ],
      "hops": [
        {
          "from_person": "柴大紀、永福",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "涂嶺",
          "quote": "接據臺灣鎮道十二月初二日來稟，内稱：職道等訪聞北路一帶深山，地方遼闊。大里杙等莊有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
          "to_person": "常青",
          "whenAr": "1787/01/31",
          "whenCh": "乾隆五十一年十二月十三日"
        },
        {
          "from_person": "耿世文、赫副將、俞令",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "臺灣",
          "quote": "業據中營遊擊耿世文帶領弁兵，同北協赫副將並彰令嚴緝報明在案",
          "to_person": "柴大紀、永福",
          "whenAr": "",
          "whenCh": "乾隆五十一年十一月"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "大里杙等莊有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
          "reporter": "柴大紀、永福",
          "subtitle": "林爽文等結黨四擾",
          "whenCh": "乾隆五十一年十一月",
          "where": "大里杙"
        }
      ],
      "hops": [
        {
          "from_person": "柴大紀、永福",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "涂嶺",
          "quote": "接據臺灣鎮道十二月初二日來稟，内稱：職道等訪聞北路一帶深山，地方遼闊。大里杙等莊有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
          "to_person": "常青",
          "whenAr": "1787/01/31",
          "whenCh": "乾隆五十一年十二月十三日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "彰化匪徒林爽文等結黨四擾",
            "reporter": "程峻",
            "subtitle": "林爽文等結黨四擾",
            "whenCh": "乾隆五十一年十一月",
            "where": "彰化"
          }
        ],
        "hops": [
          {
            "from_person": "程峻",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "十二月十一日接到署淡水同知程峻等會稟：彰化匪徒林爽文等結黨四擾",
            "to_person": "常青",
            "whenAr": "1787/01/29",
            "whenCh": "乾隆五十一年十二月十一日"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "大里杙等莊有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
            "reporter": "耿世文",
            "subtitle": "林爽文等結黨四擾",
            "whenCh": "乾隆五十一年十一月",
            "where": "大里杙"
          }
        ],
        "hops": [
          {
            "from_person": "柴大紀、永福",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "涂嶺",
            "quote": "接據臺灣鎮道十二月初二日來稟，内稱：職道等訪聞北路一帶深山，地方遼闊。大里杙等莊有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
            "to_person": "常青",
            "whenAr": "1787/01/31",
            "whenCh": "乾隆五十一年十二月十三日"
          },
          {
            "from_person": "耿世文、赫副將、俞令",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "臺灣",
            "quote": "業據中營遊擊耿世文帶領弁兵，同北協赫副將並彰令嚴緝報明在案",
            "to_person": "柴大紀、永福",
            "whenAr": "",
            "whenCh": "乾隆五十一年十一月"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "大里杙等莊有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
            "reporter": "柴大紀、永福",
            "subtitle": "林爽文等結黨四擾",
            "whenCh": "乾隆五十一年十一月",
            "where": "大里杙"
          }
        ],
        "hops": [
          {
            "from_person": "柴大紀、永福",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "涂嶺",
            "quote": "接據臺灣鎮道十二月初二日來稟，内稱：職道等訪聞北路一帶深山，地方遼闊。大里杙等莊有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
            "to_person": "常青",
            "whenAr": "1787/01/31",
            "whenCh": "乾隆五十一年十二月十三日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台33

```json
{
  "doc_id": "台33",
  "evTitle": "大墩營盤遇襲與彰城失陷",
  "event": {
    "description": "林爽文等賊匪散而復聚數千人，於十一月二十七日夜四更攻劫大墩營盤，並於二十七日夜使彰化俞令遇害、彰化城失陷。",
    "howKnown": "轉述",
    "quote": "十一月二十七夜，彰化俞令拿匪遇害，彰城失陷……二十七日夜四更時候，賊匪散而復聚，竟有數千人往劫大墩營盤。",
    "relations": [
      {
        "evidence": "彰化俞令拿匪遇害",
        "relation": "遇害",
        "relation_type": "conflict",
        "source": "林爽文",
        "target": "俞峻"
      }
    ],
    "side": "lin",
    "subtitle": "大墩營盤遇襲與彰城失陷",
    "whenAr": "1786/12/17",
    "whenCh": "十一月二十七日夜",
    "whenKnownCh": "十二月十一日",
    "where": "大墩",
    "who": [
      "林爽文",
      "俞峻"
    ],
    "who_loc": {
      "俞峻": "大墩",
      "林爽文": "大墩"
    },
    "doc_id": "台33"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "彰化匪徒林爽文等結黨四擾，十一月二十七夜，彰化俞令拿匪遇害，彰城失陷",
          "reporter": "署淡水同知程峻等",
          "subtitle": "彰化俞令遇害與彰城失陷",
          "whenCh": "十一月二十七夜",
          "where": "彰化"
        }
      ],
      "hops": [
        {
          "from_person": "署淡水同知程峻等",
          "how": "會稟",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "臣於十二月十一日接到署淡水同知程峻等會稟：彰化匪徒林爽文等結黨四擾，十一月二十七夜，彰化俞令拿匪遇害，彰城失陷，路途梗塞。等情。",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/01/29",
          "whenCh": "十二月十一日"
        }
      ]
    },
    {
      "events": [
        {
          "quote": "二十七日夜四更時候，賊匪散而復聚，竟有數千人往劫大墩營盤。",
          "reporter": "中營王都司",
          "subtitle": "大墩營盤遇襲",
          "whenCh": "十一月二十七日夜四更",
          "where": "大墩營盤"
        }
      ],
      "hops": [
        {
          "from_person": "臺灣鎮柴大紀、臺灣道永福",
          "how": "來稟",
          "inferred": false,
          "layer": 1,
          "place": "福建涂嶺途次",
          "quote": "茲於十三日行抵涂嶺途次，接據臺灣鎮道十二月初二日來稟",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/01/31",
          "whenCh": "十二月十三日"
        },
        {
          "from_person": "中營王都司",
          "how": "報稱",
          "inferred": false,
          "layer": 2,
          "place": "臺灣府城",
          "quote": "茲本月初一日接據中營王都司報稱",
          "to_person": "臺灣鎮柴大紀、臺灣道永福",
          "whenAr": "1787/01/19",
          "whenCh": "十二月初一日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "彰化匪徒林爽文等結黨四擾，十一月二十七夜，彰化俞令拿匪遇害，彰城失陷",
            "reporter": "署淡水同知程峻等",
            "subtitle": "彰化俞令遇害與彰城失陷",
            "whenCh": "十一月二十七夜",
            "where": "彰化"
          }
        ],
        "hops": [
          {
            "from_person": "署淡水同知程峻等",
            "how": "會稟",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "臣於十二月十一日接到署淡水同知程峻等會稟：彰化匪徒林爽文等結黨四擾，十一月二十七夜，彰化俞令拿匪遇害，彰城失陷，路途梗塞。等情。",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/01/29",
            "whenCh": "十二月十一日"
          }
        ]
      },
      {
        "events": [
          {
            "quote": "二十七日夜四更時候，賊匪散而復聚，竟有數千人往劫大墩營盤。",
            "reporter": "中營王都司",
            "subtitle": "大墩營盤遇襲",
            "whenCh": "十一月二十七日夜四更",
            "where": "大墩營盤"
          }
        ],
        "hops": [
          {
            "from_person": "臺灣鎮柴大紀、臺灣道永福",
            "how": "來稟",
            "inferred": false,
            "layer": 1,
            "place": "福建涂嶺途次",
            "quote": "茲於十三日行抵涂嶺途次，接據臺灣鎮道十二月初二日來稟",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/01/31",
            "whenCh": "十二月十三日"
          },
          {
            "from_person": "中營王都司",
            "how": "報稱",
            "inferred": false,
            "layer": 2,
            "place": "臺灣府城",
            "quote": "茲本月初一日接據中營王都司報稱",
            "to_person": "臺灣鎮柴大紀、臺灣道永福",
            "whenAr": "1787/01/19",
            "whenCh": "十二月初一日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台33

```json
{
  "doc_id": "台33",
  "evTitle": "匪徒阻截大肚溪交通",
  "event": {
    "description": "賊匪於大肚溪邊道路進行阻截，導致南北信息不通，並在南、北投一帶糾集滋事，聲言進攻彰化縣城。",
    "howKnown": "轉述",
    "quote": "並於大肚溪邊路，以致信息不通。南、北投一帶，亦有匪徒糾集滋事，且聞要攻縣城。",
    "relations": [],
    "side": "lin",
    "subtitle": "匪徒阻截大肚溪交通",
    "whenAr": "1786/12/18",
    "whenCh": "十一月二十八日",
    "whenKnownCh": "十二月十三日",
    "where": "大肚溪",
    "who": [],
    "who_loc": {},
    "doc_id": "台33"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "並於大肚溪邊路，以致信息不通。南、北投一帶，亦有匪徒糾集滋事，且聞要攻縣城。",
          "reporter": "中營王都司",
          "subtitle": "匪徒阻截大肚溪交通",
          "whenCh": "乾隆五十一年十一月二十八日",
          "where": "大肚溪、南投、北投"
        }
      ],
      "hops": [
        {
          "from_person": "臺灣鎮柴大紀、臺灣道永福",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "涂嶺",
          "quote": "茲於十三日行抵涂嶺途次，接據臺灣鎮道十二月初二日來稟...合將調兵起程剿捕緣由，先行具稟。等情到臣。",
          "to_person": "閩浙總督常青",
          "whenAr": "1787/01/31",
          "whenCh": "乾隆五十一年十二月十三日"
        },
        {
          "from_person": "中營王都司",
          "how": "報稱",
          "inferred": false,
          "layer": 2,
          "place": "臺灣府城",
          "quote": "茲本月初一日接據中營王都司報稱",
          "to_person": "臺灣鎮柴大紀、臺灣道永福",
          "whenAr": "1787/01/19",
          "whenCh": "乾隆五十一年十二月初一日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "並於大肚溪邊路，以致信息不通。南、北投一帶，亦有匪徒糾集滋事，且聞要攻縣城。",
            "reporter": "中營王都司",
            "subtitle": "匪徒阻截大肚溪交通",
            "whenCh": "乾隆五十一年十一月二十八日",
            "where": "大肚溪、南投、北投"
          }
        ],
        "hops": [
          {
            "from_person": "臺灣鎮柴大紀、臺灣道永福",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "涂嶺",
            "quote": "茲於十三日行抵涂嶺途次，接據臺灣鎮道十二月初二日來稟...合將調兵起程剿捕緣由，先行具稟。等情到臣。",
            "to_person": "閩浙總督常青",
            "whenAr": "1787/01/31",
            "whenCh": "乾隆五十一年十二月十三日"
          },
          {
            "from_person": "中營王都司",
            "how": "報稱",
            "inferred": false,
            "layer": 2,
            "place": "臺灣府城",
            "quote": "茲本月初一日接據中營王都司報稱",
            "to_person": "臺灣鎮柴大紀、臺灣道永福",
            "whenAr": "1787/01/19",
            "whenCh": "乾隆五十一年十二月初一日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台36

```json
{
  "doc_id": "台36",
  "evTitle": "林爽文等結黨滋事",
  "event": {
    "description": "彰化縣匪徒林爽文等人於十一月初間結黨滋事，地方官府擒捕未獲。",
    "howKnown": "轉述",
    "quote": "十一月初間聞彰化縣匪徒林爽文等結黨四虐，擒捕未獲。",
    "relations": [],
    "side": "lin",
    "subtitle": "林爽文等結黨滋事",
    "whenAr": "1786/12/20",
    "whenCh": "十一月初間",
    "whenKnownCh": "十二月二十六日",
    "where": "彰化縣",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "彰化縣"
    },
    "doc_id": "台36"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "十一月初間聞彰化縣匪徒林爽文等結黨四虐，擒捕未獲。",
          "reporter": "淡水同知程峻、北路竹塹營守備董得魁",
          "subtitle": "林爽文等結黨滋事",
          "whenCh": "十一月初間",
          "where": "彰化縣"
        }
      ],
      "hops": [
        {
          "from_person": "平陽協副將英海",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "浙江",
          "quote": "據平陽協副將英海稟稱...轉稟前來",
          "to_person": "浙江提督陳大用",
          "whenAr": "1787/02/13",
          "whenCh": "十二月二十六日已刻"
        },
        {
          "from_person": "福建桐山營遊擊吝",
          "how": "轉行",
          "inferred": false,
          "layer": 2,
          "place": "福建桐山",
          "quote": "准福建桐山營遊擊吝...轉稟前來",
          "to_person": "平陽協副將英海",
          "whenAr": "",
          "whenCh": ""
        },
        {
          "from_person": "福建巡撫",
          "how": "行文",
          "inferred": false,
          "layer": 3,
          "place": "福建",
          "quote": "奉福建巡撫行",
          "to_person": "福建桐山營遊擊吝",
          "whenAr": "",
          "whenCh": ""
        },
        {
          "from_person": "淡水同知程峻、北路竹塹營守備董得魁",
          "how": "稟報",
          "inferred": false,
          "layer": 4,
          "place": "臺灣",
          "quote": "據淡水同知程峻、北路竹塹營守備董得魁稟報",
          "to_person": "福建巡撫",
          "whenAr": "",
          "whenCh": ""
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "十一月初間聞彰化縣匪徒林爽文等結黨四虐，擒捕未獲。",
            "reporter": "淡水同知程峻、北路竹塹營守備董得魁",
            "subtitle": "林爽文等結黨滋事",
            "whenCh": "十一月初間",
            "where": "彰化縣"
          }
        ],
        "hops": [
          {
            "from_person": "平陽協副將英海",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "浙江",
            "quote": "據平陽協副將英海稟稱...轉稟前來",
            "to_person": "浙江提督陳大用",
            "whenAr": "1787/02/13",
            "whenCh": "十二月二十六日已刻"
          },
          {
            "from_person": "福建桐山營遊擊吝",
            "how": "轉行",
            "inferred": false,
            "layer": 2,
            "place": "福建桐山",
            "quote": "准福建桐山營遊擊吝...轉稟前來",
            "to_person": "平陽協副將英海",
            "whenAr": "",
            "whenCh": ""
          },
          {
            "from_person": "福建巡撫",
            "how": "行文",
            "inferred": false,
            "layer": 3,
            "place": "福建",
            "quote": "奉福建巡撫行",
            "to_person": "福建桐山營遊擊吝",
            "whenAr": "",
            "whenCh": ""
          },
          {
            "from_person": "淡水同知程峻、北路竹塹營守備董得魁",
            "how": "稟報",
            "inferred": false,
            "layer": 4,
            "place": "臺灣",
            "quote": "據淡水同知程峻、北路竹塹營守備董得魁稟報",
            "to_person": "福建巡撫",
            "whenAr": "",
            "whenCh": ""
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台36

```json
{
  "doc_id": "台36",
  "evTitle": "匪徒於大墩殺害知縣",
  "event": {
    "description": "彰化知縣俞峻在大墩地方率兵搜捕匪徒時，遭林爽文等民變群眾殺害。",
    "howKnown": "轉述",
    "quote": "此月二十七日，本縣俞知縣在大墩地方拿匪被害",
    "relations": [
      {
        "evidence": "俞知縣在大墩地方拿匪被害",
        "relation": "拿匪被害",
        "relation_type": "conflict",
        "source": "林爽文",
        "target": "俞峻"
      }
    ],
    "side": "lin",
    "subtitle": "匪徒於大墩殺害知縣",
    "whenAr": "1787/01/16",
    "whenCh": "十一月二十七日",
    "whenKnownCh": "十二月二十六日",
    "where": "大墩",
    "who": [
      "林爽文",
      "俞峻"
    ],
    "who_loc": {
      "俞峻": "大墩",
      "林爽文": "大墩"
    },
    "doc_id": "台36"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "此月二十七日，本縣俞知縣在大墩地方拿匪被害",
          "reporter": "彰邑大肚社番",
          "subtitle": "匪徒於大墩殺害知縣",
          "whenCh": "十一月二十七日",
          "where": "大墩"
        }
      ],
      "hops": [
        {
          "from_person": "平陽協副將英海",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "浙江",
          "quote": "奴才於本年十二月二十六日已刻，據平陽協副將英海稟稱...轉稟前來",
          "to_person": "浙江提督陳大用",
          "whenAr": "1787/02/13",
          "whenCh": "十二月二十六日已刻"
        },
        {
          "from_person": "福建桐山營遊擊吝",
          "how": "轉稟",
          "inferred": false,
          "layer": 2,
          "place": "閩浙交界",
          "quote": "准福建桐山營遊擊吝...轉稟前來",
          "to_person": "平陽協副將英海",
          "whenAr": "",
          "whenCh": "十二月二十六日之前"
        },
        {
          "from_person": "福建巡撫",
          "how": "行文",
          "inferred": false,
          "layer": 3,
          "place": "福建",
          "quote": "奉福建巡撫行",
          "to_person": "福建桐山營遊擊吝",
          "whenAr": "",
          "whenCh": "十二月"
        },
        {
          "from_person": "淡水同知程峻、北路竹塹營守備董得魁",
          "how": "稟報",
          "inferred": false,
          "layer": 4,
          "place": "臺灣",
          "quote": "據淡水同知程峻、北路竹塹營守備董得魁稟報",
          "to_person": "福建巡撫",
          "whenAr": "",
          "whenCh": "十一月二十九日之後"
        },
        {
          "from_person": "淡屬大甲社通事",
          "how": "轉述",
          "inferred": true,
          "layer": 5,
          "place": "臺灣淡水",
          "quote": "二十九日彰邑大肚社番字寄淡屬大甲社通事，據稱...等情",
          "to_person": "淡水同知程峻、北路竹塹營守備董得魁",
          "whenAr": "",
          "whenCh": "十一月二十九日之後"
        },
        {
          "from_person": "彰邑大肚社番",
          "how": "字寄",
          "inferred": false,
          "layer": 6,
          "place": "臺灣大甲社",
          "quote": "二十九日彰邑大肚社番字寄淡屬大甲社通事，據稱",
          "to_person": "淡屬大甲社通事",
          "whenAr": "1787/01/18",
          "whenCh": "十一月二十九日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "此月二十七日，本縣俞知縣在大墩地方拿匪被害",
            "reporter": "彰邑大肚社番",
            "subtitle": "匪徒於大墩殺害知縣",
            "whenCh": "十一月二十七日",
            "where": "大墩"
          }
        ],
        "hops": [
          {
            "from_person": "平陽協副將英海",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "浙江",
            "quote": "奴才於本年十二月二十六日已刻，據平陽協副將英海稟稱...轉稟前來",
            "to_person": "浙江提督陳大用",
            "whenAr": "1787/02/13",
            "whenCh": "十二月二十六日已刻"
          },
          {
            "from_person": "福建桐山營遊擊吝",
            "how": "轉稟",
            "inferred": false,
            "layer": 2,
            "place": "閩浙交界",
            "quote": "准福建桐山營遊擊吝...轉稟前來",
            "to_person": "平陽協副將英海",
            "whenAr": "",
            "whenCh": "十二月二十六日之前"
          },
          {
            "from_person": "福建巡撫",
            "how": "行文",
            "inferred": false,
            "layer": 3,
            "place": "福建",
            "quote": "奉福建巡撫行",
            "to_person": "福建桐山營遊擊吝",
            "whenAr": "",
            "whenCh": "十二月"
          },
          {
            "from_person": "淡水同知程峻、北路竹塹營守備董得魁",
            "how": "稟報",
            "inferred": false,
            "layer": 4,
            "place": "臺灣",
            "quote": "據淡水同知程峻、北路竹塹營守備董得魁稟報",
            "to_person": "福建巡撫",
            "whenAr": "",
            "whenCh": "十一月二十九日之後"
          },
          {
            "from_person": "淡屬大甲社通事",
            "how": "轉述",
            "inferred": true,
            "layer": 5,
            "place": "臺灣淡水",
            "quote": "二十九日彰邑大肚社番字寄淡屬大甲社通事，據稱...等情",
            "to_person": "淡水同知程峻、北路竹塹營守備董得魁",
            "whenAr": "",
            "whenCh": "十一月二十九日之後"
          },
          {
            "from_person": "彰邑大肚社番",
            "how": "字寄",
            "inferred": false,
            "layer": 6,
            "place": "臺灣大甲社",
            "quote": "二十九日彰邑大肚社番字寄淡屬大甲社通事，據稱",
            "to_person": "淡屬大甲社通事",
            "whenAr": "1787/01/18",
            "whenCh": "十一月二十九日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台36

```json
{
  "doc_id": "台36",
  "evTitle": "彰化縣城失陷",
  "event": {
    "description": "林爽文等民變隊伍攻陷彰化縣城。",
    "howKnown": "轉述",
    "quote": "本日彰城失陷",
    "relations": [],
    "side": "lin",
    "subtitle": "彰化縣城失陷",
    "whenAr": "1787/01/16",
    "whenCh": "十一月二十七日",
    "whenKnownCh": "十二月二十六日",
    "where": "彰化縣城",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "彰化縣城"
    },
    "doc_id": "台36"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "本日彰城失陷",
          "reporter": "大肚社番",
          "subtitle": "彰化縣城失陷",
          "whenCh": "十一月二十七日",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "英海",
          "how": "稟報",
          "inferred": false,
          "layer": 1,
          "place": "浙江",
          "quote": "據平陽協副將英海稟稱",
          "to_person": "陳大用",
          "whenAr": "1787/02/13",
          "whenCh": "十二月二十六日已刻"
        },
        {
          "from_person": "吝",
          "how": "轉行",
          "inferred": false,
          "layer": 2,
          "place": "福建桐山營",
          "quote": "准福建桐山營遊擊吝，奉福建巡撫行據淡水同知程峻、北路竹塹營守備董得魁稟報……轉行前途各營、縣堵禦查拿。等因。轉稟前來",
          "to_person": "英海",
          "whenAr": "",
          "whenCh": "十二月"
        },
        {
          "from_person": "程峻、董得魁",
          "how": "稟報",
          "inferred": false,
          "layer": 3,
          "place": "淡水、竹塹",
          "quote": "奉福建巡撫行據淡水同知程峻、北路竹塹營守備董得魁稟報",
          "to_person": "吝",
          "whenAr": "",
          "whenCh": "十一月"
        },
        {
          "from_person": "大甲社通事",
          "how": "轉述",
          "inferred": false,
          "layer": 4,
          "place": "淡水大甲社",
          "quote": "二十九日彰邑大肚社番字寄淡屬大甲社通事",
          "to_person": "程峻、董得魁",
          "whenAr": "1787/01/17",
          "whenCh": "十一月二十九日"
        },
        {
          "from_person": "大肚社番",
          "how": "字寄",
          "inferred": false,
          "layer": 5,
          "place": "彰化大肚社",
          "quote": "二十九日彰邑大肚社番字寄淡屬大甲社通事",
          "to_person": "大甲社通事",
          "whenAr": "1787/01/17",
          "whenCh": "十一月二十九日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "本日彰城失陷",
            "reporter": "大肚社番",
            "subtitle": "彰化縣城失陷",
            "whenCh": "十一月二十七日",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "英海",
            "how": "稟報",
            "inferred": false,
            "layer": 1,
            "place": "浙江",
            "quote": "據平陽協副將英海稟稱",
            "to_person": "陳大用",
            "whenAr": "1787/02/13",
            "whenCh": "十二月二十六日已刻"
          },
          {
            "from_person": "吝",
            "how": "轉行",
            "inferred": false,
            "layer": 2,
            "place": "福建桐山營",
            "quote": "准福建桐山營遊擊吝，奉福建巡撫行據淡水同知程峻、北路竹塹營守備董得魁稟報……轉行前途各營、縣堵禦查拿。等因。轉稟前來",
            "to_person": "英海",
            "whenAr": "",
            "whenCh": "十二月"
          },
          {
            "from_person": "程峻、董得魁",
            "how": "稟報",
            "inferred": false,
            "layer": 3,
            "place": "淡水、竹塹",
            "quote": "奉福建巡撫行據淡水同知程峻、北路竹塹營守備董得魁稟報",
            "to_person": "吝",
            "whenAr": "",
            "whenCh": "十一月"
          },
          {
            "from_person": "大甲社通事",
            "how": "轉述",
            "inferred": false,
            "layer": 4,
            "place": "淡水大甲社",
            "quote": "二十九日彰邑大肚社番字寄淡屬大甲社通事",
            "to_person": "程峻、董得魁",
            "whenAr": "1787/01/17",
            "whenCh": "十一月二十九日"
          },
          {
            "from_person": "大肚社番",
            "how": "字寄",
            "inferred": false,
            "layer": 5,
            "place": "彰化大肚社",
            "quote": "二十九日彰邑大肚社番字寄淡屬大甲社通事",
            "to_person": "大甲社通事",
            "whenAr": "1787/01/17",
            "whenCh": "十一月二十九日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台34

```json
{
  "doc_id": "台34",
  "evTitle": "林爽文等結黨搶劫",
  "event": {
    "description": "林爽文、王芬等人在大里杙等莊糾集黨羽，利用歲末之際進行搶劫滋事。",
    "howKnown": "訪聞",
    "quote": "大里杙等莊有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
    "relations": [
      {
        "evidence": "林爽文、王芬等結黨",
        "relation": "結黨",
        "relation_type": "ally",
        "source": "林爽文",
        "target": "王芬"
      }
    ],
    "side": "lin",
    "subtitle": "林爽文等結黨搶劫",
    "whenAr": "",
    "whenCh": "歲暮",
    "whenKnownCh": "",
    "where": "大里杙等莊",
    "who": [
      "林爽文",
      "王芬"
    ],
    "who_loc": {
      "林爽文": "大里杙",
      "王芬": "大里杙"
    },
    "doc_id": "台34"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "大里杙等莊有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
          "reporter": "臺灣鎮總兵柴大紀、臺灣道永福",
          "subtitle": "林爽文等結黨搶劫",
          "whenCh": "歲暮",
          "where": "大里杙等莊"
        }
      ],
      "hops": [
        {
          "from_person": "臺灣鎮總兵柴大紀、臺灣道永福",
          "how": "咨會",
          "inferred": false,
          "layer": 1,
          "place": "舟次",
          "quote": "接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱：訪聞北路一帶深山，地方遼闊。大里杙等莊有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
          "to_person": "黃仕簡",
          "whenAr": "1786/12/30",
          "whenCh": "十二月十一日"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "大里杙等莊有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
            "reporter": "臺灣鎮總兵柴大紀、臺灣道永福",
            "subtitle": "林爽文等結黨搶劫",
            "whenCh": "歲暮",
            "where": "大里杙等莊"
          }
        ],
        "hops": [
          {
            "from_person": "臺灣鎮總兵柴大紀、臺灣道永福",
            "how": "咨會",
            "inferred": false,
            "layer": 1,
            "place": "舟次",
            "quote": "接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱：訪聞北路一帶深山，地方遼闊。大里杙等莊有奸民林爽文、王芬等結黨，乘值歲暮搶劫",
            "to_person": "黃仕簡",
            "whenAr": "1786/12/30",
            "whenCh": "十二月十一日"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台34

```json
{
  "doc_id": "台34",
  "evTitle": "賊匪夜劫大墩營盤",
  "event": {
    "description": "十一月二十七日夜四更，原本散去的匪徒重新聚集數千人，前往搶劫大墩營盤。",
    "howKnown": "轉述",
    "quote": "忽聞十一月二十七夜四更時候，賊匪散而復聚，竟有數千人，往劫大墩營盤。",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪夜劫大墩營盤",
    "whenAr": "1787/01/16",
    "whenCh": "十一月二十七日",
    "whenKnownCh": "十二月初一日",
    "where": "大墩",
    "who": [],
    "who_loc": {},
    "doc_id": "台34"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "忽聞十一月二十七夜四更時候，賊匪散而復聚，竟有數千人，往劫大墩營盤。",
          "reporter": "王宗武",
          "subtitle": "賊匪夜劫大墩營盤",
          "whenCh": "十一月二十七日夜四更",
          "where": "大墩營盤"
        }
      ],
      "hops": [
        {
          "from_person": "柴大紀、永福",
          "how": "咨會",
          "inferred": false,
          "layer": 1,
          "place": "舟次",
          "quote": "茲十一日舟次，接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱",
          "to_person": "黃仕簡",
          "whenAr": "1787/01/29",
          "whenCh": "十二月十一日"
        },
        {
          "from_person": "王宗武",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "臺灣",
          "quote": "據北路中營都司王宗武報稱",
          "to_person": "柴大紀、永福",
          "whenAr": "1787/01/19",
          "whenCh": "十二月初一日辰刻"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "忽聞十一月二十七夜四更時候，賊匪散而復聚，竟有數千人，往劫大墩營盤。",
            "reporter": "王宗武",
            "subtitle": "賊匪夜劫大墩營盤",
            "whenCh": "十一月二十七日夜四更",
            "where": "大墩營盤"
          }
        ],
        "hops": [
          {
            "from_person": "柴大紀、永福",
            "how": "咨會",
            "inferred": false,
            "layer": 1,
            "place": "舟次",
            "quote": "茲十一日舟次，接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱",
            "to_person": "黃仕簡",
            "whenAr": "1787/01/29",
            "whenCh": "十二月十一日"
          },
          {
            "from_person": "王宗武",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "臺灣",
            "quote": "據北路中營都司王宗武報稱",
            "to_person": "柴大紀、永福",
            "whenAr": "1787/01/19",
            "whenCh": "十二月初一日辰刻"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台34

```json
{
  "doc_id": "台34",
  "evTitle": "大肚溪聚匪截路",
  "event": {
    "description": "匪徒在大肚溪一帶聚集並阻斷道路，導致官軍地方信息無法互通。",
    "howKnown": "轉述",
    "quote": "並於大肚溪邊聚匪截路，以致信息不通。",
    "relations": [],
    "side": "lin",
    "subtitle": "大肚溪聚匪截路",
    "whenAr": "",
    "whenCh": "十一月二十七日後",
    "whenKnownCh": "十二月初一日",
    "where": "大肚溪",
    "who": [],
    "who_loc": {},
    "doc_id": "台34"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "並於大肚溪邊聚匪截路，以致信息不通。",
          "reporter": "北路中營都司王宗武",
          "subtitle": "大肚溪聚匪截路",
          "whenCh": "十一月二十七夜四更時候後",
          "where": "大肚溪"
        }
      ],
      "hops": [
        {
          "from_person": "臺灣鎮總兵柴大紀、臺灣道永福",
          "how": "咨會",
          "inferred": false,
          "layer": 1,
          "place": "舟次",
          "quote": "茲十一日舟次，接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱",
          "to_person": "黃仕簡",
          "whenAr": "1786/12/30",
          "whenCh": "十二月十一日"
        },
        {
          "from_person": "北路中營都司王宗武",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "臺灣府城",
          "quote": "據北路中營都司王宗武報稱",
          "to_person": "臺灣鎮總兵柴大紀、臺灣道永福",
          "whenAr": "1786/12/20",
          "whenCh": "十二月初一日辰刻"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "並於大肚溪邊聚匪截路，以致信息不通。",
            "reporter": "北路中營都司王宗武",
            "subtitle": "大肚溪聚匪截路",
            "whenCh": "十一月二十七夜四更時候後",
            "where": "大肚溪"
          }
        ],
        "hops": [
          {
            "from_person": "臺灣鎮總兵柴大紀、臺灣道永福",
            "how": "咨會",
            "inferred": false,
            "layer": 1,
            "place": "舟次",
            "quote": "茲十一日舟次，接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱",
            "to_person": "黃仕簡",
            "whenAr": "1786/12/30",
            "whenCh": "十二月十一日"
          },
          {
            "from_person": "北路中營都司王宗武",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "臺灣府城",
            "quote": "據北路中營都司王宗武報稱",
            "to_person": "臺灣鎮總兵柴大紀、臺灣道永福",
            "whenAr": "1786/12/20",
            "whenCh": "十二月初一日辰刻"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台34

```json
{
  "doc_id": "台34",
  "evTitle": "南北投匪徒糾集滋事",
  "event": {
    "description": "南投、北投一帶有匪徒糾集滋事，並傳聞準備進攻彰化縣城。",
    "howKnown": "轉述",
    "quote": "南、北投一帶，亦有匪徒糾集滋事，且聞要攻縣城。",
    "relations": [],
    "side": "lin",
    "subtitle": "南北投匪徒糾集滋事",
    "whenAr": "",
    "whenCh": "十一月底",
    "whenKnownCh": "十二月初一日",
    "where": "南投、北投",
    "who": [],
    "who_loc": {},
    "doc_id": "台34"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "南、北投一帶，亦有匪徒糾集滋事，且聞要攻縣城。",
          "reporter": "王宗武",
          "subtitle": "南北投匪徒糾集滋事",
          "whenCh": "十一月底",
          "where": "南投、北投"
        }
      ],
      "hops": [
        {
          "from_person": "柴大紀、永福",
          "how": "咨會",
          "inferred": false,
          "layer": 1,
          "place": "舟次",
          "quote": "茲十一日舟次，接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱",
          "to_person": "黃仕簡",
          "whenAr": "1787/01/29",
          "whenCh": "十二月十一日"
        },
        {
          "from_person": "王宗武",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "臺灣",
          "quote": "據北路中營都司王宗武報稱：...南、北投一帶，亦有匪徒糾集滋事，且聞要攻縣城。",
          "to_person": "柴大紀、永福",
          "whenAr": "1786/12/21",
          "whenCh": "十二月初一日辰刻"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "南、北投一帶，亦有匪徒糾集滋事，且聞要攻縣城。",
            "reporter": "王宗武",
            "subtitle": "南北投匪徒糾集滋事",
            "whenCh": "十一月底",
            "where": "南投、北投"
          }
        ],
        "hops": [
          {
            "from_person": "柴大紀、永福",
            "how": "咨會",
            "inferred": false,
            "layer": 1,
            "place": "舟次",
            "quote": "茲十一日舟次，接准臺灣鎮總兵柴大紀、臺灣道永福聯銜咨稱",
            "to_person": "黃仕簡",
            "whenAr": "1787/01/29",
            "whenCh": "十二月十一日"
          },
          {
            "from_person": "王宗武",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "臺灣",
            "quote": "據北路中營都司王宗武報稱：...南、北投一帶，亦有匪徒糾集滋事，且聞要攻縣城。",
            "to_person": "柴大紀、永福",
            "whenAr": "1786/12/21",
            "whenCh": "十二月初一日辰刻"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 台34

```json
{
  "doc_id": "台34",
  "evTitle": "匪徒攻陷彰化縣城",
  "event": {
    "description": "臺灣民變匪徒攻陷彰化縣城，並殺害城內官員。",
    "howKnown": "聞報",
    "quote": "臺灣匪犯攻陷彰化縣城殺官",
    "relations": [],
    "side": "lin",
    "subtitle": "匪徒攻陷彰化縣城",
    "whenAr": "",
    "whenCh": "十一月底",
    "whenKnownCh": "十二月初十日前",
    "where": "彰化縣城",
    "who": [],
    "who_loc": {},
    "doc_id": "台34"
  },
  "chains": [],
  "_raw": {
    "chains": [],
    "mode": "trace"
  }
}
```

## 天13

```json
{
  "doc_id": "天13",
  "evTitle": "林爽文等結黨滋事騷擾地方",
  "event": {
    "description": "臺灣彰化縣匪徒林爽文等人糾眾結黨，在地方上滋事騷擾。",
    "howKnown": "轉述",
    "quote": "臺灣彰化縣匪徒林爽文等，結黨滋事，騷擾地方。",
    "relations": [],
    "side": "lin",
    "subtitle": "林爽文等結黨滋事騷擾地方",
    "whenAr": "",
    "whenCh": "",
    "whenKnownCh": "十二月二十七日",
    "where": "臺灣彰化縣",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "彰化縣"
    },
    "doc_id": "天13"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "臺灣彰化縣匪徒林爽文等，結黨滋事，騷擾地方。",
          "reporter": "常青",
          "subtitle": "林爽文等結黨滋事騷擾地方",
          "whenCh": "乾隆五十一年",
          "where": "臺灣彰化縣"
        }
      ],
      "hops": [
        {
          "from_person": "常青",
          "how": "奏報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "據常青等奏，臺灣彰化縣匪徒林爽文等，結黨滋事，騷擾地方。",
          "to_person": "乾隆帝",
          "whenAr": "",
          "whenCh": "乾隆五十一年十二月"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "臺灣彰化縣匪徒林爽文等，結黨滋事，騷擾地方。",
            "reporter": "常青",
            "subtitle": "林爽文等結黨滋事騷擾地方",
            "whenCh": "乾隆五十一年",
            "where": "臺灣彰化縣"
          }
        ],
        "hops": [
          {
            "from_person": "常青",
            "how": "奏報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "據常青等奏，臺灣彰化縣匪徒林爽文等，結黨滋事，騷擾地方。",
            "to_person": "乾隆帝",
            "whenAr": "",
            "whenCh": "乾隆五十一年十二月"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 天13

```json
{
  "doc_id": "天13",
  "evTitle": "匪徒殺害知縣並竊踞彰化縣城",
  "event": {
    "description": "彰化知縣俞峻會同副將前往各莊搜捕匪徒，匪徒先是逃竄，隨後散而復聚達數千人，導致知縣俞峻倉猝被害，彰化縣城亦被匪徒攻陷竊踞。",
    "howKnown": "轉述",
    "quote": "知縣俞駿（峻）拿匪被害，彰化縣城被匪徒竊踞。...彰化知縣會同副將前往各莊搜捕，賊匪俱已逃竄。嗣又散而復聚，竟有數千人，已致被害。",
    "relations": [
      {
        "evidence": "知縣俞駿（峻）拿匪被害",
        "relation": "殺害",
        "relation_type": "conflict",
        "source": "林爽文",
        "target": "俞峻"
      }
    ],
    "side": "lin",
    "subtitle": "匪徒殺害知縣並竊踞彰化縣城",
    "whenAr": "",
    "whenCh": "",
    "whenKnownCh": "十二月二十七日",
    "where": "彰化縣城",
    "who": [
      "林爽文",
      "俞峻"
    ],
    "who_loc": {
      "俞峻": "彰化縣",
      "林爽文": "彰化縣城"
    },
    "doc_id": "天13"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "知縣俞駿（峻）拿匪被害，彰化縣城被匪徒竊踞。...彰化知縣會同副將前往各莊搜捕，賊匪俱已逃竄。嗣又散而復聚，竟有數千人，已致被害。",
          "reporter": "常青",
          "subtitle": "匪徒殺害知縣並竊踞彰化縣城",
          "whenCh": "乾隆五十一年",
          "where": "彰化縣城"
        }
      ],
      "hops": [
        {
          "from_person": "常青",
          "how": "奏",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "據常青等奏，臺灣彰化縣匪徒林爽文等，結黨滋事，騷擾地方。知縣俞駿（峻）拿匪被害，彰化縣城被匪徒竊踞。",
          "to_person": "乾隆帝",
          "whenAr": "",
          "whenCh": "乾隆五十一年十二月二十七日以前"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "知縣俞駿（峻）拿匪被害，彰化縣城被匪徒竊踞。...彰化知縣會同副將前往各莊搜捕，賊匪俱已逃竄。嗣又散而復聚，竟有數千人，已致被害。",
            "reporter": "常青",
            "subtitle": "匪徒殺害知縣並竊踞彰化縣城",
            "whenCh": "乾隆五十一年",
            "where": "彰化縣城"
          }
        ],
        "hops": [
          {
            "from_person": "常青",
            "how": "奏",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "據常青等奏，臺灣彰化縣匪徒林爽文等，結黨滋事，騷擾地方。知縣俞駿（峻）拿匪被害，彰化縣城被匪徒竊踞。",
            "to_person": "乾隆帝",
            "whenAr": "",
            "whenCh": "乾隆五十一年十二月二十七日以前"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 天13

```json
{
  "doc_id": "天13",
  "evTitle": "賊匪赴諸羅縣攻城",
  "event": {
    "description": "林爽文部眾前往諸羅縣進攻城池，與官兵交戰，傳聞被官兵殺死二千餘人。",
    "howKnown": "轉述",
    "quote": "有傳說賊人赴諸羅縣攻城，被官兵殺死二千餘人。",
    "relations": [],
    "side": "lin",
    "subtitle": "賊匪赴諸羅縣攻城",
    "whenAr": "",
    "whenCh": "",
    "whenKnownCh": "十二月二十七日",
    "where": "諸羅縣",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "諸羅縣"
    },
    "doc_id": "天13"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "有傳說賊人赴諸羅縣攻城，被官兵殺死二千餘人。",
          "reporter": "船戶黃斌",
          "subtitle": "賊匪赴諸羅縣攻城",
          "whenCh": "乾隆五十一年十二月",
          "where": "諸羅縣"
        }
      ],
      "hops": [
        {
          "from_person": "福建巡撫徐嗣曾",
          "how": "奏報",
          "inferred": false,
          "layer": 1,
          "place": "福建",
          "quote": "又據徐嗣曾由六百里馳奏",
          "to_person": "乾隆帝",
          "whenAr": "1787/02/14",
          "whenCh": "乾隆五十一年十二月二十七日"
        },
        {
          "from_person": "蚶江通判陳惇",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "福建",
          "quote": "接蚶江通判陳惇稟稱",
          "to_person": "福建巡撫徐嗣曾",
          "whenAr": "",
          "whenCh": "乾隆五十一年十二月"
        },
        {
          "from_person": "船戶黃斌",
          "how": "口述",
          "inferred": false,
          "layer": 3,
          "place": "蚶江",
          "quote": "昨據船戶黃斌供，有傳說賊人赴諸羅縣攻城，被官兵殺死二千餘人。",
          "to_person": "蚶江通判陳惇",
          "whenAr": "",
          "whenCh": "乾隆五十一年十二月"
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "有傳說賊人赴諸羅縣攻城，被官兵殺死二千餘人。",
            "reporter": "船戶黃斌",
            "subtitle": "賊匪赴諸羅縣攻城",
            "whenCh": "乾隆五十一年十二月",
            "where": "諸羅縣"
          }
        ],
        "hops": [
          {
            "from_person": "福建巡撫徐嗣曾",
            "how": "奏報",
            "inferred": false,
            "layer": 1,
            "place": "福建",
            "quote": "又據徐嗣曾由六百里馳奏",
            "to_person": "乾隆帝",
            "whenAr": "1787/02/14",
            "whenCh": "乾隆五十一年十二月二十七日"
          },
          {
            "from_person": "蚶江通判陳惇",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "福建",
            "quote": "接蚶江通判陳惇稟稱",
            "to_person": "福建巡撫徐嗣曾",
            "whenAr": "",
            "whenCh": "乾隆五十一年十二月"
          },
          {
            "from_person": "船戶黃斌",
            "how": "口述",
            "inferred": false,
            "layer": 3,
            "place": "蚶江",
            "quote": "昨據船戶黃斌供，有傳說賊人赴諸羅縣攻城，被官兵殺死二千餘人。",
            "to_person": "蚶江通判陳惇",
            "whenAr": "",
            "whenCh": "乾隆五十一年十二月"
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

## 天20

```json
{
  "doc_id": "天20",
  "evTitle": "林爽文等攻陷彰化並攔截道路",
  "event": {
    "description": "彰化匪徒林爽文等糾眾起事，攻陷彰化縣城，並攔截重要道路，導致官府文報梗塞、信息不通。",
    "howKnown": "轉述",
    "quote": "彰化匪徒林爽文等糾衆滋事，攔截要路，以致信息不通……會匪糾衆攻陷彰化縣……彰化失陷，文報梗塞情形",
    "relations": [],
    "side": "lin",
    "subtitle": "林爽文等攻陷彰化並攔截道路",
    "whenAr": "",
    "whenCh": "",
    "whenKnownCh": "乾隆五十一年十二月二十九日",
    "where": "彰化縣",
    "who": [
      "林爽文"
    ],
    "who_loc": {
      "林爽文": "彰化縣"
    },
    "doc_id": "天20"
  },
  "chains": [
    {
      "events": [
        {
          "quote": "彰化匪徒林爽文等糾衆滋事，攔截要路，以致信息不通",
          "reporter": "臺灣鎮道",
          "subtitle": "林爽文等糾眾滋事並攔截道路",
          "whenCh": "",
          "where": "彰化"
        }
      ],
      "hops": [
        {
          "from_person": "常青、黃仕簡",
          "how": "奏",
          "inferred": false,
          "layer": 1,
          "place": "北京",
          "quote": "據常青、黃仕簡奏",
          "to_person": "乾隆帝",
          "whenAr": "1787/02/16",
          "whenCh": "乾隆五十一年十二月二十九日"
        },
        {
          "from_person": "臺灣鎮道",
          "how": "稟報",
          "inferred": false,
          "layer": 2,
          "place": "福建",
          "quote": "接臺灣鎮道稟報",
          "to_person": "常青、黃仕簡",
          "whenAr": "",
          "whenCh": ""
        }
      ]
    },
    {
      "events": [
        {
          "quote": "彰化失陷，文報梗塞情形",
          "reporter": "程必大、虞文光",
          "subtitle": "彰化失陷及文報梗塞",
          "whenCh": "",
          "where": "彰化"
        }
      ],
      "hops": [
        {
          "from_person": "常青",
          "how": "六百里馳奏",
          "inferred": false,
          "layer": 1,
          "place": "北京",
          "quote": "茲已刻又據常青六百里馳奏",
          "to_person": "乾隆帝",
          "whenAr": "1787/02/16",
          "whenCh": "乾隆五十一年十二月二十九日"
        },
        {
          "from_person": "程必大、虞文光",
          "how": "口述",
          "inferred": false,
          "layer": 2,
          "place": "福建",
          "quote": "詢悉淡水同知程峻之子程必大，及外委虞文光等彰化失陷，文報梗塞情形",
          "to_person": "常青",
          "whenAr": "",
          "whenCh": ""
        }
      ]
    }
  ],
  "_raw": {
    "chains": [
      {
        "events": [
          {
            "quote": "彰化匪徒林爽文等糾衆滋事，攔截要路，以致信息不通",
            "reporter": "臺灣鎮道",
            "subtitle": "林爽文等糾眾滋事並攔截道路",
            "whenCh": "",
            "where": "彰化"
          }
        ],
        "hops": [
          {
            "from_person": "常青、黃仕簡",
            "how": "奏",
            "inferred": false,
            "layer": 1,
            "place": "北京",
            "quote": "據常青、黃仕簡奏",
            "to_person": "乾隆帝",
            "whenAr": "1787/02/16",
            "whenCh": "乾隆五十一年十二月二十九日"
          },
          {
            "from_person": "臺灣鎮道",
            "how": "稟報",
            "inferred": false,
            "layer": 2,
            "place": "福建",
            "quote": "接臺灣鎮道稟報",
            "to_person": "常青、黃仕簡",
            "whenAr": "",
            "whenCh": ""
          }
        ]
      },
      {
        "events": [
          {
            "quote": "彰化失陷，文報梗塞情形",
            "reporter": "程必大、虞文光",
            "subtitle": "彰化失陷及文報梗塞",
            "whenCh": "",
            "where": "彰化"
          }
        ],
        "hops": [
          {
            "from_person": "常青",
            "how": "六百里馳奏",
            "inferred": false,
            "layer": 1,
            "place": "北京",
            "quote": "茲已刻又據常青六百里馳奏",
            "to_person": "乾隆帝",
            "whenAr": "1787/02/16",
            "whenCh": "乾隆五十一年十二月二十九日"
          },
          {
            "from_person": "程必大、虞文光",
            "how": "口述",
            "inferred": false,
            "layer": 2,
            "place": "福建",
            "quote": "詢悉淡水同知程峻之子程必大，及外委虞文光等彰化失陷，文報梗塞情形",
            "to_person": "常青",
            "whenAr": "",
            "whenCh": ""
          }
        ]
      }
    ],
    "mode": "trace"
  }
}
```

